# Murasaki Launcher (UI layer)
Built in the cloud by GitHub Actions - see .github/workflows/build.yml.
Real game launching still needs the Pojav engine (LauncherEngine.kt).
