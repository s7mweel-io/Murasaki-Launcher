# Murasaki Launcher
Unofficial launcher for Minecraft Java Edition. Not an official Minecraft product.
Not approved by or associated with Mojang or Microsoft.

Built in the cloud by GitHub Actions - see .github/workflows/build.yml.
Stage 1: real UI (loading screen, home, add instance, settings with cursor tab, 3D skin preview).
Next: Microsoft login, mod/resource/shader browsers, and the game engine.
