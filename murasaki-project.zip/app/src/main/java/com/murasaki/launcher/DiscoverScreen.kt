package com.murasaki.launcher

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import kotlinx.coroutines.delay

fun fmtCount(n: Long): String = when {
    n >= 1_000_000L -> String.format(java.util.Locale.US, "%.1fM", n / 1_000_000.0)
    n >= 1_000L -> (n / 1000L).toString() + "K"
    else -> n.toString()
}

@Composable
fun ProjectIcon(url: String?, size: Int) {
    val shape = RoundedCornerShape(7.dp)
    if (url == null) {
        Box(Modifier.size(size.dp).clip(shape).background(C.selected))
    } else {
        AsyncImage(
            model = url, contentDescription = null, contentScale = ContentScale.Crop,
            modifier = Modifier.size(size.dp).clip(shape).background(C.selected)
        )
    }
}

@Composable
fun DiscoverScreen(s: LauncherState) {
    val ctx = LocalContext.current
    LaunchedEffect(s.dTab, s.dSource, s.dSort, s.dMatch, s.instanceIdx, s.dQuery) {
        delay(350)
        s.search(true)
    }
    val names = listOf("mods", "resource packs", "shader packs", "modpacks")
    Column(Modifier.fillMaxWidth().padding(top = 6.dp, bottom = 12.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Seg(listOf("Mods", "Resource Packs", "Shader Packs", "Modpacks"), s.dTab, { s.dTab = it }, Modifier.width(300.dp))
            Spacer(Modifier.weight(1f))
            Seg(listOf("Modrinth", "CurseForge"), s.dSource, { s.dSource = it }, Modifier.width(120.dp))
        }
        Spacer(Modifier.height(6.dp))
        TextInput(s.dQuery, { s.dQuery = it }, "Search " + names[s.dTab] + "...", Modifier.fillMaxWidth())
        Spacer(Modifier.height(6.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Picker(Modifier.width(112.dp), SORT_LABELS, SORT_LABELS[s.dSort], { it }, height = 16) { s.dSort = SORT_LABELS.indexOf(it) }
            Spacer(Modifier.width(10.dp))
            if (s.dTab != 3) {
                Txt("Match " + s.current.version + (s.current.loader?.let { " " + it } ?: ""), 6f, C.sub)
                Spacer(Modifier.width(5.dp))
                Toggle(s.dMatch) { s.dMatch = it }
            }
            Spacer(Modifier.weight(1f))
            Txt("Installing to: " + s.current.title, 5.8f, C.muted)
        }
        Spacer(Modifier.height(8.dp))
        if (s.dSource == 1 && !CurseForge.hasKey()) {
            CardBox(Modifier.fillMaxWidth(), "Add your CurseForge key to use this tab") {
                Txt("CurseForge needs a free personal API key. Get yours at console.curseforge.com, then paste it in Settings, Online services.", 6.4f, C.sub)
                Spacer(Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PrimaryButton("Open Settings", Modifier.width(100.dp)) { s.settingsTab = 0; s.screen = "Settings" }
                    OutlineButton("Get a key", Modifier.width(80.dp)) {
                        try { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://console.curseforge.com"))) } catch (e: Exception) { s.toast("Could not open the website") }
                    }
                }
                Spacer(Modifier.height(4.dp))
                Txt("Modrinth works without a key.", 5.8f, C.muted)
            }
        } else {
            val err = s.dError
            if (err != null) {
                CardBox(Modifier.fillMaxWidth(), "Could not load") {
                    Txt(err, 6.4f, C.sub)
                    Spacer(Modifier.height(6.dp))
                    PrimaryButton("Try again", Modifier.width(80.dp)) { s.search(true) }
                }
            }
            s.dResults.forEach { p -> ProjectRow(s, p) }
            if (s.dLoading) Txt("Loading...", 7f, C.muted)
            else if (s.dResults.isEmpty() && err == null) Txt("No results", 7f, C.muted)
            if (s.dMore && !s.dLoading) {
                Spacer(Modifier.height(2.dp))
                OutlineButton("Load more", Modifier.width(100.dp)) { s.search(false) }
            }
        }
    }
}

@Composable
private fun ProjectRow(s: LauncherState, p: Project) {
    Row(
        Modifier.fillMaxWidth().padding(bottom = 6.dp).clip(R6).background(C.card).border(1.dp, C.border, R6)
            .clickable { s.detail = p }.padding(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        ProjectIcon(p.iconUrl, 36)
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Txt(p.title, 8f, C.text, FontWeight.Bold, maxLines = 1, modifier = Modifier.weight(1f, fill = false))
                if (p.author.isNotEmpty()) {
                    Spacer(Modifier.width(5.dp))
                    Txt("by " + p.author, 5.8f, C.muted, maxLines = 1)
                }
            }
            Txt(p.description, 6.1f, C.muted, maxLines = 2)
            Txt(fmtCount(p.downloads) + " downloads", 5.4f, C.muted)
        }
        Spacer(Modifier.width(8.dp))
        PrimaryButton(if (p.type == "modpack") "Install pack" else "Install", Modifier.width(62.dp)) { s.install(p, null) }
    }
}
