package com.murasaki.launcher

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

private val DialogShape = RoundedCornerShape(8.dp)

@Composable
private fun Scrim(onDismiss: () -> Unit, content: @Composable () -> Unit) {
    Box(
        Modifier.fillMaxSize().background(Color(0xB3000000)).pointerInput(Unit) { detectTapGestures { onDismiss() } },
        contentAlignment = Alignment.Center
    ) {
        Box(Modifier.pointerInput(Unit) { detectTapGestures { } }) { content() }
    }
}

@Composable
private fun DialogHeader(title: String, onClose: () -> Unit) {
    Row(Modifier.fillMaxWidth().height(31.dp).padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
        Txt(title, 9.5f, C.text, FontWeight.Bold, modifier = Modifier.weight(1f))
        Icon(Icons.Default.Close, null, tint = C.muted, modifier = Modifier.size(10.dp).clickable(onClick = onClose))
    }
    Box(Modifier.fillMaxWidth().height(1.dp).background(C.border))
}

// ---------------------------------------------------------------- Add Instance
@Composable
fun AddInstanceOverlay(s: LauncherState) {
    var name by remember { mutableStateOf("") }
    var ver by remember { mutableStateOf(s.versions.firstOrNull()?.id ?: "1.21.4") }
    var loader by remember { mutableStateOf(0) }
    var icon by remember { mutableStateOf("grass") }
    var custom by remember { mutableStateOf<String?>(null) }
    var globalMem by remember { mutableStateOf(true) }
    val loaders = listOf("Vanilla", "Fabric", "Forge", "NeoForge", "Quilt")
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            val p = s.saveImageCopy(uri, "icon_" + System.currentTimeMillis() + ".png", 256)
            if (p != null) { custom = p; icon = "custom" } else s.toast("Could not read that image")
        }
    }
    Scrim(onDismiss = { s.showAdd = false }) {
        Column(Modifier.width(590.dp).clip(DialogShape).background(Color(0xFF0F0F11)).border(1.dp, Color(0xFF30303A), DialogShape)) {
            DialogHeader("Add Instance") { s.showAdd = false }
            Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                Column(Modifier.weight(1f)) {
                    Txt("Instance name", 5.9f, C.muted)
                    Spacer(Modifier.height(3.dp))
                    TextInput(name, { name = it }, "My Survival World", Modifier.fillMaxWidth())
                    Spacer(Modifier.height(9.dp))
                    Txt("Minecraft version", 5.9f, C.muted)
                    Spacer(Modifier.height(3.dp))
                    Picker(Modifier.fillMaxWidth(), s.versions.map { it.id }, ver, { it }, height = 18) { ver = it }
                    Spacer(Modifier.height(9.dp))
                    Txt("Mod loader", 5.9f, C.muted)
                    Spacer(Modifier.height(3.dp))
                    Seg(loaders, loader, { loader = it }, Modifier.fillMaxWidth())
                    Spacer(Modifier.height(9.dp))
                    Txt("Loader version", 5.9f, C.muted)
                    Spacer(Modifier.height(3.dp))
                    Picker(Modifier.fillMaxWidth(), listOf("Latest (recommended)"), "Latest (recommended)", { it }, height = 18) { }
                    Spacer(Modifier.height(10.dp))
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Txt("Use global memory setting (${s.memoryMb} MB)", 6.3f, C.sub, modifier = Modifier.weight(1f))
                        Toggle(globalMem) { globalMem = it }
                    }
                }
                Column(Modifier.width(258.dp)) {
                    Row(Modifier.fillMaxWidth()) {
                        Txt("Instance icon", 5.9f, C.muted, modifier = Modifier.weight(1f))
                        Txt("Selected: " + (if (icon == "custom") "Your image" else BLOCKS.firstOrNull { it.key == icon }?.label ?: ""), 5.6f, C.sub)
                    }
                    Spacer(Modifier.height(5.dp))
                    val tiles = (if (custom != null) listOf("custom") else emptyList<String>()) + BLOCKS.map { it.key }
                    tiles.chunked(6).forEach { row ->
                        Row(Modifier.padding(bottom = 6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            row.forEach { key ->
                                val sel = key == icon
                                Box(
                                    Modifier.size(37.dp).clip(R6).background(Color(0xFF141418))
                                        .border(if (sel) 1.3.dp else 1.dp, if (sel) Color.White else C.border, R6)
                                        .clickable { icon = key },
                                    contentAlignment = Alignment.Center
                                ) {
                                    if (key == "custom") InstanceIcon("grass", custom, 30.dp) else InstanceIcon(key, null, 30.dp)
                                }
                            }
                        }
                    }
                    Spacer(Modifier.height(2.dp))
                    OutlineButton("Import your own image", Modifier.fillMaxWidth(), icon = Icons.Default.Add) { pick.launch("image/*") }
                }
            }
            Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 16.dp, bottom = 12.dp), horizontalArrangement = Arrangement.End) {
                OutlineButton("Cancel", Modifier.width(60.dp)) { s.showAdd = false }
                Spacer(Modifier.width(8.dp))
                PrimaryButton("Create instance", Modifier.width(128.dp), height = 22) {
                    val title = name.trim().ifEmpty { "New instance" }
                    val ld = if (loader > 0) loaders[loader] else null
                    s.addInstance(
                        Instance(
                            title, ver + (if (ld != null) "  -  " + ld else ""), ver, ld,
                            if (icon == "custom") "grass" else icon, if (icon == "custom") custom else null
                        )
                    )
                    s.showAdd = false
                }
            }
        }
    }
}

// ---------------------------------------------------------------- Accounts
@Composable
fun AccountsOverlay(s: LauncherState) {
    var localName by remember { mutableStateOf("") }
    Scrim(onDismiss = { s.showAccounts = false }) {
        Column(Modifier.width(600.dp).clip(DialogShape).background(Color(0xFF0F0F11)).border(1.dp, Color(0xFF30303A), DialogShape)) {
            DialogHeader("Accounts") { s.showAccounts = false }
            Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                Column(Modifier.width(236.dp)) {
                    Txt("Your accounts", 6.3f, C.muted)
                    Spacer(Modifier.height(5.dp))
                    s.accounts.forEachIndexed { i, a ->
                        val active = i == s.accountIdx
                        Row(
                            Modifier.fillMaxWidth().padding(bottom = 6.dp).clip(R6)
                                .background(if (active) C.selected else C.card)
                                .border(1.dp, if (active) Color(0xFF46464E) else C.border, R6)
                                .clickable { s.accountIdx = i; s.save() }.padding(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Avatar(a.name, 18)
                            Spacer(Modifier.width(8.dp))
                            Column(Modifier.weight(1f)) {
                                Txt(a.name, 7.2f, C.text, FontWeight.Bold, maxLines = 1)
                                Txt(a.type + (if (active) "  -  Active" else ""), 5.4f, if (active) C.green else C.muted, maxLines = 1)
                            }
                            Icon(Icons.Default.Close, null, tint = C.muted, modifier = Modifier.size(8.dp).clickable { s.removeAccount(i) })
                        }
                    }
                }
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    CardBox(Modifier.fillMaxWidth(), "Microsoft account") {
                        Txt("Sign in to play on online servers and to change your skin and cape. You will be taken to Microsoft's own sign-in page.", 5.9f, C.sub)
                        Spacer(Modifier.height(7.dp))
                        PrimaryButton("Sign in with Microsoft", Modifier.fillMaxWidth(), height = 24) {
                            s.toast("Microsoft sign-in arrives in the next step")
                        }
                    }
                    CardBox(Modifier.fillMaxWidth(), "Local account") {
                        Txt("Username", 5.9f, C.muted)
                        Spacer(Modifier.height(3.dp))
                        TextInput(localName, { localName = it }, "Steve", Modifier.fillMaxWidth())
                        Spacer(Modifier.height(5.dp))
                        Txt("Works offline and in single-player. Online servers need a Microsoft account.", 5.4f, C.muted)
                        Spacer(Modifier.height(7.dp))
                        OutlineButton("Create local account", Modifier.fillMaxWidth(), height = 24) {
                            s.addLocalAccount(localName); localName = ""
                        }
                    }
                }
            }
        }
    }
}
