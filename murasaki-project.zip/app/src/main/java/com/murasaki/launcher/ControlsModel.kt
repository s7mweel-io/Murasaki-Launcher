package com.murasaki.launcher

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

val KEY_GROUPS: List<Pair<String, List<String>>> = listOf(
    "Mouse" to listOf("LMB", "RMB", "Middle mouse", "Scroll up", "Scroll down"),
    "Letters" to ('A'..'Z').map { it.toString() },
    "Numbers" to ('0'..'9').map { it.toString() },
    "F keys" to (1..12).map { "F$it" },
    "Modifiers" to listOf("Ctrl", "Shift", "Alt", "Right Ctrl", "Right Shift", "Right Alt", "Caps Lock", "Tab", "Space", "Enter", "Backspace", "Esc"),
    "Move" to listOf("Up", "Down", "Left", "Right", "Home", "End", "Page Up", "Page Down", "Insert", "Delete"),
    "Symbols" to listOf("`", "-", "=", "[", "]", "\\", ";", "'", ",", ".", "/"),
    "Numpad" to ((0..9).map { "Num $it" } + listOf("Num +", "Num -", "Num *", "Num /", "Num .", "Num Enter", "Num Lock")),
    "Other" to listOf("Print Screen", "Scroll Lock", "Pause", "Menu")
)
val KEY_NAMES: List<String> = KEY_GROUPS.flatMap { it.second }
val SPECIALS = listOf("None", "Virtual mouse", "Hide controls", "Keyboard", "Open menu")

data class CtlButton(
    val id: String,
    val name: String,
    val kind: Int = 0,          // 0 = button, 1 = joystick
    val x: Float = 0.5f,        // 0..1 across the free width
    val y: Float = 0.5f,        // 0..1 across the free height
    val w: Float = 44f,         // size in design dp
    val h: Float = 44f,
    val radius: Float = 0.3f,   // 0 = square ... 1 = circle
    val opacity: Float = 0.85f,
    val fill: Long = 0xFF141418,
    val stroke: Long = 0xFF6E6E78,
    val strokeW: Float = 1f,
    val keys: List<String> = emptyList(),
    val special: String = "None",
    val toggle: Boolean = false,
    val swipe: Boolean = false,
    val pass: Boolean = false,
    val showInGame: Boolean = true,
    val locked: Boolean = false // joystick: forward lock
)

data class ControlLayout(
    val name: String,
    val buttons: List<CtlButton>,
    val snap: Boolean = true,
    val grid: Float = 0.3f,
    val scale: Float = 0.5f,
    val opacity: Float = 0.9f
)

data class LogLine(val time: String, val level: Char, val text: String)

fun layoutScale(l: ControlLayout): Float = 0.7f + l.scale * 0.8f

private const val REF_W = 793f
private const val REF_H = 366f
private fun cb(id: String, name: String, px: Float, py: Float, w: Float, h: Float, radius: Float, keys: List<String>, special: String = "None"): CtlButton =
    CtlButton(id = id, name = name, x = px / (REF_W - w), y = py / (REF_H - h), w = w, h = h, radius = radius, keys = keys, special = special)

fun defaultLayout(): ControlLayout {
    val b = ArrayList<CtlButton>()
    b.add(cb("w", "W", 86f, 222f, 36f, 36f, 0.3f, listOf("W")))
    b.add(cb("a", "A", 46f, 262f, 36f, 36f, 0.3f, listOf("A")))
    b.add(cb("s", "S", 86f, 262f, 36f, 36f, 0.3f, listOf("S")))
    b.add(cb("d", "D", 126f, 262f, 36f, 36f, 0.3f, listOf("D")))
    b.add(cb("attack", "Attack", 640f, 214f, 48f, 48f, 1f, listOf("LMB")))
    b.add(cb("use", "Use", 698f, 214f, 48f, 48f, 1f, listOf("RMB")))
    b.add(cb("sneak", "Sneak", 640f, 272f, 48f, 48f, 1f, listOf("Shift")))
    b.add(cb("jump", "Jump", 698f, 272f, 48f, 48f, 1f, listOf("Space")))
    b.add(cb("inv", "E", 16f, 56f, 30f, 30f, 0.3f, listOf("E")))
    b.add(cb("chat", "T", 52f, 56f, 30f, 30f, 0.3f, listOf("T")))
    b.add(cb("menu", "Menu", 88f, 56f, 40f, 30f, 0.3f, emptyList(), "Open menu"))
    for (i in 1..9) b.add(cb("h$i", "$i", 290f + (i - 1) * 24f, 334f, 21f, 21f, 0.2f, listOf("$i")).copy(opacity = 0.55f))
    return ControlLayout("Default", b)
}

private fun buttonToJson(b: CtlButton): JSONObject =
    JSONObject().put("id", b.id).put("name", b.name).put("kind", b.kind).put("x", b.x.toDouble()).put("y", b.y.toDouble())
        .put("w", b.w.toDouble()).put("h", b.h.toDouble()).put("r", b.radius.toDouble()).put("o", b.opacity.toDouble())
        .put("f", b.fill).put("s", b.stroke).put("sw", b.strokeW.toDouble()).put("keys", JSONArray(b.keys))
        .put("sp", b.special).put("t", b.toggle).put("sv", b.swipe).put("p", b.pass).put("g", b.showInGame).put("l", b.locked)

private fun buttonFromJson(o: JSONObject): CtlButton {
    val ks = o.optJSONArray("keys")
    val keys = if (ks == null) emptyList() else (0 until ks.length()).map { ks.getString(it) }
    return CtlButton(
        id = o.getString("id"), name = o.optString("name", "Button"), kind = o.optInt("kind", 0),
        x = o.optDouble("x", 0.5).toFloat(), y = o.optDouble("y", 0.5).toFloat(),
        w = o.optDouble("w", 44.0).toFloat(), h = o.optDouble("h", 44.0).toFloat(), radius = o.optDouble("r", 0.3).toFloat(),
        opacity = o.optDouble("o", 0.85).toFloat(), fill = o.optLong("f", 0xFF141418), stroke = o.optLong("s", 0xFF6E6E78),
        strokeW = o.optDouble("sw", 1.0).toFloat(), keys = keys, special = o.optString("sp", "None"),
        toggle = o.optBoolean("t", false), swipe = o.optBoolean("sv", false), pass = o.optBoolean("p", false),
        showInGame = o.optBoolean("g", true), locked = o.optBoolean("l", false)
    )
}

fun layoutToJson(l: ControlLayout): JSONObject {
    val arr = JSONArray()
    l.buttons.forEach { arr.put(buttonToJson(it)) }
    return JSONObject().put("name", l.name).put("snap", l.snap).put("grid", l.grid.toDouble())
        .put("scale", l.scale.toDouble()).put("opacity", l.opacity.toDouble()).put("buttons", arr)
}

fun layoutFromJson(o: JSONObject): ControlLayout {
    val arr = o.getJSONArray("buttons")
    return ControlLayout(
        o.optString("name", "Imported layout"), (0 until arr.length()).map { buttonFromJson(arr.getJSONObject(it)) },
        o.optBoolean("snap", true), o.optDouble("grid", 0.3).toFloat(), o.optDouble("scale", 0.5).toFloat(), o.optDouble("opacity", 0.9).toFloat()
    )
}

class ControlsStore(private val ctx: Context) {
    private val sp = ctx.getSharedPreferences("murasaki_controls", Context.MODE_PRIVATE)
    var layouts by mutableStateOf(listOf(defaultLayout()))
    var activeIdx by mutableStateOf(0)
    var defaultIdx by mutableStateOf(0)
    val active: ControlLayout get() = layouts[activeIdx.coerceIn(0, layouts.lastIndex)]

    init { runCatching { load() } }

    private fun load() {
        val o = JSONObject(sp.getString("data", "{}") ?: "{}")
        val arr = o.optJSONArray("layouts")
        if (arr != null && arr.length() > 0) {
            layouts = (0 until arr.length()).map { layoutFromJson(arr.getJSONObject(it)) }
            activeIdx = o.optInt("active", 0).coerceIn(0, layouts.lastIndex)
            defaultIdx = o.optInt("default", 0).coerceIn(0, layouts.lastIndex)
        }
    }

    fun save() {
        val arr = JSONArray()
        layouts.forEach { arr.put(layoutToJson(it)) }
        sp.edit().putString("data", JSONObject().put("layouts", arr).put("active", activeIdx).put("default", defaultIdx).toString()).apply()
    }

    fun setActive(i: Int) { activeIdx = i.coerceIn(0, layouts.lastIndex); save() }
    fun setDefault(i: Int) { defaultIdx = i.coerceIn(0, layouts.lastIndex); save() }
    fun updateActive(l: ControlLayout) {
        layouts = layouts.mapIndexed { n, old -> if (n == activeIdx) l else old }
        save()
    }
    fun addCopy(name: String, from: ControlLayout) {
        val base = name.trim().ifEmpty { "My layout" }
        var n = base
        var k = 2
        while (layouts.any { it.name == n }) { n = base + " " + k; k++ }
        layouts = layouts + from.copy(name = n)
        activeIdx = layouts.lastIndex
        save()
    }
    fun delete(i: Int) {
        if (layouts.size <= 1) return
        layouts = layouts.filterIndexed { n, _ -> n != i }
        activeIdx = activeIdx.coerceIn(0, layouts.lastIndex)
        defaultIdx = defaultIdx.coerceIn(0, layouts.lastIndex)
        save()
    }
    fun resetActive() { updateActive(defaultLayout().copy(name = active.name)) }
    fun export(i: Int): String {
        val l = layouts[i]
        val dir = File(ctx.getExternalFilesDir(null) ?: ctx.filesDir, "Minecraft/controls")
        dir.mkdirs()
        val f = File(dir, slug(l.name) + ".json")
        f.writeText(layoutToJson(l).toString(2))
        return f.path
    }
    fun importText(text: String): Boolean = try {
        val l = layoutFromJson(JSONObject(text))
        addCopy(l.name, l)
        true
    } catch (e: Exception) {
        false
    }
}

class GameSession {
    var running by mutableStateOf(false)
    var logs by mutableStateOf<List<LogLine>>(emptyList())
    var controlsVisible by mutableStateOf(true)
    var perf by mutableStateOf(false)
    var keyboard by mutableStateOf(false)
    var virtualMouse by mutableStateOf(true)
    var cx by mutableStateOf(300f)
    var cy by mutableStateOf(160f)
    val pressed = HashSet<String>()
    private val fmt = SimpleDateFormat("HH:mm:ss", Locale.US)

    fun log(level: Char, text: String) {
        logs = (logs + LogLine(fmt.format(Date()), level, text)).takeLast(3000)
    }

    fun key(name: String, down: Boolean) {
        if (down) { if (!pressed.add(name)) return } else { if (!pressed.remove(name)) return }
        log('I', "[Input] " + name + (if (down) " pressed" else " released"))
    }

    fun begin() {
        logs = emptyList()
        pressed.clear()
        controlsVisible = true
        running = true
    }
}
