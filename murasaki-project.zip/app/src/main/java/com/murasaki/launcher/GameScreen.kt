package com.murasaki.launcher

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.io.File

private val GShape = RoundedCornerShape(8.dp)

@Composable
fun GameScreen(s: LauncherState) {
    val g = s.game
    var menuOpen by remember { mutableStateOf(false) }
    var showLog by remember { mutableStateOf(false) }
    var showLayouts by remember { mutableStateOf(false) }
    var showForce by remember { mutableStateOf(false) }
    var fps by remember { mutableStateOf(0) }

    BackHandler(enabled = !s.editorOpen) { if (showLog) showLog = false else menuOpen = !menuOpen }

    LaunchedEffect(g.perf) {
        if (g.perf) {
            var last = 0L
            var frames = 0
            var acc = 0L
            while (true) {
                withFrameNanos { n ->
                    if (last != 0L) {
                        acc += n - last
                        frames++
                        if (acc >= 500_000_000L) {
                            fps = (frames * 1_000_000_000L / acc).toInt()
                            frames = 0
                            acc = 0L
                        }
                    }
                    last = n
                }
            }
        }
    }

    Box(Modifier.fillMaxSize().background(C.bg)) {
        // game surface (stands in for Minecraft until the engine is connected)
        Box(
            Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF1C2B3C), Color(0xFF0A0E13))))
                .pointerInput(Unit) {
                    detectDragGestures { change, drag ->
                        change.consume()
                        if (g.virtualMouse) {
                            val k = 0.5f + s.cursorSens * 1.8f
                            g.cx = (g.cx + drag.x * k).coerceIn(0f, 4000f)
                            g.cy = (g.cy + drag.y * k).coerceIn(0f, 4000f)
                        }
                    }
                }
        )
        Canvas(Modifier.fillMaxSize()) {
            if (g.virtualMouse) {
                drawCursor(
                    s.cursorStyle, Offset(g.cx.coerceIn(0f, size.width), g.cy.coerceIn(0f, size.height)),
                    (10f + s.cursorSize * 26f).dp.toPx(), s.customCursor?.asImageBitmap()
                )
            }
        }
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Txt("Preview session  -  the Minecraft engine is not connected yet", 7f, Color(0x66FFFFFF))
        }
        // on-screen controls
        if (g.controlsVisible && !s.editorOpen) {
            BoxWithConstraints(Modifier.fillMaxSize()) {
                val areaW = maxWidth.value
                val areaH = maxHeight.value
                val lay = s.controls.active
                val sc = layoutScale(lay)
                lay.buttons.forEach { b ->
                    if (b.showInGame) key(b.id) { GameCtl(s, b, lay, sc, areaW, areaH) { menuOpen = true } }
                }
            }
        }
        // menu button
        Box(
            Modifier.padding(10.dp).size(26.dp).clip(R6).background(Color(0xD70A0A0C)).border(1.dp, Color(0xFF46464E), R6)
                .clickable { menuOpen = true },
            contentAlignment = Alignment.Center
        ) { Image(painterResource(R.drawable.logo_mark), null, Modifier.height(14.dp).aspectRatio(1.128f)) }
        // performance overlay
        if (g.perf) {
            val used = remember(fps) { (Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory()) / 1048576L }
            Box(Modifier.fillMaxSize().padding(10.dp), contentAlignment = Alignment.TopEnd) {
                Column(horizontalAlignment = Alignment.End) {
                    Txt("$fps FPS", 6.6f, Color.White, FontWeight.Bold)
                    Txt("$used MB used", 5.4f, Color(0xCCFFFFFF))
                }
            }
        }
        if (g.keyboard) Box(Modifier.fillMaxSize(), contentAlignment = Alignment.BottomCenter) { KeyboardBar(g) }
        // menu drawer
        if (menuOpen) {
            Row(Modifier.fillMaxSize()) {
                GameMenu(
                    s,
                    onResume = { menuOpen = false },
                    onEdit = { menuOpen = false; s.editorOpen = true },
                    onLayouts = { menuOpen = false; showLayouts = true },
                    onLog = { menuOpen = false; showLog = true },
                    onForce = { menuOpen = false; showForce = true },
                    onQuit = { menuOpen = false; s.endGame(false) }
                )
                Box(Modifier.weight(1f).fillMaxHeight().background(Color(0x99000000)).clickable { menuOpen = false })
            }
        }
        if (showLog) LogPanel(s) { showLog = false }
        if (showLayouts) LayoutsDialog(s) { showLayouts = false }
        if (showForce) {
            ModalBox(onDismiss = { showForce = false }) {
                Column(Modifier.width(270.dp).clip(GShape).background(Color(0xFF101012)).border(1.dp, Color(0xFF5A3030), GShape).padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.PowerSettingsNew, null, tint = Color(0xFFF87171), modifier = Modifier.size(12.dp))
                        Spacer(Modifier.width(8.dp))
                        Txt("Force quit game?", 8.6f, C.text, FontWeight.Bold)
                    }
                    Spacer(Modifier.height(8.dp))
                    Txt("The game process will be stopped right away.", 6.3f, C.sub)
                    Txt("Unsaved progress in the world will be lost.", 6.3f, C.sub)
                    Spacer(Modifier.height(12.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                        OutlineButton("Cancel", Modifier.width(80.dp)) { showForce = false }
                        Spacer(Modifier.width(8.dp))
                        Box(
                            Modifier.width(120.dp).height(22.dp).clip(R4).background(Color(0xFFDC4646))
                                .clickable { showForce = false; s.endGame(true) },
                            contentAlignment = Alignment.Center
                        ) { Txt("Force quit", 6.8f, Color.White, FontWeight.Bold) }
                    }
                }
            }
        }
    }
}

@Composable
private fun GameCtl(s: LauncherState, b: CtlButton, lay: ControlLayout, sc: Float, areaW: Float, areaH: Float, onMenu: () -> Unit) {
    val g = s.game
    var pressed by remember { mutableStateOf(false) }
    var toggled by remember { mutableStateOf(false) }
    var stick by remember { mutableStateOf(Offset.Zero) }
    val bw = b.w * sc
    val bh = b.h * sc
    val ox = b.x * (areaW - bw).coerceAtLeast(0f)
    val oy = b.y * (areaH - bh).coerceAtLeast(0f)
    val base = Modifier.offset(ox.dp, oy.dp)

    fun fire(down: Boolean) {
        for (k in b.keys) g.key(k, down)
        when (b.special) {
            "Mouse left", "Mouse right", "Mouse middle" -> g.key(b.special, down)
            "Virtual mouse" -> if (down) g.virtualMouse = !g.virtualMouse
            "Hide controls" -> if (down) g.controlsVisible = false
            "Keyboard" -> if (down) g.keyboard = !g.keyboard
            "Open menu" -> if (down) onMenu()
            else -> {}
        }
    }

    if (b.kind == 1) {
        Box(
            base.pointerInput(b.id) {
                fun upd(p: Offset) {
                    val r = size.width / 2f
                    val maxR = r * 0.6f
                    var dx = p.x - r
                    var dy = p.y - size.height / 2f
                    val len = kotlin.math.sqrt(dx * dx + dy * dy)
                    if (len > maxR && len > 0f) {
                        dx = dx / len * maxR
                        dy = dy / len * maxR
                    }
                    stick = Offset(dx, dy)
                    val nx = dx / maxR
                    val ny = dy / maxR
                    g.key("W", ny < -0.35f)
                    g.key("S", ny > 0.35f)
                    g.key("A", nx < -0.35f)
                    g.key("D", nx > 0.35f)
                    if (b.locked) g.key("Ctrl", ny < -0.92f)
                }
                fun release() {
                    stick = Offset.Zero
                    for (k in listOf("W", "A", "S", "D", "Ctrl")) g.key(k, false)
                }
                detectDragGestures(
                    onDragStart = { upd(it) },
                    onDragEnd = { release() },
                    onDragCancel = { release() },
                    onDrag = { change, _ -> change.consume(); upd(change.position) }
                )
            }
        ) { CtlVisual(b, sc, lay.opacity, false, stick) }
    } else {
        Box(
            base.pointerInput(b.id) {
                detectTapGestures(onPress = {
                    if (b.toggle) {
                        toggled = !toggled
                        fire(toggled)
                    } else {
                        pressed = true
                        fire(true)
                        tryAwaitRelease()
                        pressed = false
                        fire(false)
                    }
                })
            }
        ) { CtlVisual(b, sc, lay.opacity, pressed || toggled, Offset.Zero) }
    }
}

@Composable
private fun KeyboardBar(g: GameSession) {
    var text by remember { mutableStateOf("") }
    Row(
        Modifier.padding(bottom = 6.dp).width(300.dp).clip(R6).background(Color(0xF0101012)).border(1.dp, C.border, R6).padding(6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        TextInput(
            text, { v ->
                if (v.length > text.length) g.log('I', "[Input] typed: " + v.substring(text.length))
                text = v
            }, "Type here (on-screen keyboard)", Modifier.weight(1f)
        )
        Spacer(Modifier.width(6.dp))
        OutlineButton("Close", Modifier.width(44.dp), height = 18) { g.keyboard = false }
    }
}

@Composable
private fun MenuRow(icon: ImageVector, label: String, color: Color = C.sub, trailing: @Composable () -> Unit = {}, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().height(21.dp).padding(horizontal = 6.dp).clip(R5).clickable(onClick = onClick).padding(horizontal = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = color, modifier = Modifier.size(9.dp))
        Spacer(Modifier.width(8.dp))
        Txt(label, 6.6f, color, modifier = Modifier.weight(1f))
        trailing()
    }
}

@Composable
private fun MenuLabel(text: String) {
    Txt(text, 5f, C.muted, FontWeight.Bold, spacing = 0.9f, modifier = Modifier.padding(start = 14.dp, top = 8.dp, bottom = 2.dp))
}

@Composable
private fun GameMenu(
    s: LauncherState, onResume: () -> Unit, onEdit: () -> Unit, onLayouts: () -> Unit,
    onLog: () -> Unit, onForce: () -> Unit, onQuit: () -> Unit
) {
    val g = s.game
    Column(
        Modifier.width(192.dp).fillMaxHeight().background(Color(0xFC0C0C0E)).border(1.dp, C.border)
            .verticalScroll(rememberScrollState()).padding(vertical = 8.dp)
    ) {
        Row(Modifier.padding(start = 14.dp, end = 10.dp, bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Image(painterResource(R.drawable.logo_mark), null, Modifier.height(20.dp).aspectRatio(1.128f))
            Spacer(Modifier.width(8.dp))
            Column {
                Txt("Murasaki Launcher", 7.4f, C.text, FontWeight.Bold, maxLines = 1)
                Txt(s.current.title + "  -  preview session", 5.2f, C.muted, maxLines = 1)
            }
        }
        Box(Modifier.padding(horizontal = 10.dp).fillMaxWidth().height(1.dp).background(C.border))
        Spacer(Modifier.height(4.dp))
        MenuRow(Icons.Default.PlayArrow, "Resume game", onClick = onResume)
        MenuRow(Icons.Default.Keyboard, "On-screen keyboard", trailing = { Toggle(g.keyboard) { g.keyboard = it } }) { g.keyboard = !g.keyboard }
        MenuRow(Icons.Default.Visibility, "Show controls", trailing = { Toggle(g.controlsVisible) { g.controlsVisible = it } }) { g.controlsVisible = !g.controlsVisible }
        MenuRow(Icons.Default.Speed, "Performance overlay", trailing = { Toggle(g.perf) { g.perf = it } }) { g.perf = !g.perf }
        MenuLabel("CONTROLS")
        MenuRow(Icons.Default.Edit, "Edit controls", onClick = onEdit)
        MenuRow(
            Icons.Default.Layers, "Change layout",
            trailing = { Txt(s.controls.active.name, 5.4f, C.muted, maxLines = 1) }, onClick = onLayouts
        )
        Column(Modifier.padding(horizontal = 14.dp, vertical = 4.dp)) {
            Txt("Cursor size", 6f, C.sub)
            FlatSlider(s.cursorSize, { s.cursorSize = it; s.save() }, Modifier.fillMaxWidth())
            Txt("Sensitivity", 6f, C.sub)
            FlatSlider(s.cursorSens, { s.cursorSens = it; s.save() }, Modifier.fillMaxWidth())
        }
        MenuLabel("TOOLS")
        MenuRow(Icons.Default.Description, "Log output", onClick = onLog)
        Box(Modifier.padding(horizontal = 10.dp, vertical = 4.dp).fillMaxWidth().height(1.dp).background(C.border))
        MenuRow(Icons.Default.PowerSettingsNew, "Force quit game", color = Color(0xFFF87171), onClick = onForce)
        MenuRow(Icons.Default.ExitToApp, "Quit to launcher", onClick = onQuit)
    }
}

@Composable
private fun LogButton(label: String, onClick: () -> Unit) {
    Box(
        Modifier.clip(R4).background(C.field).border(1.dp, C.border, R4).clickable(onClick = onClick).padding(horizontal = 8.dp, vertical = 3.dp),
        contentAlignment = Alignment.Center
    ) { Txt(label, 5.8f, C.text, FontWeight.Bold) }
}

@Composable
private fun LogPanel(s: LauncherState, onClose: () -> Unit) {
    val g = s.game
    val ctx = LocalContext.current
    var flt by remember { mutableStateOf(0) }
    var q by remember { mutableStateOf("") }
    var auto by remember { mutableStateOf(true) }
    val shown = g.logs.filter { l ->
        (flt == 0 || (flt == 1 && l.level == 'I') || (flt == 2 && l.level == 'W') || (flt == 3 && l.level == 'E')) &&
            (q.isEmpty() || l.text.contains(q, ignoreCase = true))
    }
    val ls = rememberLazyListState()
    LaunchedEffect(shown.size, auto) { if (auto && shown.isNotEmpty()) ls.scrollToItem(shown.lastIndex) }
    Box(Modifier.fillMaxSize().background(Color(0xB3000000)).pointerInput(Unit) { detectTapGestures { } }) {
        Column(
            Modifier.fillMaxSize().padding(horizontal = 26.dp, vertical = 14.dp).clip(R6).background(Color(0xFA090A0C)).border(1.dp, Color(0xFF38383E), R6)
        ) {
            Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Txt("Log output", 8.4f, C.text, FontWeight.Bold)
                Spacer(Modifier.width(10.dp))
                Seg(listOf("All", "Info", "Warn", "Error"), flt, { flt = it }, Modifier.width(150.dp), height = 16)
                Spacer(Modifier.width(8.dp))
                TextInput(q, { q = it }, "Search log...", Modifier.weight(1f))
                Spacer(Modifier.width(8.dp))
                LogButton("Copy") {
                    val text = shown.joinToString("\n") { it.time + "  " + it.text }
                    val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    cm.setPrimaryClip(ClipData.newPlainText("Murasaki log", text))
                    s.toast("Log copied")
                }
                Spacer(Modifier.width(4.dp))
                LogButton("Save") {
                    val dir = File(ctx.getExternalFilesDir(null) ?: ctx.filesDir, "Minecraft/logs")
                    dir.mkdirs()
                    val f = File(dir, "latest.log")
                    f.writeText(g.logs.joinToString("\n") { it.time + "  " + it.text })
                    s.toast("Saved: " + f.path)
                }
                Spacer(Modifier.width(4.dp))
                LogButton("Clear") { g.logs = emptyList() }
                Spacer(Modifier.width(8.dp))
                Icon(Icons.Default.Close, null, tint = C.muted, modifier = Modifier.size(10.dp).clickable(onClick = onClose))
            }
            Box(Modifier.fillMaxWidth().height(1.dp).background(C.border))
            LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 10.dp, vertical = 4.dp), state = ls) {
                items(shown) { l ->
                    val col = if (l.level == 'E') Color(0xFFF87171) else if (l.level == 'W') Color(0xFFFACC15) else Color(0xFFDCDCE4)
                    Row(Modifier.fillMaxWidth()) {
                        Text(l.time, color = Color(0xFF6E6E78), fontSize = 5.2.sp, lineHeight = 7.5.sp, fontFamily = FontFamily.Monospace)
                        Spacer(Modifier.width(8.dp))
                        Text(l.text, color = col, fontSize = 5.6.sp, lineHeight = 7.5.sp, fontFamily = FontFamily.Monospace)
                    }
                }
            }
            Box(Modifier.fillMaxWidth().height(1.dp).background(C.border))
            Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                Txt(shown.size.toString() + " lines", 5.6f, C.muted, modifier = Modifier.weight(1f))
                Txt("Auto-scroll", 5.8f, C.sub)
                Spacer(Modifier.width(6.dp))
                Toggle(auto) { auto = it }
            }
        }
    }
}
