package com.murasaki.launcher

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

@Composable
fun InstanceScreen(s: LauncherState) {
    val idx = s.manageIdx.coerceIn(0, s.instances.lastIndex)
    val inst = s.instances[idx]
    Column(Modifier.fillMaxWidth().padding(top = 6.dp, bottom = 12.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            InstanceIcon(inst.iconKey, inst.customIcon, 28.dp)
            Spacer(Modifier.width(9.dp))
            Column(Modifier.weight(1f)) {
                Txt(inst.title, 10f, C.text, FontWeight.Bold, maxLines = 1)
                Txt(inst.version + (if (inst.loader != null) "  -  " + inst.loader else ""), 6f, C.muted)
            }
            PrimaryButton("Use this instance", Modifier.width(100.dp), height = 20) { s.instanceIdx = idx; s.save(); s.screen = "Home" }
        }
        Spacer(Modifier.height(8.dp))
        Seg(listOf("Content", "Settings", "Game options"), s.instTab, { s.instTab = it }, Modifier.width(250.dp))
        Spacer(Modifier.height(8.dp))
        when (s.instTab) {
            0 -> ContentTab(s, idx, inst)
            1 -> InstanceSettingsTab(s, idx, inst)
            else -> OptionsTab(s, inst)
        }
    }
}

@Composable
private fun ContentTab(s: LauncherState, idx: Int, inst: Instance) {
    val items = remember(s.refreshTick, inst.dir) { s.installer.listInstalled(inst) }
    val groups = listOf("mod" to "Mods", "resourcepack" to "Resource packs", "shader" to "Shader packs")
    groups.forEachIndexed { n, g ->
        val list = items.filter { it.type == g.first }
        Row(Modifier.fillMaxWidth().padding(top = 4.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Txt(g.second + " (" + list.size + ")", 8f, C.text, FontWeight.Bold, modifier = Modifier.weight(1f))
            OutlineButton("Find more", Modifier.width(70.dp), height = 18) {
                s.instanceIdx = idx; s.save(); s.dTab = n; s.screen = "Discover"
            }
        }
        if (list.isEmpty()) Txt("Nothing installed yet", 6f, C.muted)
        list.forEach { item -> InstalledRow(s, inst, item) }
    }
    Spacer(Modifier.height(8.dp))
    Txt("Folder: " + s.installer.dir(inst).path, 5.2f, C.muted)
}

@Composable
private fun InstalledRow(s: LauncherState, inst: Instance, item: InstalledItem) {
    Row(
        Modifier.fillMaxWidth().padding(bottom = 4.dp).clip(R6).background(C.card).border(1.dp, C.border, R6).padding(7.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        ProjectIcon(item.iconUrl, 24)
        Spacer(Modifier.width(8.dp))
        Column(Modifier.weight(1f)) {
            Txt(item.title, 7f, if (item.enabled) C.text else C.muted, FontWeight.Bold, maxLines = 1)
            Txt(item.fileName + "  -  " + item.sizeKb + " KB", 5.2f, C.muted, maxLines = 1)
        }
        if (item.type == "mod") {
            Toggle(item.enabled) { on -> s.installer.setEnabled(inst, item, on); s.refreshTick++ }
            Spacer(Modifier.width(10.dp))
        }
        Txt("Remove", 6f, Color(0xFFF87171), modifier = Modifier.clickable { s.installer.remove(inst, item); s.refreshTick++ })
    }
}

@Composable
private fun InstanceSettingsTab(s: LauncherState, idx: Int, inst: Instance) {
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            val p = s.saveImageCopy(uri, "icon_" + System.currentTimeMillis() + ".png", 256)
            if (p != null) s.updateInstance(idx, inst.copy(customIcon = p)) else s.toast("Could not read that image")
        }
    }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        CardBox(Modifier.weight(1f), "General") {
            Txt("Name", 6.3f, C.sub)
            Spacer(Modifier.height(3.dp))
            TextInput(inst.title, { s.updateInstance(idx, inst.copy(title = it)) }, "Instance name", Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            Txt("Icon", 6.3f, C.sub)
            Spacer(Modifier.height(4.dp))
            BLOCKS.chunked(6).forEach { row ->
                Row(Modifier.padding(bottom = 4.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    row.forEach { b ->
                        val sel = inst.customIcon == null && inst.iconKey == b.key
                        Box(
                            Modifier.size(28.dp).clip(R5).background(Color(0xFF141418))
                                .border(if (sel) 1.3.dp else 1.dp, if (sel) Color.White else C.border, R5)
                                .clickable { s.updateInstance(idx, inst.copy(iconKey = b.key, customIcon = null)) },
                            contentAlignment = Alignment.Center
                        ) { InstanceIcon(b.key, null, 22.dp) }
                    }
                }
            }
            Spacer(Modifier.height(2.dp))
            OutlineButton("Import your own image", Modifier.fillMaxWidth(), icon = Icons.Default.Add) { pick.launch("image/*") }
            if (s.instances.size > 1) {
                Spacer(Modifier.height(10.dp))
                Txt("Delete this instance and its files", 6f, Color(0xFFF87171), modifier = Modifier.clickable {
                    s.removeInstance(idx); s.screen = "Library"
                })
            }
        }
        CardBox(Modifier.weight(1f), "Game") {
            SettingRow("Java version") {
                Picker(
                    Modifier.width(120.dp), listOf("Use global setting", "Temurin 8", "Temurin 17", "Temurin 21"),
                    inst.javaOverride ?: "Use global setting", { it }, height = 16
                ) { s.updateInstance(idx, inst.copy(javaOverride = if (it == "Use global setting") null else it)) }
            }
            SettingRow("Override memory") {
                Toggle(inst.memOverride > 0) { on -> s.updateInstance(idx, inst.copy(memOverride = if (on) s.memoryMb else 0)) }
            }
            if (inst.memOverride > 0) {
                Row(Modifier.fillMaxWidth().height(18.dp), verticalAlignment = Alignment.CenterVertically) {
                    FlatSlider((inst.memOverride - 1024) / 5120f, { f -> s.updateInstance(idx, inst.copy(memOverride = 1024 + ((f * 20f).toInt() * 256))) }, Modifier.weight(1f))
                    Txt(inst.memOverride.toString() + " MB", 6.4f, C.text, FontWeight.Bold, modifier = Modifier.width(52.dp))
                }
            }
            Txt("JVM arguments (leave empty to use the global ones)", 6.0f, C.sub)
            Spacer(Modifier.height(3.dp))
            TextInput(inst.jvmOverride, { s.updateInstance(idx, inst.copy(jvmOverride = it)) }, "-Xss1M", Modifier.fillMaxWidth())
            Spacer(Modifier.height(6.dp))
            Txt("Game arguments", 6.0f, C.sub)
            Spacer(Modifier.height(3.dp))
            TextInput(inst.gameArgs, { s.updateInstance(idx, inst.copy(gameArgs = it)) }, "--quickPlayMultiplayer example.com", Modifier.fillMaxWidth())
            Spacer(Modifier.height(6.dp))
            Txt("Window size (0 = automatic)", 6.0f, C.sub)
            Spacer(Modifier.height(3.dp))
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                TextInput(if (inst.resW == 0) "" else inst.resW.toString(), { t -> s.updateInstance(idx, inst.copy(resW = t.filter { c -> c.isDigit() }.take(4).toIntOrNull() ?: 0)) }, "Width", Modifier.width(70.dp))
                Txt("  x  ", 6.4f, C.muted)
                TextInput(if (inst.resH == 0) "" else inst.resH.toString(), { t -> s.updateInstance(idx, inst.copy(resH = t.filter { c -> c.isDigit() }.take(4).toIntOrNull() ?: 0)) }, "Height", Modifier.width(70.dp))
            }
        }
    }
}

@Composable
private fun OptSlider(label: String, frac: Float, value: String, onChange: (Float) -> Unit) {
    Row(Modifier.fillMaxWidth().height(20.dp), verticalAlignment = Alignment.CenterVertically) {
        Txt(label, 6.3f, C.sub, modifier = Modifier.width(110.dp))
        FlatSlider(frac, onChange, Modifier.weight(1f))
        Txt(value, 6.2f, C.text, FontWeight.Bold, modifier = Modifier.width(66.dp))
    }
}

@Composable
private fun OptionsTab(s: LauncherState, inst: Instance) {
    var opts by remember(inst.dir, s.refreshTick) { mutableStateOf(s.installer.readOptions(inst)) }
    fun put(k: String, v: String) { s.installer.writeOption(inst, k, v); opts = s.installer.readOptions(inst) }
    fun num(k: String, d: Float): Float = opts[k]?.toFloatOrNull() ?: d
    fun flag(k: String, d: Boolean): Boolean = opts[k]?.let { it == "true" } ?: d
    fun f2(v: Float): String = String.format(java.util.Locale.US, "%.2f", v)
    CardBox(Modifier.fillMaxWidth(), "Game options") {
        Txt("Saved in this instance's options.txt. Needs Minecraft 1.18 or newer.", 5.6f, C.muted)
        Spacer(Modifier.height(6.dp))
        val rd = num("renderDistance", 12f)
        OptSlider("Render distance", (rd - 2f) / 30f, rd.toInt().toString() + " chunks") { put("renderDistance", (2 + (it * 30f).toInt()).toString()) }
        val fps = num("maxFps", 120f)
        OptSlider("Max FPS", (fps - 10f) / 250f, if (fps >= 260f) "Unlimited" else fps.toInt().toString()) { put("maxFps", (10 + (it * 250f).toInt()).toString()) }
        val fov = 70f + num("fov", 0f) * 40f
        OptSlider("Field of view", (fov - 30f) / 80f, fov.toInt().toString()) { put("fov", f2(((30f + it * 80f) - 70f) / 40f)) }
        val gm = num("gamma", 0.5f)
        OptSlider("Brightness", gm, (gm * 100f).toInt().toString() + "%") { put("gamma", f2(it)) }
        val vol = num("soundCategory_master", 1f)
        OptSlider("Master volume", vol, (vol * 100f).toInt().toString() + "%") { put("soundCategory_master", f2(it)) }
        Spacer(Modifier.height(4.dp))
        val gui = listOf("Auto", "1", "2", "3", "4")
        SettingRow("Interface size") {
            Picker(Modifier.width(112.dp), gui, gui[num("guiScale", 0f).toInt().coerceIn(0, 4)], { it }, height = 16) { put("guiScale", gui.indexOf(it).toString()) }
        }
        val gfx = listOf("Fast", "Fancy", "Fabulous")
        SettingRow("Graphics") {
            Picker(Modifier.width(112.dp), gfx, gfx[num("graphicsMode", 1f).toInt().coerceIn(0, 2)], { it }, height = 16) { put("graphicsMode", gfx.indexOf(it).toString()) }
        }
        val par = listOf("All", "Decreased", "Minimal")
        SettingRow("Particles") {
            Picker(Modifier.width(112.dp), par, par[num("particles", 0f).toInt().coerceIn(0, 2)], { it }, height = 16) { put("particles", par.indexOf(it).toString()) }
        }
        SettingRow("VSync") { Toggle(flag("enableVsync", true)) { put("enableVsync", it.toString()) } }
        SettingRow("Entity shadows") { Toggle(flag("entityShadows", true)) { put("entityShadows", it.toString()) } }
    }
}
