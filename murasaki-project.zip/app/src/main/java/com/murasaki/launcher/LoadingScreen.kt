package com.murasaki.launcher

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun LoadingScreen(onDone: () -> Unit) {
    val mark = remember { Animatable(0f) }
    val word = remember { Animatable(0f) }
    val band = remember { Animatable(0f) }
    val prog = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        coroutineScope {
            launch { mark.animateTo(1f, tween(800)) }
            launch { delay(600); word.animateTo(1f, tween(750)) }
            launch { delay(1250); band.animateTo(1f, tween(600)) }
            launch { delay(1500); prog.animateTo(1f, tween(2600, easing = FastOutSlowInEasing)) }
        }
        delay(350)
        onDone()
    }
    val p = prog.value
    val status = when {
        p < 0.30f -> "Checking Java runtime..."
        p < 0.66f -> "Preparing game files..."
        p < 0.97f -> "Starting Minecraft..."
        else -> "Ready"
    }
    Box(Modifier.fillMaxSize().background(C.bg), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Image(
                painterResource(R.drawable.logo_mark), null,
                Modifier.height(92.dp).aspectRatio(1.128f)
                    .graphicsLayer { alpha = mark.value; scaleX = 0.85f + 0.15f * mark.value; scaleY = 0.85f + 0.15f * mark.value }
            )
            Spacer(Modifier.height(14.dp))
            Image(
                painterResource(R.drawable.logo_wordmark), null,
                Modifier.width(250.dp).aspectRatio(10.17f).graphicsLayer { alpha = word.value }
                    .drawWithContent { clipRect(right = size.width * word.value) { this@drawWithContent.drawContent() } }
            )
            Spacer(Modifier.height(4.dp))
            Image(
                painterResource(R.drawable.logo_launcher_band), null,
                Modifier.width(190.dp).aspectRatio(18.25f).graphicsLayer { alpha = band.value }
            )
            Spacer(Modifier.height(34.dp))
            Box(
                Modifier.width(210.dp).height(3.dp).clip(RoundedCornerShape(2.dp))
                    .graphicsLayer { alpha = if (prog.value > 0f) 1f else 0f }.background(C.track)
            ) {
                Box(Modifier.fillMaxWidth(p).fillMaxHeight().background(Color.White))
            }
            Spacer(Modifier.height(7.dp))
            Row(Modifier.width(210.dp).graphicsLayer { alpha = if (prog.value > 0f) 1f else 0f }) {
                Txt(status, 6.2f, C.muted, modifier = Modifier.weight(1f))
                Txt("${(p * 100).toInt()}%", 6.2f, C.text, androidx.compose.ui.text.font.FontWeight.Bold)
            }
        }
    }
}
