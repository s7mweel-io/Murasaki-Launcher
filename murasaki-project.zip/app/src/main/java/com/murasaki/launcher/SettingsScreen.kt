package com.murasaki.launcher

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp

@Composable
fun SettingsScreen(s: LauncherState) {
    Column(Modifier.fillMaxWidth().padding(top = 6.dp, bottom = 12.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Seg(listOf("General", "Cursor"), s.settingsTab, { s.settingsTab = it }, Modifier.width(140.dp))
            Spacer(Modifier.weight(1f))
            Txt("Changes are saved automatically", 5.6f, C.muted)
        }
        Spacer(Modifier.height(8.dp))
        if (s.settingsTab == 0) GeneralTab(s) else CursorTab(s)
    }
}

@Composable
private fun GeneralTab(s: LauncherState) {
    val ctx = LocalContext.current
    val ramGb = remember(ctx) {
        val mi = ActivityManager.MemoryInfo()
        (ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
        Math.round(mi.totalMem / 1073741824.0).toInt()
    }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(15.dp)) {
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            CardBox(Modifier.fillMaxWidth(), "Java") {
                SettingRow("Java runtime") {
                    Picker(Modifier.width(112.dp), listOf("Temurin 8", "Temurin 17", "Temurin 21"), s.javaRuntime, { it }, height = 16) {
                        s.javaRuntime = it; s.save()
                    }
                }
                Txt("JVM arguments", 6.3f, C.sub)
                Spacer(Modifier.height(3.dp))
                TextInput(s.jvmArgs, { s.jvmArgs = it; s.save() }, "-Xss1M", Modifier.fillMaxWidth())
            }
            CardBox(Modifier.fillMaxWidth(), "Game") {
                Txt("Game directory", 6.3f, C.sub)
                Spacer(Modifier.height(3.dp))
                TextInput(s.gameDir, { s.gameDir = it; s.save() }, "/storage/emulated/0/Minecraft", Modifier.fillMaxWidth())
                Spacer(Modifier.height(5.dp))
                Row(Modifier.fillMaxWidth().height(18.dp), verticalAlignment = Alignment.CenterVertically) {
                    Txt("Resolution scale", 6.3f, C.sub, modifier = Modifier.width(90.dp))
                    FlatSlider(s.resScale, { s.resScale = it; s.save() }, Modifier.weight(1f))
                    Txt("${(50 + s.resScale * 50).toInt()}%", 6.4f, C.text, FontWeight.Bold, modifier = Modifier.width(30.dp))
                }
            }
            CardBox(Modifier.fillMaxWidth(), "Controls") {
                SettingRow("Default layout") {
                    Picker(
                        Modifier.width(112.dp), s.controls.layouts.map { it.name },
                        s.controls.layouts[s.controls.defaultIdx.coerceIn(0, s.controls.layouts.lastIndex)].name, { it }, height = 16
                    ) { nm -> s.controls.setDefault(s.controls.layouts.indexOfFirst { l -> l.name == nm }.coerceAtLeast(0)) }
                }
                Row(Modifier.fillMaxWidth().height(21.dp), verticalAlignment = Alignment.CenterVertically) {
                    Txt("Button opacity", 6.3f, C.sub, modifier = Modifier.width(90.dp))
                    FlatSlider(s.btnOpacity, { s.btnOpacity = it; s.save() }, Modifier.weight(1f))
                    Txt("${(s.btnOpacity * 100).toInt()}%", 6.4f, C.text, FontWeight.Bold, modifier = Modifier.width(30.dp))
                }
                SettingRow("Haptic feedback") { Toggle(s.haptic) { s.haptic = it; s.save() } }
                Spacer(Modifier.height(4.dp))
                PrimaryButton("Open control editor", Modifier.fillMaxWidth(), height = 20) { s.editorOpen = true }
            }
        }
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            CardBox(Modifier.fillMaxWidth(), "Memory") {
                Row(Modifier.fillMaxWidth()) {
                    Txt("Allocated memory", 6.3f, C.sub, modifier = Modifier.weight(1f))
                    Txt("${s.memoryMb} MB", 7.2f, C.text, FontWeight.Bold)
                }
                FlatSlider(s.memFrac, { s.memFrac = it; s.save() }, Modifier.fillMaxWidth())
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    listOf("1 GB", "2 GB", "3 GB", "4 GB", "5 GB", "6 GB").forEach { Txt(it, 5f, C.muted) }
                }
                Spacer(Modifier.height(4.dp))
                Txt("Device RAM: $ramGb GB  -  leave about 2 GB free for Android", 5.4f, C.muted)
            }
            CardBox(Modifier.fillMaxWidth(), "Graphics") {
                SettingRow("Renderer") {
                    Picker(Modifier.width(112.dp), listOf("gl4es (fast)", "ANGLE", "Zink (Vulkan)"), s.renderer, { it }, height = 16) {
                        s.renderer = it; s.save()
                    }
                }
                SettingRow("Show FPS overlay") { Toggle(s.showFps) { s.showFps = it; s.save() } }
                SettingRow("Sustained performance mode") { Toggle(s.sustained) { s.sustained = it; s.save() } }
            }
            CardBox(Modifier.fillMaxWidth(), "Launcher") {
                SettingRow("Language") {
                    Picker(Modifier.width(112.dp), listOf("English"), s.language, { it }, height = 16) { s.language = it; s.save() }
                }
                SettingRow("Theme") {
                    Picker(Modifier.width(112.dp), listOf("Dark"), s.theme, { it }, height = 16) { s.theme = it; s.save() }
                }
                SettingRow("Check for updates on start") { Toggle(s.checkUpdates) { s.checkUpdates = it; s.save() } }
            }
            CardBox(Modifier.fillMaxWidth(), "Online services") {
                Txt("CurseForge API key", 6.3f, C.sub)
                Spacer(Modifier.height(3.dp))
                TextInput(s.cfKey, { s.updateCfKey(it) }, "Paste your own key here", Modifier.fillMaxWidth())
                Spacer(Modifier.height(4.dp))
                Txt(
                    if (CurseForge.hasKey()) "Key saved. The CurseForge tab is on." else "No key yet. The CurseForge tab stays off until you add one.",
                    5.6f, if (CurseForge.hasKey()) C.green else C.muted
                )
                Spacer(Modifier.height(5.dp))
                OutlineButton("Get a free key", Modifier.width(90.dp), height = 18) {
                    try { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://console.curseforge.com"))) } catch (e: Exception) { s.toast("Could not open the website") }
                }
                Spacer(Modifier.height(3.dp))
                Txt("Modrinth needs no key.", 5.4f, C.muted)
            }
        }
    }
}

/** Draws one of the four cursor styles centred on [c]; [s] is the cursor size in px. */
fun DrawScope.drawCursor(style: Int, c: Offset, s: Float, custom: androidx.compose.ui.graphics.ImageBitmap?) {
    when (style) {
        0 -> {
            val pts = listOf(0f to 0f, 0f to 1f, 0.25f to 0.78f, 0.42f to 1.18f, 0.58f to 1.1f, 0.41f to 0.72f, 0.74f to 0.72f)
            fun poly(k: Float, col: Color) {
                val p = Path()
                pts.forEachIndexed { i, pt ->
                    val x = c.x + (pt.first - 0.37f) * k * s
                    val y = c.y + (pt.second - 0.59f) * k * s
                    if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
                }
                p.close()
                drawPath(p, col)
            }
            poly(1f, Color(0xFF0A0A0C)); poly(0.84f, Color.White)
        }
        1 -> {
            val w = (s * 0.09f).coerceAtLeast(2f)
            drawLine(Color.White, Offset(c.x - s * 0.55f, c.y), Offset(c.x - s * 0.14f, c.y), w)
            drawLine(Color.White, Offset(c.x + s * 0.14f, c.y), Offset(c.x + s * 0.55f, c.y), w)
            drawLine(Color.White, Offset(c.x, c.y - s * 0.55f), Offset(c.x, c.y - s * 0.14f), w)
            drawLine(Color.White, Offset(c.x, c.y + s * 0.14f), Offset(c.x, c.y + s * 0.55f), w)
        }
        2 -> drawCircle(Color.White, s * 0.16f, c)
        else -> {
            if (custom != null) {
                val sz = (s * 1.4f).toInt().coerceAtLeast(2)
                drawImage(custom, dstOffset = IntOffset((c.x - sz / 2f).toInt(), (c.y - sz / 2f).toInt()), dstSize = IntSize(sz, sz))
            } else {
                drawCircle(Color(0xFFFACC15), s * 0.3f, c, style = Stroke(width = (s * 0.07f).coerceAtLeast(1.5f)))
            }
        }
    }
}

@Composable
private fun CursorTab(s: LauncherState) {
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri -> if (uri != null) s.importCursor(uri) }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        CardBox(Modifier.width(200.dp).height(254.dp)) {
            Canvas(Modifier.fillMaxWidth().weight(1f).clip(R5).background(C.panel)) {
                val step = 12.dp.toPx()
                var gx = step / 2
                while (gx < size.width) {
                    var gy = step / 2
                    while (gy < size.height) { drawCircle(Color(0xFF222226), 0.6.dp.toPx(), Offset(gx, gy)); gy += step }
                    gx += step
                }
                drawCursor(s.cursorStyle, Offset(size.width / 2f, size.height / 2f), (10f + s.cursorSize * 26f).dp.toPx(), s.customCursor?.asImageBitmap())
            }
            Spacer(Modifier.height(5.dp))
            Txt("Preview  -  ${(50 + s.cursorSize * 150).toInt()}%", 5.6f, C.muted, modifier = Modifier.align(Alignment.CenterHorizontally))
        }
        CardBox(Modifier.weight(1f).height(254.dp), "Cursor") {
            Row(Modifier.fillMaxWidth()) {
                Txt("Cursor size", 6.4f, C.sub, modifier = Modifier.weight(1f))
                Txt("${(50 + s.cursorSize * 150).toInt()}%", 7f, C.text, FontWeight.Bold)
            }
            FlatSlider(s.cursorSize, { s.cursorSize = it; s.save() }, Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth()) {
                Txt("Sensitivity", 6.4f, C.sub, modifier = Modifier.weight(1f))
                Txt("${(s.cursorSens * 100).toInt()}%", 7f, C.text, FontWeight.Bold)
            }
            FlatSlider(s.cursorSens, { s.cursorSens = it; s.save() }, Modifier.fillMaxWidth())
            Spacer(Modifier.height(9.dp))
            Txt("Cursor style", 6.4f, C.sub)
            Spacer(Modifier.height(4.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Arrow", "Crosshair", "Dot", "Custom").forEachIndexed { i, nm ->
                    val sel = i == s.cursorStyle
                    Column(
                        Modifier.weight(1f).height(46.dp).clip(R6).background(Color(0xFF141418))
                            .border(if (sel) 1.3.dp else 1.dp, if (sel) Color.White else C.border, R6)
                            .clickable { s.cursorStyle = i; s.save() },
                        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
                    ) {
                        Canvas(Modifier.size(24.dp, 22.dp)) {
                            drawCursor(i, Offset(size.width / 2f, size.height / 2f), 14.dp.toPx(), s.customCursor?.asImageBitmap())
                        }
                        Spacer(Modifier.height(2.dp))
                        Txt(nm, 5.6f, if (sel) C.text else C.muted)
                    }
                }
            }
            Spacer(Modifier.height(9.dp))
            OutlineButton("Import your own cursor (PNG)", Modifier.fillMaxWidth(), icon = Icons.Default.Add) { pick.launch("image/*") }
            Spacer(Modifier.height(4.dp))
            Row(Modifier.fillMaxWidth()) {
                Txt("Transparent PNG, up to 128 x 128 px", 5.4f, C.muted, modifier = Modifier.weight(1f))
                Txt(
                    "Reset to default", 5.8f, C.sub,
                    modifier = Modifier.clickable { s.cursorSize = 0.5f; s.cursorSens = 0.6f; s.cursorStyle = 0; s.save() }
                )
            }
        }
    }
}
