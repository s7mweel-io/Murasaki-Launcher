package com.murasaki.launcher

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.zip.ZipFile

data class InstalledItem(
    val type: String, val fileName: String, val enabled: Boolean, val sizeKb: Long, val title: String, val iconUrl: String?
)
data class PackResult(val inst: Instance, val skipped: List<String>)

class Installer(private val ctx: Context) {

    fun root(): File = File(ctx.getExternalFilesDir(null) ?: ctx.filesDir, "Minecraft/instances")
    fun dir(inst: Instance): File {
        val d = File(root(), if (inst.dir.isEmpty()) slug(inst.title) else inst.dir)
        d.mkdirs()
        return d
    }
    fun folderName(type: String): String = when (type) {
        "resourcepack" -> "resourcepacks"
        "shader" -> "shaderpacks"
        else -> "mods"
    }

    // ------------------------------------------------------------ installed list (with a small info file)
    private fun metaFile(inst: Instance) = File(dir(inst), "murasaki_installed.json")
    private fun readMeta(inst: Instance): JSONArray =
        try { JSONArray(metaFile(inst).readText()) } catch (e: Exception) { JSONArray() }

    private fun record(inst: Instance, type: String, title: String, iconUrl: String?, fileName: String) {
        val old = readMeta(inst)
        val out = JSONArray()
        for (i in 0 until old.length()) {
            val o = old.getJSONObject(i)
            if (!(o.optString("file") == fileName && o.optString("type") == type)) out.put(o)
        }
        out.put(JSONObject().put("type", type).put("file", fileName).put("title", title).put("icon", iconUrl ?: ""))
        metaFile(inst).writeText(out.toString())
    }

    fun installFile(inst: Instance, p: Project, v: FileVer, onProgress: (Float) -> Unit) {
        val url = v.url ?: throw IllegalStateException("This file can only be downloaded from the website")
        val dest = File(File(dir(inst), folderName(p.type)), v.fileName)
        Net.download(url, dest) { d, t -> if (t > 0) onProgress(d.toFloat() / t.toFloat()) }
        record(inst, p.type, p.title, p.iconUrl, v.fileName)
    }

    fun listInstalled(inst: Instance): List<InstalledItem> {
        val meta = readMeta(inst)
        val out = ArrayList<InstalledItem>()
        for (type in listOf("mod", "resourcepack", "shader")) {
            val files = File(dir(inst), folderName(type)).listFiles() ?: continue
            for (f in files.sortedBy { it.name.lowercase() }) {
                if (!f.isFile) continue
                val enabled = !f.name.endsWith(".disabled")
                val real = f.name.removeSuffix(".disabled")
                var title = real
                var icon: String? = null
                for (i in 0 until meta.length()) {
                    val o = meta.getJSONObject(i)
                    if (o.optString("file") == real && o.optString("type") == type) {
                        title = o.optString("title", real)
                        icon = o.optString("icon", "").ifEmpty { null }
                    }
                }
                out.add(InstalledItem(type, real, enabled, f.length() / 1024, title, icon))
            }
        }
        return out
    }

    fun setEnabled(inst: Instance, item: InstalledItem, enable: Boolean) {
        val base = File(dir(inst), folderName(item.type))
        val on = File(base, item.fileName)
        val off = File(base, item.fileName + ".disabled")
        if (enable && off.exists()) off.renameTo(on)
        if (!enable && on.exists()) on.renameTo(off)
    }

    fun remove(inst: Instance, item: InstalledItem) {
        val base = File(dir(inst), folderName(item.type))
        File(base, item.fileName).delete()
        File(base, item.fileName + ".disabled").delete()
    }

    fun deleteInstanceFiles(inst: Instance) {
        dir(inst).deleteRecursively()
    }

    // ------------------------------------------------------------ options.txt
    fun readOptions(inst: Instance): Map<String, String> {
        val f = File(dir(inst), "options.txt")
        val m = LinkedHashMap<String, String>()
        if (f.exists()) {
            for (line in f.readLines()) {
                val i = line.indexOf(':')
                if (i > 0) m[line.substring(0, i)] = line.substring(i + 1)
            }
        }
        return m
    }

    fun writeOption(inst: Instance, key: String, value: String) {
        val f = File(dir(inst), "options.txt")
        val lines = if (f.exists()) f.readLines().toMutableList() else mutableListOf<String>()
        var found = false
        for (i in lines.indices) {
            if (lines[i].startsWith("$key:")) { lines[i] = "$key:$value"; found = true }
        }
        if (!found) lines.add("$key:$value")
        f.writeText(lines.joinToString("\n") + "\n")
    }

    // ------------------------------------------------------------ modpacks
    private fun safeFile(base: File, rel: String): File {
        val f = File(base, rel).canonicalFile
        if (!f.path.startsWith(base.canonicalPath)) throw IllegalStateException("Unsafe path in modpack: $rel")
        return f
    }

    private fun newInstance(name: String, mc: String, loader: String?, iconUrl: String?): Instance {
        val dirName = slug(name) + "-" + (System.currentTimeMillis() % 100000)
        var custom: String? = null
        if (iconUrl != null) {
            try {
                val f = File(File(root(), dirName), "icon.png")
                Net.download(iconUrl, f)
                custom = f.path
            } catch (e: Exception) { custom = null }
        }
        return Instance(name, mc + (if (loader != null) "  -  $loader" else ""), mc, loader, "log", custom, dirName)
    }

    private fun extractOverrides(zf: ZipFile, base: File, prefixes: List<String>) {
        val entries = zf.entries()
        while (entries.hasMoreElements()) {
            val e = entries.nextElement()
            if (e.isDirectory) continue
            for (pre in prefixes) {
                if (e.name.startsWith(pre)) {
                    val dest = safeFile(base, e.name.removePrefix(pre))
                    dest.parentFile?.mkdirs()
                    zf.getInputStream(e).use { input -> dest.outputStream().use { out -> input.copyTo(out) } }
                }
            }
        }
    }

    private fun loaderFromId(id: String): String? = when (id.substringBefore('-').lowercase()) {
        "forge" -> "Forge"
        "fabric" -> "Fabric"
        "neoforge" -> "NeoForge"
        "quilt" -> "Quilt"
        else -> null
    }

    fun installPackFile(zipFile: File, iconUrl: String?, update: (Float, String) -> Unit): PackResult {
        ZipFile(zipFile).use { zf ->
            val idx = zf.getEntry("modrinth.index.json")
            if (idx != null) return installMrpack(zf, idx.name, iconUrl, update)
            val man = zf.getEntry("manifest.json")
            if (man != null) return installCfPack(zf, man.name, iconUrl, update)
        }
        throw IllegalStateException("This file is not a Modrinth or CurseForge modpack")
    }

    private fun installMrpack(zf: ZipFile, entry: String, iconUrl: String?, update: (Float, String) -> Unit): PackResult {
        val o = JSONObject(zf.getInputStream(zf.getEntry(entry)).bufferedReader().use { it.readText() })
        val name = o.optString("name", "Modpack")
        val deps = o.optJSONObject("dependencies") ?: JSONObject()
        val mc = deps.optString("minecraft", "")
        val loader = when {
            deps.has("fabric-loader") -> "Fabric"
            deps.has("quilt-loader") -> "Quilt"
            deps.has("neoforge") -> "NeoForge"
            deps.has("forge") -> "Forge"
            else -> null
        }
        val inst = newInstance(name, mc, loader, iconUrl)
        val base = dir(inst)
        val files = o.optJSONArray("files") ?: JSONArray()
        val skipped = ArrayList<String>()
        for (i in 0 until files.length()) {
            val f = files.getJSONObject(i)
            val path = f.getString("path")
            val env = f.optJSONObject("env")
            if (env != null && env.optString("client", "required") == "unsupported") continue
            val dest = safeFile(base, path)
            update(0.9f * i / files.length().coerceAtLeast(1), "Downloading " + dest.name)
            val urls = f.getJSONArray("downloads")
            var ok = false
            for (u in 0 until urls.length()) {
                if (ok) break
                try { Net.download(urls.getString(u), dest); ok = true } catch (e: Exception) { ok = false }
            }
            if (!ok) skipped.add(dest.name)
        }
        update(0.95f, "Copying pack settings")
        extractOverrides(zf, base, listOf("overrides/", "client-overrides/"))
        return PackResult(inst, skipped)
    }

    private fun installCfPack(zf: ZipFile, entry: String, iconUrl: String?, update: (Float, String) -> Unit): PackResult {
        if (!CurseForge.hasKey()) throw IllegalStateException("CurseForge modpacks need a CurseForge API key (Settings)")
        val o = JSONObject(zf.getInputStream(zf.getEntry(entry)).bufferedReader().use { it.readText() })
        val name = o.optString("name", "Modpack")
        val mcObj = o.getJSONObject("minecraft")
        val mc = mcObj.optString("version", "")
        var loader: String? = null
        val ml = mcObj.optJSONArray("modLoaders")
        if (ml != null && ml.length() > 0) {
            var pick = ml.getJSONObject(0)
            for (i in 0 until ml.length()) if (ml.getJSONObject(i).optBoolean("primary", false)) pick = ml.getJSONObject(i)
            loader = loaderFromId(pick.optString("id", ""))
        }
        val inst = newInstance(name, mc, loader, iconUrl)
        val base = dir(inst)
        val files = o.optJSONArray("files") ?: JSONArray()
        val fileIds = ArrayList<String>()
        val projectIds = ArrayList<String>()
        for (i in 0 until files.length()) {
            val f = files.getJSONObject(i)
            fileIds.add(f.getLong("fileID").toString())
            projectIds.add(f.getLong("projectID").toString())
        }
        update(0.05f, "Reading the modpack list")
        val infos = CurseForge.filesByIds(fileIds)
        val classOf = HashMap<Long, Int>()
        for (m in CurseForge.modsByIds(projectIds.distinct())) classOf[m.getLong("id")] = m.optInt("classId", 6)
        val skipped = ArrayList<String>()
        for ((n, info) in infos.withIndex()) {
            val fileName = info.optString("fileName", "file")
            update(0.1f + 0.85f * n / infos.size.coerceAtLeast(1), "Downloading $fileName")
            val url = if (info.isNull("downloadUrl")) "" else info.optString("downloadUrl", "")
            if (url.isEmpty()) { skipped.add(fileName); continue }
            val cls = classOf[info.optLong("modId")] ?: 6
            val folder = when (cls) { 12 -> "resourcepacks"; 6552 -> "shaderpacks"; else -> "mods" }
            try { Net.download(url, File(File(base, folder), fileName)) } catch (e: Exception) { skipped.add(fileName) }
        }
        update(0.97f, "Copying pack settings")
        val over = o.optString("overrides", "overrides")
        extractOverrides(zf, base, listOf("$over/"))
        return PackResult(inst, skipped)
    }
}
