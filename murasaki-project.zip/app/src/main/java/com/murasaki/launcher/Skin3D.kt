package com.murasaki.launcher

import android.graphics.Bitmap
import android.graphics.Canvas as AndroidCanvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Rect
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin
import kotlin.math.sqrt

/** Small software 3D renderer for a Minecraft-style character (skin atlas 64x64, cape atlas 64x32). */
object Skin3D {
    private class Part(
        val box: FloatArray, val w: Int, val h: Int, val d: Int,
        val bx: Int, val by: Int, val ox: Int, val oy: Int, val e: Float,
        val pivot: FloatArray?, val sign: Float
    )
    private val PARTS = listOf(
        Part(floatArrayOf(-4f, 4f, 24f, 32f, -4f, 4f), 8, 8, 8, 0, 0, 32, 0, 0.5f, null, 0f),
        Part(floatArrayOf(-4f, 4f, 12f, 24f, -2f, 2f), 8, 12, 4, 16, 16, 16, 32, 0.25f, null, 0f),
        Part(floatArrayOf(-8f, -4f, 12f, 24f, -2f, 2f), 4, 12, 4, 40, 16, 40, 32, 0.25f, floatArrayOf(-6f, 22f, 0f), 1f),
        Part(floatArrayOf(4f, 8f, 12f, 24f, -2f, 2f), 4, 12, 4, 32, 48, 48, 48, 0.25f, floatArrayOf(6f, 22f, 0f), -1f),
        Part(floatArrayOf(-4f, 0f, 0f, 12f, -2f, 2f), 4, 12, 4, 0, 16, 0, 32, 0.25f, floatArrayOf(-2f, 12f, 0f), -1f),
        Part(floatArrayOf(0f, 4f, 0f, 12f, -2f, 2f), 4, 12, 4, 16, 48, 0, 48, 0.25f, floatArrayOf(2f, 12f, 0f), 1f)
    )
    private val FACES = listOf("front", "back", "right", "left", "top")

    private class Item(
        val depth: Float, val bmp: Bitmap, val rect: IntArray, val shade: Float,
        val p0x: Float, val p0y: Float, val ux: Float, val uy: Float, val vx: Float, val vy: Float
    )

    private fun uv(name: String, w: Int, h: Int, d: Int, ox: Int, oy: Int): IntArray = when (name) {
        "top" -> intArrayOf(ox + d, oy, w, d)
        "right" -> intArrayOf(ox, oy + d, d, h)
        "front" -> intArrayOf(ox + d, oy + d, w, h)
        "left" -> intArrayOf(ox + d + w, oy + d, d, h)
        else -> intArrayOf(ox + 2 * d + w, oy + d, w, h)
    }

    private fun face(name: String, b: FloatArray, e: Float): Array<FloatArray> {
        val x0 = b[0] - e; val x1 = b[1] + e; val y0 = b[2] - e; val y1 = b[3] + e; val z0 = b[4] - e; val z1 = b[5] + e
        val w = x1 - x0; val h = y1 - y0; val d = z1 - z0
        return when (name) {
            "front" -> arrayOf(floatArrayOf(x0, y1, z1), floatArrayOf(w, 0f, 0f), floatArrayOf(0f, -h, 0f), floatArrayOf(0f, 0f, 1f))
            "back" -> arrayOf(floatArrayOf(x1, y1, z0), floatArrayOf(-w, 0f, 0f), floatArrayOf(0f, -h, 0f), floatArrayOf(0f, 0f, -1f))
            "right" -> arrayOf(floatArrayOf(x0, y1, z0), floatArrayOf(0f, 0f, d), floatArrayOf(0f, -h, 0f), floatArrayOf(-1f, 0f, 0f))
            "left" -> arrayOf(floatArrayOf(x1, y1, z1), floatArrayOf(0f, 0f, -d), floatArrayOf(0f, -h, 0f), floatArrayOf(1f, 0f, 0f))
            else -> arrayOf(floatArrayOf(x0, y1, z0), floatArrayOf(w, 0f, 0f), floatArrayOf(0f, 0f, d), floatArrayOf(0f, 1f, 0f))
        }
    }

    private fun rotY(a: Double): Array<FloatArray> {
        val c = cos(a).toFloat(); val s = sin(a).toFloat()
        return arrayOf(floatArrayOf(c, 0f, s), floatArrayOf(0f, 1f, 0f), floatArrayOf(-s, 0f, c))
    }
    private fun rotX(a: Double): Array<FloatArray> {
        val c = cos(a).toFloat(); val s = sin(a).toFloat()
        return arrayOf(floatArrayOf(1f, 0f, 0f), floatArrayOf(0f, c, -s), floatArrayOf(0f, s, c))
    }
    private fun mul(a: Array<FloatArray>, b: Array<FloatArray>): Array<FloatArray> =
        Array(3) { i -> FloatArray(3) { j -> a[i][0] * b[0][j] + a[i][1] * b[1][j] + a[i][2] * b[2][j] } }
    private fun xform(m: Array<FloatArray>, v: FloatArray): FloatArray =
        floatArrayOf(
            m[0][0] * v[0] + m[0][1] * v[1] + m[0][2] * v[2],
            m[1][0] * v[0] + m[1][1] * v[1] + m[1][2] * v[2],
            m[2][0] * v[0] + m[2][1] * v[1] + m[2][2] * v[2]
        )

    private val paint = Paint().apply { isFilterBitmap = false; isAntiAlias = true }
    private val cm = ColorMatrix()
    private val mat = Matrix()
    private val src = FloatArray(6)
    private val dst = FloatArray(6)

    fun draw(
        canvas: AndroidCanvas, skin: Bitmap, cape: Bitmap?, angleDeg: Float, pitchDeg: Float,
        cx: Float, cy: Float, scale: Float, walking: Boolean = false, phase: Float = 0f
    ) {
        val r = mul(rotX(Math.toRadians(pitchDeg.toDouble())), rotY(Math.toRadians(angleDeg.toDouble())))
        val lx = -0.35f; val ly = 0.75f; val lz = 0.55f
        val ln = sqrt(lx * lx + ly * ly + lz * lz)
        val items = ArrayList<Item>()

        fun add(bmp: Bitmap, rect: IntArray, f: Array<FloatArray>, bias: Float, tilt: Array<FloatArray>?, pivot: FloatArray?) {
            var p0 = f[0]; var u = f[1]; var v = f[2]; var n = f[3]
            if (tilt != null && pivot != null) {
                val rel = floatArrayOf(p0[0] - pivot[0], p0[1] - pivot[1], p0[2] - pivot[2])
                val t = xform(tilt, rel)
                p0 = floatArrayOf(t[0] + pivot[0], t[1] + pivot[1], t[2] + pivot[2])
                u = xform(tilt, u); v = xform(tilt, v); n = xform(tilt, n)
            }
            val nr = xform(r, n)
            if (nr[2] <= 0.03f) return
            val shade = 0.58f + 0.42f * max(0f, (nr[0] * lx + nr[1] * ly + nr[2] * lz) / ln)
            val q0 = xform(r, p0); val qu = xform(r, u); val qv = xform(r, v)
            val cz = q0[2] + qu[2] / 2f + qv[2] / 2f
            items.add(
                Item(
                    cz + bias, bmp, rect, shade,
                    cx + q0[0] * scale, cy - (q0[1] - 16f) * scale,
                    qu[0] * scale, -qu[1] * scale, qv[0] * scale, -qv[1] * scale
                )
            )
        }

        for (p in PARTS) {
            var tilt: Array<FloatArray>? = null
            if (p.pivot != null) {
                val amp = if (walking) 38.0 else 3.5
                tilt = rotX(Math.toRadians(p.sign * amp * sin(phase.toDouble())))
            }
            for (fn in FACES) {
                add(skin, uv(fn, p.w, p.h, p.d, p.bx, p.by), face(fn, p.box, 0f), 0f, tilt, p.pivot)
                add(skin, uv(fn, p.w, p.h, p.d, p.ox, p.oy), face(fn, p.box, p.e), 0.35f, tilt, p.pivot)
            }
        }
        if (cape != null) {
            val box = floatArrayOf(-5f, 5f, 8f, 24f, -3.05f, -2.05f)
            val capeAngle = 7.0 + (if (walking) 9.0 * (0.5 + 0.5 * sin(phase * 2.0)) else 1.5 * sin(phase * 0.8))
            val tilt = rotX(Math.toRadians(capeAngle))
            val pivot = floatArrayOf(0f, 24f, -2.5f)
            val pairs = listOf("back" to "front", "front" to "back", "top" to "top", "right" to "right", "left" to "left")
            for ((fn, uvName) in pairs) {
                add(cape, uv(uvName, 10, 16, 1, 0, 0), face(fn, box, 0f), -0.1f, tilt, pivot)
            }
        }
        items.sortBy { it.depth }
        for (item in items) {
            val tw = item.rect[2]; val th = item.rect[3]
            src[0] = 0f; src[1] = 0f; src[2] = tw.toFloat(); src[3] = 0f; src[4] = 0f; src[5] = th.toFloat()
            dst[0] = item.p0x; dst[1] = item.p0y
            dst[2] = item.p0x + item.ux; dst[3] = item.p0y + item.uy
            dst[4] = item.p0x + item.vx; dst[5] = item.p0y + item.vy
            mat.setPolyToPoly(src, 0, dst, 0, 3)
            canvas.save()
            canvas.concat(mat)
            cm.setScale(item.shade, item.shade, item.shade, 1f)
            paint.colorFilter = ColorMatrixColorFilter(cm)
            canvas.drawBitmap(item.bmp, Rect(item.rect[0], item.rect[1], item.rect[0] + tw, item.rect[1] + th), Rect(0, 0, tw, th), paint)
            canvas.restore()
        }
    }

    /** Makes any skin image a 64x64 atlas (handles old 64x32 skins and HD skins). */
    fun normalizeSkin(srcBmp: Bitmap): Bitmap {
        val b = if (srcBmp.width != 64) Bitmap.createScaledBitmap(srcBmp, 64, (srcBmp.height * 64f / srcBmp.width).toInt().coerceAtLeast(1), false) else srcBmp
        if (b.height == 64) return b
        val out = Bitmap.createBitmap(64, 64, Bitmap.Config.ARGB_8888)
        val c = AndroidCanvas(out)
        c.drawBitmap(b, 0f, 0f, null)
        if (b.height == 32) {
            val flip = Matrix().apply { preScale(-1f, 1f) }
            val leg = Bitmap.createBitmap(b, 0, 16, 16, 16, flip, false)
            val arm = Bitmap.createBitmap(b, 40, 16, 16, 16, flip, false)
            c.drawBitmap(leg, 16f, 48f, null)
            c.drawBitmap(arm, 32f, 48f, null)
        }
        return out
    }

    fun normalizeCape(srcBmp: Bitmap): Bitmap =
        if (srcBmp.width == 64 && srcBmp.height == 32) srcBmp else Bitmap.createScaledBitmap(srcBmp, 64, 32, false)
}

@Composable
fun SkinPreview(skin: Bitmap, cape: Bitmap?, walking: Boolean, modifier: Modifier = Modifier) {
    var yaw by remember { mutableStateOf(25f) }
    var pitch by remember { mutableStateOf(12f) }
    var zoom by remember { mutableStateOf(1f) }
    var phase by remember { mutableStateOf(0f) }
    var lastTouch by remember { mutableStateOf(0L) }
    val walkingNow by rememberUpdatedState(walking)
    LaunchedEffect(Unit) {
        var last = 0L
        while (true) {
            withFrameNanos { now ->
                if (last != 0L) {
                    val dt = (now - last) / 1_000_000_000f
                    phase += dt * (if (walkingNow) 7f else 1.6f)
                    if (System.nanoTime() - lastTouch > 2_500_000_000L) yaw += dt * 35f
                }
                last = now
            }
        }
    }
    Canvas(
        modifier.pointerInput(Unit) {
            detectTransformGestures { _, pan, zoomChange, _ ->
                yaw += pan.x * 0.45f
                pitch = (pitch - pan.y * 0.3f).coerceIn(-60f, 60f)
                zoom = (zoom * zoomChange).coerceIn(0.6f, 2.6f)
                lastTouch = System.nanoTime()
            }
        }
    ) {
        drawIntoCanvas { c ->
            Skin3D.draw(c.nativeCanvas, skin, cape, yaw, pitch, size.width / 2f, size.height / 2f, size.height / 40f * zoom, walking, phase)
        }
    }
}
