package com.murasaki.launcher

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

@Composable
fun LoginScreen(s: LauncherState) {
    var name by remember { mutableStateOf("") }
    Box(Modifier.fillMaxSize().background(C.bg).displayCutoutPadding(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Image(painterResource(R.drawable.logo_wordmark), null, Modifier.width(200.dp).aspectRatio(10.17f))
            Spacer(Modifier.height(3.dp))
            Image(painterResource(R.drawable.logo_launcher_band), null, Modifier.width(140.dp).aspectRatio(18.25f))
            Spacer(Modifier.height(14.dp))
            Txt("Sign in to play", 11f, C.text, FontWeight.Bold)
            Spacer(Modifier.height(3.dp))
            Txt("You need an account before the game can start.", 6.6f, C.muted)
            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                CardBox(Modifier.width(250.dp), "Microsoft account") {
                    Txt("Play on online servers and change your skin and cape. You will be taken to Microsoft's own sign-in page.", 6.2f, C.sub)
                    Spacer(Modifier.height(10.dp))
                    PrimaryButton("Sign in with Microsoft", Modifier.fillMaxWidth(), height = 24) {
                        s.toast("Microsoft sign-in is coming in the next update. Use a local account for now.")
                    }
                }
                CardBox(Modifier.width(250.dp), "Local account") {
                    Txt("Username", 5.9f, C.muted)
                    Spacer(Modifier.height(3.dp))
                    TextInput(name, { name = it }, "Steve", Modifier.fillMaxWidth())
                    Spacer(Modifier.height(4.dp))
                    Txt("3 to 16 letters, numbers or _. Works offline and in single-player. Online servers need a Microsoft account.", 5.4f, C.muted)
                    Spacer(Modifier.height(8.dp))
                    PrimaryButton("Continue", Modifier.fillMaxWidth(), height = 24) { s.addLocalAccount(name) }
                }
            }
            Spacer(Modifier.height(12.dp))
            Txt("*Not an official Minecraft product. Not approved by or associated with Mojang or Microsoft.", 4.9f, Color(0xFF787880))
        }
    }
}
