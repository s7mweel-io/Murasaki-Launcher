package com.murasaki.launcher

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

@Composable
fun SkinsScreen(s: LauncherState) {
    val skinPick = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri -> if (uri != null) s.importSkin(uri) }
    val capePick = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri -> if (uri != null) s.importCape(uri) }
    var skinUser by remember { mutableStateOf("") }
    var capeUser by remember { mutableStateOf("") }
    Column(Modifier.fillMaxWidth().padding(top = 4.dp, bottom = 12.dp)) {
        Txt("Skins & Capes", 11f, C.text, FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth().height(262.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Box(Modifier.width(212.dp).fillMaxHeight().clip(R6).background(C.card).border(1.dp, C.border, R6)) {
                SkinPreview(s.skin, s.cape, Modifier.fillMaxSize())
            }
            Column(Modifier.weight(1f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                CardBox(Modifier.fillMaxWidth(), "Skin") {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        TextInput(skinUser, { skinUser = it }, "Minecraft username", Modifier.weight(1f))
                        PrimaryButton(if (s.skinBusy) "Fetching..." else "Fetch skin", Modifier.width(98.dp), enabled = !s.skinBusy) { s.fetchSkin(skinUser) }
                    }
                    Spacer(Modifier.height(6.dp))
                    OutlineButton("Import skin file (.png)", Modifier.fillMaxWidth(), icon = Icons.Default.Add) { skinPick.launch("image/*") }
                }
                CardBox(Modifier.fillMaxWidth(), "Cape") {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        TextInput(capeUser, { capeUser = it }, "Minecraft username", Modifier.weight(1f))
                        PrimaryButton(if (s.capeBusy) "Fetching..." else "Fetch cape", Modifier.width(98.dp), enabled = !s.capeBusy) { s.fetchCape(capeUser) }
                    }
                    Spacer(Modifier.height(6.dp))
                    OutlineButton("Import cape file (.png)", Modifier.fillMaxWidth(), icon = Icons.Default.Add) { capePick.launch("image/*") }
                }
                Spacer(Modifier.weight(1f))
                PrimaryButton("Apply to my account", Modifier.width(152.dp).align(Alignment.End), height = 26) {
                    s.toast("Sign in with a Microsoft account first (coming in the next step)")
                }
            }
        }
    }
}
