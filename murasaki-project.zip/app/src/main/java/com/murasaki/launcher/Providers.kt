package com.murasaki.launcher

import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder

data class Project(
    val source: String,
    val id: String,
    val type: String,
    val title: String,
    val author: String,
    val description: String,
    val iconUrl: String?,
    val downloads: Long,
    val slug: String,
    val gallery: List<String> = emptyList(),
    val webUrl: String = ""
)

data class FileVer(
    val id: String,
    val label: String,
    val fileName: String,
    val url: String?,
    val gameVersions: List<String>,
    val loaders: List<String>,
    val requiredDeps: List<String>,
    val date: String = ""
)

private fun enc(s: String): String = URLEncoder.encode(s, "UTF-8")
private fun JSONObject.strOrNull(k: String): String? = if (has(k) && !isNull(k)) getString(k) else null
private fun JSONArray.strings(): List<String> = (0 until length()).map { getString(it) }

val SORT_LABELS = listOf("Relevance", "Downloads", "Recently updated", "Newest")
val MODRINTH_SORTS = listOf("relevance", "downloads", "updated", "newest")
val CF_SORTS = listOf(2, 6, 3, 11)

object Modrinth {
    private const val BASE = "https://api.modrinth.com/v2"

    fun typeName(tab: Int): String = when (tab) {
        0 -> "mod"
        1 -> "resourcepack"
        2 -> "shader"
        else -> "modpack"
    }

    fun search(tab: Int, query: String, mc: String?, loader: String?, sort: String, offset: Int): List<Project> {
        val facets = JSONArray()
        facets.put(JSONArray().put("project_type:" + typeName(tab)))
        if (mc != null) facets.put(JSONArray().put("versions:$mc"))
        if (loader != null && (tab == 0 || tab == 3)) facets.put(JSONArray().put("categories:" + loader.lowercase()))
        val url = BASE + "/search?query=" + enc(query) + "&facets=" + enc(facets.toString()) +
            "&index=" + sort + "&limit=20&offset=" + offset
        val hits = JSONObject(Net.get(url)).getJSONArray("hits")
        return (0 until hits.length()).map { i ->
            val h = hits.getJSONObject(i)
            val slug = h.optString("slug", h.getString("project_id"))
            Project(
                "modrinth", h.getString("project_id"), typeName(tab), h.getString("title"), h.optString("author", ""),
                h.optString("description", ""), h.strOrNull("icon_url"), h.optLong("downloads", 0L), slug,
                h.optJSONArray("gallery")?.strings() ?: emptyList(),
                "https://modrinth.com/" + typeName(tab) + "/" + slug
            )
        }
    }

    fun project(id: String): Project {
        val h = JSONObject(Net.get("$BASE/project/$id"))
        val type = h.optString("project_type", "mod")
        val slug = h.optString("slug", id)
        return Project(
            "modrinth", h.getString("id"), type, h.getString("title"), "", h.optString("description", ""),
            h.strOrNull("icon_url"), h.optLong("downloads", 0L), slug, emptyList(), "https://modrinth.com/$type/$slug"
        )
    }

    fun versions(id: String, mc: String?, loader: String?, useLoader: Boolean): List<FileVer> {
        var url = "$BASE/project/$id/version"
        val q = ArrayList<String>()
        if (mc != null) q.add("game_versions=" + enc(JSONArray().put(mc).toString()))
        if (loader != null && useLoader) q.add("loaders=" + enc(JSONArray().put(loader.lowercase()).toString()))
        if (q.isNotEmpty()) url += "?" + q.joinToString("&")
        val arr = JSONArray(Net.get(url))
        val out = ArrayList<FileVer>()
        for (i in 0 until arr.length()) {
            val v = arr.getJSONObject(i)
            val files = v.getJSONArray("files")
            if (files.length() == 0) continue
            var f = files.getJSONObject(0)
            for (j in 0 until files.length()) {
                if (files.getJSONObject(j).optBoolean("primary", false)) f = files.getJSONObject(j)
            }
            val deps = ArrayList<String>()
            val d = v.optJSONArray("dependencies")
            if (d != null) {
                for (j in 0 until d.length()) {
                    val o = d.getJSONObject(j)
                    if (o.optString("dependency_type") == "required" && !o.isNull("project_id")) deps.add(o.getString("project_id"))
                }
            }
            out.add(
                FileVer(
                    v.getString("id"), v.optString("version_number", v.optString("name", "")), f.getString("filename"),
                    f.getString("url"), v.getJSONArray("game_versions").strings(), v.getJSONArray("loaders").strings(),
                    deps, v.optString("date_published", "")
                )
            )
        }
        return out
    }
}

object CurseForge {
    private const val BASE = "https://api.curseforge.com/v1"
    private const val GAME = 432
    var apiKey: String = ""

    fun hasKey(): Boolean = apiKey.isNotBlank()
    private fun headers(): Map<String, String> = mapOf("x-api-key" to apiKey)

    fun classId(tab: Int): Int = when (tab) {
        0 -> 6
        1 -> 12
        2 -> 6552
        else -> 4471
    }

    private fun typeOfClass(c: Int): String = when (c) {
        12 -> "resourcepack"
        6552 -> "shader"
        4471 -> "modpack"
        else -> "mod"
    }

    fun loaderCode(l: String?): Int? = when (l?.lowercase()) {
        "forge" -> 1
        "fabric" -> 4
        "quilt" -> 5
        "neoforge" -> 6
        else -> null
    }

    fun search(tab: Int, query: String, mc: String?, loader: String?, sortField: Int, offset: Int): List<Project> {
        var url = BASE + "/mods/search?gameId=" + GAME + "&classId=" + classId(tab) + "&searchFilter=" + enc(query) +
            "&sortField=" + sortField + "&sortOrder=desc&pageSize=20&index=" + offset
        if (mc != null) url += "&gameVersion=" + enc(mc)
        val lc = loaderCode(loader)
        if (lc != null && (tab == 0 || tab == 3)) url += "&modLoaderType=$lc"
        val data = JSONObject(Net.get(url, headers())).getJSONArray("data")
        return (0 until data.length()).map { toProject(data.getJSONObject(it)) }
    }

    fun toProject(o: JSONObject): Project {
        val logo = o.optJSONObject("logo")
        val authors = o.optJSONArray("authors")
        val shots = o.optJSONArray("screenshots")
        val g = ArrayList<String>()
        if (shots != null) for (i in 0 until shots.length()) g.add(shots.getJSONObject(i).getString("url"))
        val icon = logo?.optString("thumbnailUrl")?.takeIf { it.isNotEmpty() }
        val author = if (authors != null && authors.length() > 0) authors.getJSONObject(0).getString("name") else ""
        return Project(
            "curseforge", o.getLong("id").toString(), typeOfClass(o.optInt("classId", 6)), o.getString("name"), author,
            o.optString("summary", ""), icon, o.optLong("downloadCount", 0L), o.optString("slug", ""), g,
            o.optJSONObject("links")?.optString("websiteUrl") ?: ""
        )
    }

    fun project(id: String): Project = toProject(JSONObject(Net.get("$BASE/mods/$id", headers())).getJSONObject("data"))

    fun fileOf(f: JSONObject): FileVer {
        val deps = ArrayList<String>()
        val d = f.optJSONArray("dependencies")
        if (d != null) {
            for (j in 0 until d.length()) {
                val o = d.getJSONObject(j)
                if (o.optInt("relationType") == 3) deps.add(o.getLong("modId").toString())
            }
        }
        val gv = f.optJSONArray("gameVersions")?.strings() ?: emptyList()
        val url = if (f.isNull("downloadUrl")) null else f.optString("downloadUrl").ifEmpty { null }
        return FileVer(
            f.getLong("id").toString(), f.optString("displayName", f.optString("fileName", "")), f.getString("fileName"),
            url, gv, emptyList(), deps, f.optString("fileDate", "")
        )
    }

    fun files(modId: String, mc: String?, loader: String?, useLoader: Boolean): List<FileVer> {
        var url = "$BASE/mods/$modId/files?pageSize=30"
        if (mc != null) url += "&gameVersion=" + enc(mc)
        val lc = loaderCode(loader)
        if (lc != null && useLoader) url += "&modLoaderType=$lc"
        val data = JSONObject(Net.get(url, headers())).getJSONArray("data")
        return (0 until data.length()).map { fileOf(data.getJSONObject(it)) }.sortedByDescending { it.date }
    }

    fun filesByIds(ids: List<String>): List<JSONObject> {
        val out = ArrayList<JSONObject>()
        for (chunk in ids.chunked(100)) {
            val body = JSONObject().put("fileIds", JSONArray(chunk.map { it.toLong() })).toString()
            val data = JSONObject(Net.post("$BASE/mods/files", body, headers())).getJSONArray("data")
            for (i in 0 until data.length()) out.add(data.getJSONObject(i))
        }
        return out
    }

    fun modsByIds(ids: List<String>): List<JSONObject> {
        val out = ArrayList<JSONObject>()
        for (chunk in ids.chunked(100)) {
            val body = JSONObject().put("modIds", JSONArray(chunk.map { it.toLong() })).toString()
            val data = JSONObject(Net.post("$BASE/mods", body, headers())).getJSONArray("data")
            for (i in 0 until data.length()) out.add(data.getJSONObject(i))
        }
        return out
    }
}
