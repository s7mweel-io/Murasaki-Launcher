package com.murasaki.launcher

import android.graphics.BitmapFactory
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/* All sizes are "design pixels" of the 720 x 366 mockup. DesignCanvas scales them to fit the phone. */

object C {
    val bg = Color(0xFF08080A)
    val panel = Color(0xFF0B0B0D)
    val card = Color(0xFF111113)
    val selected = Color(0xFF1C1C1F)
    val border = Color(0xFF262629)
    val field = Color(0xFF0D0D0F)
    val track = Color(0xFF28282C)
    val text = Color(0xFFF4F4F5)
    val sub = Color(0xFFC9C9CF)
    val muted = Color(0xFF85858D)
    val green = Color(0xFF4ADE80)
}
val R4 = RoundedCornerShape(4.dp)
val R5 = RoundedCornerShape(5.dp)
val R6 = RoundedCornerShape(6.dp)

@Composable
fun DesignCanvas(content: @Composable () -> Unit) {
    BoxWithConstraints(Modifier.fillMaxSize().background(C.bg)) {
        val scale = minOf(constraints.maxHeight / 366f, constraints.maxWidth / 640f)
        CompositionLocalProvider(LocalDensity provides Density(scale, 1f)) {
            Box(Modifier.fillMaxSize()) { content() }
        }
    }
}

@Composable
fun Txt(
    text: String, size: Float, color: Color = C.text, weight: FontWeight = FontWeight.Normal,
    spacing: Float = 0f, maxLines: Int = Int.MAX_VALUE, modifier: Modifier = Modifier
) {
    Text(
        text, modifier = modifier, color = color, fontSize = size.sp, fontWeight = weight,
        letterSpacing = spacing.sp, lineHeight = (size * 1.3f).sp, maxLines = maxLines, overflow = TextOverflow.Ellipsis
    )
}

@Composable
fun Avatar(name: String, size: Int) {
    Box(Modifier.size(size.dp).clip(CircleShape).background(Color(0xFF3F3F46)), contentAlignment = Alignment.Center) {
        Txt(name.take(1).uppercase(), size * 0.5f, C.text, FontWeight.Bold)
    }
}

@Composable
fun InstanceIcon(iconKey: String, customPath: String?, size: Dp) {
    val custom = remember(customPath) { customPath?.let { BitmapFactory.decodeFile(it)?.asImageBitmap() } }
    if (custom != null) Image(custom, null, Modifier.size(size).clip(R4))
    else Image(painterResource(blockRes(iconKey)), null, Modifier.size(size))
}

@Composable
fun FlatSlider(value: Float, onChange: (Float) -> Unit, modifier: Modifier = Modifier) {
    var w by remember { mutableStateOf(1f) }
    val cb by rememberUpdatedState(onChange)
    Box(
        modifier.height(14.dp).onSizeChanged { w = it.width.toFloat().coerceAtLeast(1f) }
            .pointerInput(Unit) { detectTapGestures { o -> cb((o.x / w).coerceIn(0f, 1f)) } }
            .pointerInput(Unit) { detectHorizontalDragGestures { change, _ -> cb((change.position.x / w).coerceIn(0f, 1f)) } },
        contentAlignment = Alignment.CenterStart
    ) {
        Box(Modifier.fillMaxWidth().height(2.6.dp).clip(RoundedCornerShape(2.dp)).background(C.track))
        Box(Modifier.fillMaxWidth(value.coerceIn(0f, 1f)).height(2.6.dp).clip(RoundedCornerShape(2.dp)).background(Color.White))
        Box(
            Modifier.offset { IntOffset((value.coerceIn(0f, 1f) * w - 4.dp.toPx()).toInt(), 0) }
                .size(8.dp).clip(CircleShape).background(Color.White)
        )
    }
}

@Composable
fun Toggle(on: Boolean, onChange: (Boolean) -> Unit) {
    Box(
        Modifier.size(20.dp, 10.dp).clip(RoundedCornerShape(5.dp))
            .background(if (on) Color.White else C.track).clickable { onChange(!on) }
    ) {
        Box(
            Modifier.padding(start = if (on) 12.dp else 2.dp, top = 2.dp).size(6.dp)
                .clip(CircleShape).background(if (on) C.bg else C.muted)
        )
    }
}

@Composable
fun TextInput(value: String, onChange: (String) -> Unit, placeholder: String, modifier: Modifier = Modifier) {
    Box(
        modifier.height(18.dp).clip(R4).background(C.field).border(1.dp, C.border, R4).padding(horizontal = 6.dp),
        contentAlignment = Alignment.CenterStart
    ) {
        if (value.isEmpty()) Txt(placeholder, 6.6f, C.muted, maxLines = 1)
        BasicTextField(
            value = value, onValueChange = onChange, singleLine = true,
            textStyle = TextStyle(color = C.sub, fontSize = 6.8.sp),
            cursorBrush = SolidColor(Color.White), modifier = Modifier.fillMaxWidth()
        )
    }
}

@Composable
fun <T> Picker(
    modifier: Modifier, items: List<T>, selected: T, label: (T) -> String,
    leading: (@Composable () -> Unit)? = null, height: Int = 26, onSelect: (T) -> Unit
) {
    var open by remember { mutableStateOf(false) }
    Box(modifier) {
        Row(
            Modifier.fillMaxWidth().height(height.dp).clip(R6).background(C.card).border(1.dp, C.border, R6)
                .clickable { open = true }.padding(horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (leading != null) { leading(); Spacer(Modifier.width(7.dp)) }
            Txt(label(selected), 7.0f, C.text, FontWeight.Medium, maxLines = 1, modifier = Modifier.weight(1f))
            Icon(Icons.Default.KeyboardArrowDown, null, tint = C.muted, modifier = Modifier.size(10.dp))
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            items.forEach { DropdownMenuItem(text = { Txt(label(it), 8f) }, onClick = { onSelect(it); open = false }) }
        }
    }
}

@Composable
fun PrimaryButton(label: String, modifier: Modifier = Modifier, enabled: Boolean = true, height: Int = 18, onClick: () -> Unit) {
    Box(
        modifier.height(height.dp).clip(R4).background(if (enabled) Color.White else Color(0xFF3F3F46))
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Txt(label, 6.6f, if (enabled) Color(0xFF0A0A0A) else C.muted, FontWeight.Bold) }
}

@Composable
fun OutlineButton(label: String, modifier: Modifier = Modifier, height: Int = 22, icon: ImageVector? = null, onClick: () -> Unit) {
    Row(
        modifier.height(height.dp).clip(R4).background(C.field).border(1.dp, C.border, R4).clickable(onClick = onClick),
        horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically
    ) {
        if (icon != null) { Icon(icon, null, tint = C.text, modifier = Modifier.size(8.dp)); Spacer(Modifier.width(5.dp)) }
        Txt(label, 6.6f, C.text, FontWeight.Bold)
    }
}

@Composable
fun Seg(labels: List<String>, active: Int, onSelect: (Int) -> Unit, modifier: Modifier = Modifier, height: Int = 18) {
    Row(modifier.height(height.dp).clip(R5).background(C.field).border(1.dp, C.border, R5).padding(2.dp)) {
        labels.forEachIndexed { i, l ->
            Box(
                Modifier.weight(1f).fillMaxHeight().clip(R4)
                    .background(if (i == active) C.selected else Color.Transparent).clickable { onSelect(i) },
                contentAlignment = Alignment.Center
            ) { Txt(l, 6.4f, if (i == active) C.text else C.muted, if (i == active) FontWeight.Bold else FontWeight.Normal) }
        }
    }
}

@Composable
fun CardBox(modifier: Modifier = Modifier, title: String? = null, content: @Composable ColumnScope.() -> Unit) {
    Column(modifier.clip(R6).background(C.card).border(1.dp, C.border, R6).padding(10.dp)) {
        if (title != null) { Txt(title, 7.6f, C.text, FontWeight.Bold); Spacer(Modifier.height(6.dp)) }
        content()
    }
}

@Composable
fun SettingRow(label: String, control: @Composable () -> Unit) {
    Row(Modifier.fillMaxWidth().height(21.dp), verticalAlignment = Alignment.CenterVertically) {
        Txt(label, 6.3f, C.sub, modifier = Modifier.weight(1f)); control()
    }
}
