package com.murasaki.launcher

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Icon
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

@Composable
fun AppRoot(s: LauncherState) {
    Box(Modifier.fillMaxSize()) {
        MainLayout(s)
        if (s.showAdd) AddInstanceOverlay(s)
        if (s.showAccounts) AccountsOverlay(s)
    }
}

@Composable
private fun MainLayout(s: LauncherState) {
    Row(Modifier.fillMaxSize().background(C.bg).displayCutoutPadding()) {
        Sidebar(s)
        Box(Modifier.width(1.dp).fillMaxHeight().background(C.border))
        Column(
            Modifier.weight(1f).fillMaxHeight().verticalScroll(rememberScrollState()).padding(horizontal = 18.dp)
        ) {
            TopBar(s)
            when (s.screen) {
                "Home" -> HomeContent(s)
                "Library" -> LibraryScreen(s)
                "Discover" -> ComingSoon("Mod, resource pack and shader browsers\n(Modrinth and CurseForge) arrive in the next step")
                "Skins" -> SkinsScreen(s)
                else -> SettingsScreen(s)
            }
        }
    }
}

@Composable
private fun ComingSoon(text: String) {
    Box(Modifier.fillMaxWidth().height(220.dp), contentAlignment = Alignment.Center) {
        Txt(text, 8f, C.muted)
    }
}

// ------------------------------------------------------------------ sidebar
@Composable
private fun Sidebar(s: LauncherState) {
    Column(Modifier.width(141.dp).fillMaxHeight().background(C.panel).padding(horizontal = 8.dp)) {
        Spacer(Modifier.height(20.dp))
        Row(Modifier.padding(start = 9.dp), verticalAlignment = Alignment.CenterVertically) {
            Image(painterResource(R.drawable.logo_mark), null, Modifier.height(23.dp).aspectRatio(1.128f))
            Spacer(Modifier.width(10.dp))
            Column {
                Image(painterResource(R.drawable.logo_wordmark), null, Modifier.width(64.dp).aspectRatio(10.17f))
                Spacer(Modifier.height(3.dp))
                Image(painterResource(R.drawable.logo_launcher_text), null, Modifier.width(49.dp).aspectRatio(9.3f))
            }
        }
        Spacer(Modifier.height(14.dp))
        listOf(
            "Home" to Icons.Default.Home,
            "Library" to Icons.Default.VideoLibrary,
            "Discover" to Icons.Default.Explore,
            "Skins" to Icons.Default.Person,
            "Settings" to Icons.Default.Settings
        ).forEach { (name, icon) ->
            NavItem(icon, name, s.screen == name) { s.screen = name }
            Spacer(Modifier.height(1.4.dp))
        }
        Spacer(Modifier.height(4.dp))
        Box(Modifier.padding(horizontal = 4.dp).fillMaxWidth().height(1.dp).background(C.border))
        Spacer(Modifier.height(10.dp))
        Txt("Quick Access", 6f, C.muted, modifier = Modifier.padding(start = 4.dp))
        Spacer(Modifier.height(5.dp))
        s.instances.take(3).forEachIndexed { i, ins ->
            Row(
                Modifier.fillMaxWidth().height(26.dp).clip(R5)
                    .clickable { s.instanceIdx = i; s.save(); s.screen = "Home" }.padding(start = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                InstanceIcon(ins.iconKey, ins.customIcon, 17.dp)
                Spacer(Modifier.width(7.dp))
                Column {
                    Txt(ins.title, 6.6f, C.text, FontWeight.Bold, maxLines = 1)
                    Txt(ins.subtitle, 5.4f, C.muted, maxLines = 1)
                }
            }
        }
        Spacer(Modifier.weight(1f))
        Txt(
            "*Not an official Minecraft product. Not approved by or associated with Mojang or Microsoft.",
            4.9f, Color(0xFF787880), modifier = Modifier.padding(horizontal = 5.dp)
        )
        Spacer(Modifier.height(7.dp))
        Row(
            Modifier.padding(horizontal = 4.dp).fillMaxWidth().height(27.dp).clip(R6)
                .border(1.dp, C.border, R6).clickable { s.showAdd = true },
            horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Default.Add, null, tint = C.text, modifier = Modifier.size(9.dp))
            Spacer(Modifier.width(6.dp))
            Txt("Add Instance", 7f, C.text)
        }
        Spacer(Modifier.height(19.dp))
    }
}

@Composable
private fun NavItem(icon: ImageVector, label: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().height(23.dp).clip(R5)
            .background(if (selected) C.selected else Color.Transparent)
            .clickable(onClick = onClick).padding(start = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = if (selected) C.text else C.muted, modifier = Modifier.size(9.dp))
        Spacer(Modifier.width(8.dp))
        Txt(label, 7.6f, if (selected) C.text else C.sub, if (selected) FontWeight.Bold else FontWeight.Normal)
    }
}

// ------------------------------------------------------------------ top bar
@Composable
private fun TopBar(s: LauncherState) {
    Row(Modifier.fillMaxWidth().padding(top = 14.dp).height(26.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Default.ChevronLeft, null, tint = C.text, modifier = Modifier.size(12.dp).clickable { s.screen = "Home" })
        Spacer(Modifier.weight(1f))
        Row(
            Modifier.width(103.dp).fillMaxHeight().clip(R6).background(C.card).border(1.dp, C.border, R6)
                .clickable { s.showAccounts = true }.padding(horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Avatar(s.account.name, 14)
            Spacer(Modifier.width(6.dp))
            Column {
                Txt(s.account.name, 6.4f, C.text, FontWeight.Bold, maxLines = 1)
                Txt(s.account.type, 4.9f, C.muted, maxLines = 1)
            }
        }
        Spacer(Modifier.width(12.dp))
        Icon(Icons.Default.Notifications, null, tint = C.text, modifier = Modifier.size(11.dp))
    }
}

// ------------------------------------------------------------------ home
@Composable
private fun HomeContent(s: LauncherState) {
    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
        Spacer(Modifier.height(12.dp))
        Image(painterResource(R.drawable.logo_wordmark), null, Modifier.width(250.dp).aspectRatio(10.17f))
        Spacer(Modifier.height(4.dp))
        Image(painterResource(R.drawable.logo_launcher_band), null, Modifier.width(170.dp).aspectRatio(18.25f))
        Spacer(Modifier.height(6.dp))
        Txt("PLAY MINECRAFT JAVA", 6.6f, C.muted, spacing = 2.6f)
        Spacer(Modifier.height(9.dp))
        Row(Modifier.width(272.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Picker(
                Modifier.weight(1f), s.accounts, s.account, { it.name }, { Avatar(s.account.name, 14) }
            ) { s.accountIdx = s.accounts.indexOf(it); s.save() }
            Picker(
                Modifier.weight(1f), s.instances, s.current, { it.title + "  " + it.version },
                { InstanceIcon(s.current.iconKey, s.current.customIcon, 17.dp) }
            ) { s.instanceIdx = s.instances.indexOf(it); s.save() }
        }
        Spacer(Modifier.height(5.dp))
        Row(Modifier.width(272.dp), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            Box(
                Modifier.weight(1f).height(34.dp).clip(R6)
                    .background(if (s.launching) Color(0xFF3F3F46) else Color.White)
                    .clickable(enabled = !s.launching, onClick = s::play),
                contentAlignment = Alignment.Center
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (s.status == null) {
                        Icon(Icons.Default.PlayArrow, null, tint = Color.Black, modifier = Modifier.size(11.dp))
                        Spacer(Modifier.width(4.dp))
                    }
                    Txt(s.status ?: "PLAY", 8.5f, if (s.launching) C.muted else Color.Black, FontWeight.Bold, spacing = 1.6f)
                }
            }
            Box(
                Modifier.size(33.dp, 34.dp).clip(R6).background(C.card).border(1.dp, C.border, R6)
                    .clickable { s.screen = "Settings" },
                contentAlignment = Alignment.Center
            ) { Icon(Icons.Default.Tune, null, tint = C.text, modifier = Modifier.size(11.dp)) }
        }
    }
    Spacer(Modifier.height(12.dp))
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        InfoCard(Icons.Default.ViewInAr, "Java Runtime", s.javaRuntime, Modifier.weight(1f)) { s.screen = "Settings"; s.settingsTab = 0 }
        InfoCard(Icons.Default.Memory, "Memory Allocation", "${s.memoryMb / 1024} GB (${s.memoryMb} MB)", Modifier.weight(1f)) { s.screen = "Settings"; s.settingsTab = 0 }
        InfoCard(Icons.Default.Folder, "Game Directory", s.gameDir, Modifier.weight(1.1f)) { s.screen = "Settings"; s.settingsTab = 0 }
        InfoCard(Icons.Default.Code, "Game Arguments", "Default", Modifier.weight(1f)) { s.screen = "Settings"; s.settingsTab = 0 }
    }
    Spacer(Modifier.height(10.dp))
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(18.dp)) {
        Column(Modifier.weight(1.85f)) {
            SectionLabel(Icons.Default.History, "Recently Played", null)
            Row(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                s.instances.take(3).forEachIndexed { i, ins ->
                    RecentCard(ins, Modifier.weight(1f)) { s.instanceIdx = i; s.save() }
                }
            }
        }
        Column(Modifier.weight(1f)) {
            SectionLabel(Icons.Default.Campaign, "News & Updates", "View All")
            NewsCard(s.news)
        }
    }
    Spacer(Modifier.height(10.dp))
}

@Composable
private fun SectionLabel(icon: ImageVector, title: String, trailing: String?) {
    Row(Modifier.fillMaxWidth().height(16.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = C.muted, modifier = Modifier.size(8.dp))
        Spacer(Modifier.width(5.dp))
        Txt(title, 6.8f, C.text, FontWeight.Bold)
        if (trailing != null) {
            Spacer(Modifier.weight(1f))
            Txt(trailing, 5.5f, C.muted)
        }
    }
}

@Composable
private fun InfoCard(icon: ImageVector, title: String, value: String, modifier: Modifier, onClick: () -> Unit) {
    Row(
        modifier.height(30.dp).clip(R6).background(C.card).border(1.dp, C.border, R6)
            .clickable(onClick = onClick).padding(horizontal = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = C.text, modifier = Modifier.size(11.dp))
        Spacer(Modifier.width(7.dp))
        Column(Modifier.weight(1f)) {
            Txt(title, 6.2f, C.text, FontWeight.Bold, maxLines = 1)
            Txt(value, 5.2f, C.muted, maxLines = 1)
        }
        Icon(Icons.Default.ChevronRight, null, tint = C.muted, modifier = Modifier.size(9.dp))
    }
}

private val thumb = Brush.verticalGradient(listOf(Color(0xFF45454C), Color(0xFF1B1B1E)))

@Composable
private fun RecentCard(i: Instance, modifier: Modifier, onClick: () -> Unit) {
    Column(modifier.height(62.dp).clip(R6).background(C.card).border(1.dp, C.border, R6).clickable(onClick = onClick)) {
        Box(Modifier.fillMaxWidth().height(34.dp).background(thumb)) {
            Box(Modifier.padding(4.dp)) { InstanceIcon(i.iconKey, i.customIcon, 15.dp) }
        }
        Row(Modifier.fillMaxSize().padding(horizontal = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Txt(i.title, 6.3f, C.text, FontWeight.Bold, maxLines = 1)
                Txt(i.subtitle, 5.2f, C.muted, maxLines = 1)
            }
            Icon(Icons.Default.ChevronRight, null, tint = C.muted, modifier = Modifier.size(9.dp))
        }
    }
}

@Composable
private fun NewsCard(n: NewsItem) {
    Row(
        Modifier.fillMaxWidth().height(50.dp).clip(R6).background(C.card).border(1.dp, C.border, R6).padding(5.dp),
        verticalAlignment = Alignment.Top
    ) {
        Box(Modifier.width(48.dp).fillMaxHeight().clip(RoundedCornerShape(4.dp)).background(thumb))
        Spacer(Modifier.width(6.dp))
        Column {
            Txt(n.title, 6.2f, C.text, FontWeight.Bold, maxLines = 1)
            Txt(n.body, 5.1f, C.muted, maxLines = 2)
            Txt(n.date, 4.8f, C.muted, maxLines = 1)
        }
    }
}

// ------------------------------------------------------------------ library
@Composable
private fun LibraryScreen(s: LauncherState) {
    Column(Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 12.dp)) {
        Txt("Library", 11f, C.text, FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        s.instances.forEachIndexed { i, ins ->
            Row(
                Modifier.fillMaxWidth().padding(bottom = 6.dp).clip(R6).background(C.card).border(1.dp, C.border, R6)
                    .clickable { s.instanceIdx = i; s.save(); s.screen = "Home" }.padding(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                InstanceIcon(ins.iconKey, ins.customIcon, 28.dp)
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Txt(ins.title, 7.8f, C.text, FontWeight.Bold, maxLines = 1)
                    Txt(ins.version + (if (ins.loader != null) "  -  " + ins.loader else ""), 6f, C.muted, maxLines = 1)
                }
                if (i == s.instanceIdx) Txt("Selected", 6f, C.green, FontWeight.Bold)
                Spacer(Modifier.width(10.dp))
                Txt("Remove", 6f, C.muted, modifier = Modifier.clickable { s.removeInstance(i) })
            }
        }
        OutlineButton("Add Instance", Modifier.width(120.dp), icon = Icons.Default.Add) { s.showAdd = true }
    }
}
