package com.murasaki.launcher

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private object C {
    val bg = Color(0xFF0A0A0B)
    val panel = Color(0xFF111113)
    val card = Color(0xFF18181B)
    val border = Color(0xFF27272A)
    val text = Color(0xFFF4F4F5)
    val muted = Color(0xFF8A8A93)
}
private val R8 = RoundedCornerShape(8.dp)

@Composable
fun HomeScreen(s: LauncherState) {
    Row(Modifier.fillMaxSize().background(C.bg).displayCutoutPadding()) {
        Sidebar(s)
        Column(
            Modifier.weight(1f).fillMaxHeight()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            TopBar(s)
            if (s.screen == "Home") HomeContent(s)
            else Box(Modifier.fillMaxWidth().height(240.dp), contentAlignment = Alignment.Center) {
                Text("${s.screen} – coming soon", color = C.muted)
            }
        }
    }
}

@Composable
private fun Sidebar(s: LauncherState) {
    Column(Modifier.width(190.dp).fillMaxHeight().background(C.panel).padding(12.dp)) {
        Text("MURASAKI", color = C.text, fontWeight = FontWeight.Black, fontSize = 15.sp, letterSpacing = 3.sp)
        Text("LAUNCHER", color = C.muted, fontSize = 9.sp, letterSpacing = 4.sp)
        Spacer(Modifier.height(14.dp))
        listOf(
            "Home" to Icons.Default.Home,
            "Library" to Icons.Default.VideoLibrary,
            "Discover" to Icons.Default.Explore,
            "Mods" to Icons.Default.Extension,
            "Settings" to Icons.Default.Settings
        ).forEach { (name, icon) -> NavItem(icon, name, s.screen == name) { s.screen = name } }

        Spacer(Modifier.height(12.dp))
        Text("Quick Access", color = C.muted, fontSize = 10.sp, modifier = Modifier.padding(start = 4.dp, bottom = 4.dp))
        s.quickAccess.forEach { i ->
            Row(
                Modifier.fillMaxWidth().clip(R8).clickable { s.pick(i); s.screen = "Home" }.padding(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.ViewInAr, null, tint = C.text, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(10.dp))
                Column {
                    Text(i.title, color = C.text, fontSize = 11.sp)
                    Text(i.subtitle, color = C.muted, fontSize = 9.sp)
                }
            }
        }
        Spacer(Modifier.weight(1f))
        Row(
            Modifier.fillMaxWidth().clip(R8).border(1.dp, C.border, R8)
                .clickable { /* TODO: create-instance dialog */ }.padding(10.dp),
            horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Default.Add, null, tint = C.text, modifier = Modifier.size(14.dp))
            Spacer(Modifier.width(6.dp))
            Text("Add Instance", color = C.text, fontSize = 11.sp)
        }
    }
}

@Composable
private fun NavItem(icon: ImageVector, label: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(R8)
            .background(if (selected) C.card else Color.Transparent)
            .clickable(onClick = onClick).padding(horizontal = 10.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = if (selected) C.text else C.muted, modifier = Modifier.size(16.dp))
        Spacer(Modifier.width(10.dp))
        Text(label, color = if (selected) C.text else C.muted, fontSize = 12.sp)
    }
}

@Composable
private fun TopBar(s: LauncherState) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Default.ChevronLeft, null, tint = C.text, modifier = Modifier.clickable { s.screen = "Home" })
        Spacer(Modifier.weight(1f))
        Row(
            Modifier.clip(R8).background(C.card).border(1.dp, C.border, R8).padding(horizontal = 8.dp, vertical = 5.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Avatar(s.account.name)
            Spacer(Modifier.width(8.dp))
            Column {
                Text(s.account.name, color = C.text, fontSize = 10.sp, fontWeight = FontWeight.Medium)
                Text(s.account.type, color = C.muted, fontSize = 8.sp)
            }
        }
        Spacer(Modifier.width(12.dp))
        Icon(Icons.Default.Notifications, null, tint = C.text, modifier = Modifier.size(18.dp))
    }
}

@Composable
private fun Avatar(name: String) {
    Box(Modifier.size(22.dp).clip(CircleShape).background(Color(0xFF3F3F46)), contentAlignment = Alignment.Center) {
        Text(name.take(1).uppercase(), color = C.text, fontSize = 10.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun HomeContent(s: LauncherState) {
    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
        Text("PLAY MINECRAFT JAVA EDITION", color = C.muted, fontSize = 9.sp, letterSpacing = 2.sp)
        // Swap these two Texts for your own logo image if you have one.
        Text("MINECRAFT", color = C.text, fontSize = 38.sp, fontWeight = FontWeight.Black, letterSpacing = 4.sp)
        Text("JAVA EDITION", color = C.text, fontSize = 11.sp, letterSpacing = 6.sp)
        Spacer(Modifier.height(12.dp))

        Row(Modifier.widthIn(max = 480.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Picker(Modifier.weight(1f), listOf(s.account), s.account, { it.name }, { Avatar(s.account.name) }) { s.account = it }
            Picker(
                Modifier.weight(1f), s.versions, s.version, { it.id },
                { Icon(Icons.Default.ViewInAr, null, tint = C.text, modifier = Modifier.size(18.dp)) }
            ) { s.version = it; s.loader = null }
        }
        Spacer(Modifier.height(8.dp))
        Row(Modifier.widthIn(max = 480.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(
                onClick = s::play, enabled = !s.launching,
                modifier = Modifier.weight(1f).height(44.dp), shape = R8,
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color.White, contentColor = Color.Black,
                    disabledContainerColor = Color(0xFF3F3F46), disabledContentColor = C.muted
                )
            ) {
                if (s.status == null) Icon(Icons.Default.PlayArrow, null)
                Spacer(Modifier.width(6.dp))
                Text(s.status ?: "PLAY", fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
            }
            Box(
                Modifier.size(44.dp).clip(R8).background(C.card).border(1.dp, C.border, R8)
                    .clickable { s.screen = "Settings" },
                contentAlignment = Alignment.Center
            ) { Icon(Icons.Default.Tune, null, tint = C.text) }
        }
    }

    Spacer(Modifier.height(14.dp))
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        InfoCard(Icons.Default.ViewInAr, "Java Runtime", s.settings.javaRuntime, Modifier.weight(1f))
        InfoCard(Icons.Default.Memory, "Memory Allocation", "${s.settings.memoryMb / 1024} GB (${s.settings.memoryMb} MB)", Modifier.weight(1f))
        InfoCard(Icons.Default.Folder, "Game Directory", s.settings.gameDir, Modifier.weight(1f))
        InfoCard(Icons.Default.SportsEsports, "Game Arguments", s.settings.gameArgs, Modifier.weight(1f))
    }

    Spacer(Modifier.height(14.dp))
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Column(Modifier.weight(2f)) {
            Text("Recently Played", color = C.text, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                s.recent.forEach { RecentCard(it, Modifier.weight(1f)) { s.pick(it) } }
            }
        }
        Column(Modifier.weight(1f)) {
            Row(Modifier.padding(bottom = 6.dp)) {
                Text("News & Updates", color = C.text, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.weight(1f))
                Text("View All", color = C.muted, fontSize = 9.sp)
            }
            Column(Modifier.fillMaxWidth().clip(R8).background(C.card).border(1.dp, C.border, R8).padding(10.dp)) {
                Text(s.news.title, color = C.text, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Text(s.news.body, color = C.muted, fontSize = 9.sp)
                Text(s.news.date, color = C.muted, fontSize = 8.sp, modifier = Modifier.padding(top = 4.dp))
            }
        }
    }
    Spacer(Modifier.height(12.dp))
}

@Composable
private fun <T> Picker(
    modifier: Modifier, items: List<T>, selected: T, label: (T) -> String,
    leading: @Composable () -> Unit, onSelect: (T) -> Unit
) {
    var open by remember { mutableStateOf(false) }
    Box(modifier) {
        Row(
            Modifier.fillMaxWidth().clip(R8).background(C.card).border(1.dp, C.border, R8)
                .clickable { open = true }.padding(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            leading()
            Spacer(Modifier.width(8.dp))
            Text(label(selected), color = C.text, fontSize = 12.sp, modifier = Modifier.weight(1f))
            Icon(Icons.Default.KeyboardArrowDown, null, tint = C.muted)
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            items.forEach { DropdownMenuItem(text = { Text(label(it)) }, onClick = { onSelect(it); open = false }) }
        }
    }
}

@Composable
private fun InfoCard(icon: ImageVector, title: String, value: String, modifier: Modifier) {
    Row(
        modifier.clip(R8).background(C.card).border(1.dp, C.border, R8)
            .clickable { /* TODO: open editor */ }.padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = C.text, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(8.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = C.text, fontSize = 10.sp, fontWeight = FontWeight.Medium)
            Text(value, color = C.muted, fontSize = 9.sp, maxLines = 1)
        }
        Icon(Icons.Default.ChevronRight, null, tint = C.muted, modifier = Modifier.size(16.dp))
    }
}

@Composable
private fun RecentCard(i: Instance, modifier: Modifier, onClick: () -> Unit) {
    Column(modifier.clip(R8).background(C.card).border(1.dp, C.border, R8).clickable(onClick = onClick)) {
        Box(
            Modifier.fillMaxWidth().height(54.dp)
                .background(Brush.verticalGradient(listOf(Color(0xFF3F3F46), Color(0xFF18181B))))
        )
        Row(Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(i.title, color = C.text, fontSize = 10.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                Text(i.subtitle, color = C.muted, fontSize = 9.sp, maxLines = 1)
            }
            Icon(Icons.Default.ChevronRight, null, tint = C.muted, modifier = Modifier.size(16.dp))
        }
    }
}
