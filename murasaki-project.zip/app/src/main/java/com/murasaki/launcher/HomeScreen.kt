package com.murasaki.launcher

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/*
 * All sizes below are in "design pixels": the same units as your 720 x 366 mockup.
 * DesignCanvas scales everything so the screen is exactly 366 design-dp tall,
 * so the layout keeps the mockup's proportions on any phone.
 */

private object C {
    val bg = Color(0xFF08080A)
    val panel = Color(0xFF0B0B0D)
    val card = Color(0xFF111113)
    val selected = Color(0xFF1C1C1F)
    val border = Color(0xFF232326)
    val text = Color(0xFFF4F4F5)
    val sub = Color(0xFFC9C9CF)
    val muted = Color(0xFF85858D)
}
private val R6 = RoundedCornerShape(6.dp)
private val R5 = RoundedCornerShape(5.dp)

@Composable
fun DesignCanvas(content: @Composable () -> Unit) {
    BoxWithConstraints(Modifier.fillMaxSize().background(C.bg)) {
        val scale = minOf(constraints.maxHeight / 366f, constraints.maxWidth / 640f)
        CompositionLocalProvider(LocalDensity provides Density(scale, 1f)) {
            Box(Modifier.fillMaxSize()) { content() }
        }
    }
}

/** Text helper: fixes line height (Material's default 24sp would wreck small text). */
@Composable
private fun Txt(
    text: String, size: Float, color: Color = C.text, weight: FontWeight = FontWeight.Normal,
    spacing: Float = 0f, maxLines: Int = Int.MAX_VALUE, modifier: Modifier = Modifier
) {
    Text(
        text, modifier = modifier, color = color, fontSize = size.sp, fontWeight = weight,
        letterSpacing = spacing.sp, lineHeight = (size * 1.3f).sp,
        maxLines = maxLines, overflow = TextOverflow.Ellipsis
    )
}

@Composable
fun HomeScreen(s: LauncherState) {
    Row(Modifier.fillMaxSize().background(C.bg).displayCutoutPadding()) {
        Sidebar(s)
        Box(Modifier.width(1.dp).fillMaxHeight().background(C.border))
        Column(
            Modifier.weight(1f).fillMaxHeight()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 18.dp)
        ) {
            TopBar(s)
            if (s.screen == "Home") HomeContent(s)
            else Box(Modifier.fillMaxWidth().height(200.dp), contentAlignment = Alignment.Center) {
                Txt("${s.screen} - coming soon", 9f, C.muted)
            }
        }
    }
}

// ---------------------------------------------------------------- sidebar

@Composable
private fun Sidebar(s: LauncherState) {
    Column(Modifier.width(141.dp).fillMaxHeight().background(C.panel).padding(horizontal = 8.dp)) {
        Spacer(Modifier.height(20.dp))
        Row(Modifier.padding(start = 9.dp), verticalAlignment = Alignment.CenterVertically) {
            Image(painterResource(R.drawable.logo_murasaki_mark), null, Modifier.size(25.dp, 23.dp))
            Spacer(Modifier.width(10.dp))
            Column {
                // MURASAKI wordmark: cap height ~6.3 -> drawn height 7.1
                Image(
                    painterResource(R.drawable.logo_murasaki_text), null,
                    Modifier.height(7.1.dp).aspectRatio(9.0265f)
                )
                Spacer(Modifier.height(4.dp))
                Txt("LAUNCHER", 4.5f, C.muted, spacing = 2.8f)
            }
        }
        Spacer(Modifier.height(14.dp))
        listOf(
            "Home" to Icons.Default.Home,
            "Library" to Icons.Default.VideoLibrary,
            "Discover" to Icons.Default.Explore,
            "Mods" to Icons.Default.Extension,
            "Settings" to Icons.Default.Settings
        ).forEach { (name, icon) ->
            NavItem(icon, name, s.screen == name) { s.screen = name }
            Spacer(Modifier.height(1.4.dp))
        }
        Spacer(Modifier.height(4.dp))
        Box(Modifier.padding(horizontal = 4.dp).fillMaxWidth().height(1.dp).background(C.border))
        Spacer(Modifier.height(10.dp))
        Txt("Quick Access", 6f, C.muted, modifier = Modifier.padding(start = 4.dp))
        Spacer(Modifier.height(5.dp))
        s.quickAccess.forEach { i ->
            Row(
                Modifier.fillMaxWidth().height(26.dp).clip(R5)
                    .clickable { s.pick(i); s.screen = "Home" }.padding(start = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.ViewInAr, null, tint = C.text, modifier = Modifier.size(10.dp))
                Spacer(Modifier.width(8.dp))
                Column {
                    Txt(i.title, 6.3f, C.text, FontWeight.Medium)
                    Txt(i.subtitle, 5.3f, C.muted)
                }
            }
        }
        Spacer(Modifier.weight(1f))
        Row(
            Modifier.padding(horizontal = 4.dp).fillMaxWidth().height(27.dp).clip(R6)
                .border(1.dp, C.border, R6).clickable { /* TODO: create-instance dialog */ },
            horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Default.Add, null, tint = C.text, modifier = Modifier.size(9.dp))
            Spacer(Modifier.width(6.dp))
            Txt("Add Instance", 6.8f, C.text)
        }
        Spacer(Modifier.height(19.dp))
    }
}

@Composable
private fun NavItem(icon: ImageVector, label: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().height(23.dp).clip(R5)
            .background(if (selected) C.selected else Color.Transparent)
            .clickable(onClick = onClick).padding(start = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = if (selected) C.text else C.muted, modifier = Modifier.size(9.dp))
        Spacer(Modifier.width(8.dp))
        Txt(label, 7.2f, if (selected) C.text else C.sub, FontWeight.Medium)
    }
}

// ---------------------------------------------------------------- top bar

@Composable
private fun TopBar(s: LauncherState) {
    Row(
        Modifier.fillMaxWidth().padding(top = 14.dp).height(26.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            Icons.Default.ChevronLeft, null, tint = C.text,
            modifier = Modifier.size(12.dp).clickable { s.screen = "Home" }
        )
        Spacer(Modifier.weight(1f))
        Row(
            Modifier.width(103.dp).fillMaxHeight().clip(R6).background(C.card)
                .border(1.dp, C.border, R6).padding(horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Avatar(s.account.name, 16)
            Spacer(Modifier.width(6.dp))
            Column {
                Txt(s.account.name, 6.3f, C.text, FontWeight.Medium, maxLines = 1)
                Txt(s.account.type, 4.8f, C.muted, maxLines = 1)
            }
        }
        Spacer(Modifier.width(12.dp))
        Icon(Icons.Default.Notifications, null, tint = C.text, modifier = Modifier.size(11.dp))
    }
}

@Composable
private fun Avatar(name: String, size: Int) {
    Box(Modifier.size(size.dp).clip(CircleShape).background(Color(0xFF3F3F46)), contentAlignment = Alignment.Center) {
        Txt(name.take(1).uppercase(), size * 0.5f, C.text, FontWeight.Bold)
    }
}

// ---------------------------------------------------------------- home

@Composable
private fun HomeContent(s: LauncherState) {
    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
        Spacer(Modifier.height(28.dp))
        Txt("PLAY MINECRAFT JAVA EDITION", 5.3f, C.muted, spacing = 1.6f)
        Spacer(Modifier.height(10.dp))
        // MINECRAFT wordmark: 235 wide, cap height 25 -> drawn height 29.75
        Image(painterResource(R.drawable.logo_minecraft_text), null, Modifier.width(235.dp).aspectRatio(7.8992f))
        Spacer(Modifier.height(6.dp))
        Txt("JAVA EDITION", 7f, C.text, FontWeight.Light, spacing = 4.2f)
        Spacer(Modifier.height(11.dp))

        Row(Modifier.width(272.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Picker(Modifier.weight(1f), listOf(s.account), s.account, { it.name }, { Avatar(s.account.name, 14) }) { s.account = it }
            Picker(
                Modifier.weight(1f), s.versions, s.version, { it.id },
                { Icon(Icons.Default.ViewInAr, null, tint = C.text, modifier = Modifier.size(11.dp)) }
            ) { s.version = it; s.loader = null }
        }
        Spacer(Modifier.height(5.dp))
        Row(Modifier.width(272.dp), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            Box(
                Modifier.weight(1f).height(34.dp).clip(R6)
                    .background(if (s.launching) Color(0xFF3F3F46) else Color.White)
                    .clickable(enabled = !s.launching, onClick = s::play),
                contentAlignment = Alignment.Center
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (s.status == null) {
                        Icon(Icons.Default.PlayArrow, null, tint = Color.Black, modifier = Modifier.size(11.dp))
                        Spacer(Modifier.width(4.dp))
                    }
                    Txt(s.status ?: "PLAY", 8.5f, if (s.launching) C.muted else Color.Black, FontWeight.Bold, spacing = 1.6f)
                }
            }
            Box(
                Modifier.size(33.dp, 34.dp).clip(R6).background(C.card).border(1.dp, C.border, R6)
                    .clickable { s.screen = "Settings" },
                contentAlignment = Alignment.Center
            ) { Icon(Icons.Default.Tune, null, tint = C.text, modifier = Modifier.size(11.dp)) }
        }
    }

    Spacer(Modifier.height(17.dp))
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        InfoCard(Icons.Default.ViewInAr, "Java Runtime", s.settings.javaRuntime, Modifier.weight(1f))
        InfoCard(Icons.Default.Memory, "Memory Allocation", "${s.settings.memoryMb / 1024} GB (${s.settings.memoryMb} MB)", Modifier.weight(1f))
        InfoCard(Icons.Default.Folder, "Game Directory", s.settings.gameDir, Modifier.weight(1.1f))
        InfoCard(Icons.Default.SportsEsports, "Game Arguments", s.settings.gameArgs, Modifier.weight(1f))
    }

    Spacer(Modifier.height(12.dp))
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(18.dp)) {
        Column(Modifier.weight(1.85f)) {
            SectionLabel(Icons.Default.History, "Recently Played")
            Row(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                s.recent.forEach { RecentCard(it, Modifier.weight(1f)) { s.pick(it) } }
            }
        }
        Column(Modifier.weight(1f)) {
            SectionLabel(Icons.Default.Campaign, "News & Updates", trailing = "View All")
            NewsCard(s.news)
            Spacer(Modifier.height(5.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                repeat(4) { n ->
                    Box(Modifier.padding(horizontal = 2.dp).size(3.dp).clip(CircleShape)
                        .background(if (n == 0) C.text else C.border))
                }
            }
        }
    }
    Spacer(Modifier.height(10.dp))
}

@Composable
private fun SectionLabel(icon: ImageVector, title: String, trailing: String? = null) {
    Row(Modifier.fillMaxWidth().height(16.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = C.muted, modifier = Modifier.size(8.dp))
        Spacer(Modifier.width(5.dp))
        Txt(title, 6.8f, C.text, FontWeight.Bold)
        if (trailing != null) {
            Spacer(Modifier.weight(1f))
            Txt(trailing, 5.5f, C.muted)
        }
    }
}

@Composable
private fun <T> Picker(
    modifier: Modifier, items: List<T>, selected: T, label: (T) -> String,
    leading: @Composable () -> Unit, onSelect: (T) -> Unit
) {
    var open by remember { mutableStateOf(false) }
    Box(modifier) {
        Row(
            Modifier.fillMaxWidth().height(26.dp).clip(R6).background(C.card).border(1.dp, C.border, R6)
                .clickable { open = true }.padding(horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            leading()
            Spacer(Modifier.width(7.dp))
            Txt(label(selected), 7.3f, C.text, FontWeight.Medium, maxLines = 1, modifier = Modifier.weight(1f))
            Icon(Icons.Default.KeyboardArrowDown, null, tint = C.muted, modifier = Modifier.size(10.dp))
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            items.forEach { DropdownMenuItem(text = { Txt(label(it), 8f) }, onClick = { onSelect(it); open = false }) }
        }
    }
}

@Composable
private fun InfoCard(icon: ImageVector, title: String, value: String, modifier: Modifier) {
    Row(
        modifier.height(30.dp).clip(R6).background(C.card).border(1.dp, C.border, R6)
            .clickable { /* TODO: open editor */ }.padding(horizontal = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = C.text, modifier = Modifier.size(11.dp))
        Spacer(Modifier.width(7.dp))
        Column(Modifier.weight(1f)) {
            Txt(title, 6.2f, C.text, FontWeight.Medium, maxLines = 1)
            Txt(value, 5.2f, C.muted, maxLines = 1)
        }
        Icon(Icons.Default.ChevronRight, null, tint = C.muted, modifier = Modifier.size(9.dp))
    }
}

@Composable
private fun RecentCard(i: Instance, modifier: Modifier, onClick: () -> Unit) {
    Column(modifier.height(54.dp).clip(R6).background(C.card).border(1.dp, C.border, R6).clickable(onClick = onClick)) {
        Box(
            Modifier.fillMaxWidth().height(31.dp)
                .background(Brush.verticalGradient(listOf(Color(0xFF45454C), Color(0xFF1B1B1E))))
        )
        Row(Modifier.fillMaxSize().padding(horizontal = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Txt(i.title, 6.3f, C.text, FontWeight.Bold, maxLines = 1)
                Txt(i.subtitle, 5.2f, C.muted, maxLines = 1)
            }
            Icon(Icons.Default.ChevronRight, null, tint = C.muted, modifier = Modifier.size(9.dp))
        }
    }
}

@Composable
private fun NewsCard(n: NewsItem) {
    Row(
        Modifier.fillMaxWidth().height(55.dp).clip(R6).background(C.card).border(1.dp, C.border, R6).padding(5.dp),
        verticalAlignment = Alignment.Top
    ) {
        Box(
            Modifier.width(48.dp).fillMaxHeight().clip(RoundedCornerShape(4.dp))
                .background(Brush.verticalGradient(listOf(Color(0xFF45454C), Color(0xFF1B1B1E))))
        )
        Spacer(Modifier.width(6.dp))
        Column {
            Txt(n.title, 6.2f, C.text, FontWeight.Bold, maxLines = 1)
            Txt(n.body, 5.1f, C.muted, maxLines = 2)
            Txt(n.date, 4.8f, C.muted, maxLines = 1)
        }
    }
}
