package com.murasaki.launcher

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp

private val SWATCHES = listOf(0xFF141418L, 0xFFF4F4F5L, 0xFF4ADE80L, 0xFF60A5FAL, 0xFFA78BFAL, 0xFFF472B6L, 0xFFFB923CL, 0xFFF87171L)
private val DlgShape = RoundedCornerShape(8.dp)

class PickerReq(val initial: Long, val onApply: (Long) -> Unit)

@Composable
fun ModalBox(onDismiss: () -> Unit, content: @Composable () -> Unit) {
    Box(
        Modifier.fillMaxSize().background(Color(0xB3000000)).pointerInput(Unit) { detectTapGestures { onDismiss() } },
        contentAlignment = Alignment.Center
    ) {
        Box(Modifier.pointerInput(Unit) { detectTapGestures { } }) { content() }
    }
}

/** How one control (button or joystick) looks. Used by the editor and by the game screen. */
@Composable
fun CtlVisual(b: CtlButton, scale: Float, gop: Float, pressed: Boolean, stick: Offset) {
    val w = b.w * scale
    val h = b.h * scale
    val a = (b.opacity * gop).coerceIn(0.08f, 1f)
    val fill = Color(b.fill)
    val strokeC = Color(b.stroke)
    if (b.kind == 1) {
        Box(
            Modifier.size(w.dp, h.dp).clip(CircleShape).background(fill.copy(alpha = a * 0.85f))
                .border(b.strokeW.dp, strokeC.copy(alpha = a), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Box(
                Modifier.offset { IntOffset(stick.x.toInt(), stick.y.toInt()) }.size((w * 0.42f).dp)
                    .clip(CircleShape).background(strokeC.copy(alpha = a))
            )
        }
    } else {
        val shape = if (b.radius >= 0.99f) CircleShape else RoundedCornerShape((b.radius * minOf(w, h) / 2f).dp)
        val lum = 0.299f * fill.red + 0.587f * fill.green + 0.114f * fill.blue
        val tc = if (lum > 0.6f) Color(0xFF0A0A0A) else Color.White
        Box(
            Modifier.size(w.dp, h.dp).clip(shape)
                .background(fill.copy(alpha = if (pressed) (a + 0.25f).coerceAtMost(1f) else a * 0.92f))
                .border(b.strokeW.dp, strokeC.copy(alpha = a), shape),
            contentAlignment = Alignment.Center
        ) {
            Txt(b.name, (6.2f * scale).coerceAtLeast(4.6f), tc.copy(alpha = (a + 0.2f).coerceAtMost(1f)), FontWeight.Bold, maxLines = 1)
            if (b.toggle) Box(Modifier.align(Alignment.TopEnd).padding(3.dp).size(4.dp).clip(CircleShape).background(C.green))
        }
    }
}

// ---------------------------------------------------------------- small panel widgets
@Composable
private fun ToolItem(icon: ImageVector, label: String, enabled: Boolean = true, filled: Boolean = false, onClick: () -> Unit) {
    val c = if (filled) Color(0xFF0A0A0A) else if (enabled) Color(0xFFC4C4CC) else Color(0xFF55555C)
    Row(
        Modifier.clip(RoundedCornerShape(10.dp)).background(if (filled) Color.White else Color.Transparent)
            .clickable(enabled = enabled, onClick = onClick).padding(horizontal = 7.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = c, modifier = Modifier.size(9.dp))
        Spacer(Modifier.width(4.dp))
        Txt(label, 5.6f, c, if (filled) FontWeight.Bold else FontWeight.Normal, maxLines = 1)
    }
}

@Composable
private fun PSlider(label: String, frac: Float, value: String, onChange: (Float) -> Unit) {
    Row(Modifier.fillMaxWidth().height(20.dp), verticalAlignment = Alignment.CenterVertically) {
        Txt(label, 6f, C.sub, modifier = Modifier.width(58.dp))
        FlatSlider(frac, onChange, Modifier.weight(1f))
        Txt(value, 6f, C.text, FontWeight.Bold, modifier = Modifier.width(34.dp))
    }
}

@Composable
private fun PToggle(label: String, on: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().height(20.dp), verticalAlignment = Alignment.CenterVertically) {
        Txt(label, 6f, C.sub, modifier = Modifier.weight(1f))
        Toggle(on, onChange)
    }
}

@Composable
private fun PLabel(text: String) {
    Spacer(Modifier.height(8.dp))
    Txt(text, 5.2f, C.muted, FontWeight.Bold, spacing = 0.9f)
    Spacer(Modifier.height(4.dp))
}

@Composable
private fun SwatchRow(current: Long, onPick: (Long) -> Unit, onCustom: () -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        SWATCHES.forEach { c ->
            val sel = c == current
            Box(
                Modifier.size(16.dp).clip(R4).background(Color(c))
                    .border(if (sel) 1.4.dp else 0.8.dp, if (sel) Color.White else C.border, R4).clickable { onPick(c) }
            )
        }
        val custom = current !in SWATCHES
        Box(
            Modifier.size(16.dp).clip(R4).background(if (custom) Color(current) else Color(0xFF18181C))
                .border(if (custom) 1.4.dp else 0.8.dp, if (custom) Color.White else C.border, R4).clickable(onClick = onCustom),
            contentAlignment = Alignment.Center
        ) {
            if (!custom) Icon(Icons.Default.Add, null, tint = C.text, modifier = Modifier.size(7.dp))
        }
    }
}

@Composable
private fun PanelHeader(title: String, onClose: () -> Unit) {
    Row(Modifier.fillMaxWidth().height(30.dp).padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Txt(title, 8.2f, C.text, FontWeight.Bold, modifier = Modifier.weight(1f))
        Icon(Icons.Default.Close, null, tint = C.muted, modifier = Modifier.size(9.dp).clickable(onClick = onClose))
    }
    Box(Modifier.fillMaxWidth().height(1.dp).background(C.border))
}

// ---------------------------------------------------------------- property panel
@Composable
private fun PropertyPanel(
    b: CtlButton, lockRatio: Boolean, onLock: (Boolean) -> Unit,
    onChange: (Boolean, (CtlButton) -> CtlButton) -> Unit,
    onPickColor: (Long, (Long) -> Unit) -> Unit,
    onDuplicate: () -> Unit, onDelete: () -> Unit, onClose: () -> Unit
) {
    var keyMenu by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxHeight().width(212.dp).background(Color(0xF7101012)).border(1.dp, C.border)) {
        PanelHeader(if (b.kind == 1) "Edit joystick" else "Edit button", onClose)
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 4.dp)) {
            PLabel("NAME")
            TextInput(b.name, { v -> onChange(false) { it.copy(name = v) } }, "Name", Modifier.fillMaxWidth())
            if (b.kind == 0) {
                PLabel("KEY MAPPING")
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
                    b.keys.forEach { k ->
                        Row(
                            Modifier.clip(R4).background(Color(0xFF1E1E22)).border(1.dp, C.border, R4).padding(horizontal = 6.dp, vertical = 3.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Txt(k, 6.2f, C.text, FontWeight.Bold)
                            Spacer(Modifier.width(4.dp))
                            Icon(Icons.Default.Close, null, tint = C.muted, modifier = Modifier.size(6.dp).clickable { onChange(true) { it.copy(keys = it.keys - k) } })
                        }
                    }
                    if (b.keys.size < 4) {
                        Box {
                            Box(Modifier.clip(R4).border(1.dp, C.border, R4).clickable { keyMenu = true }.padding(horizontal = 7.dp, vertical = 3.dp)) {
                                Txt("+ key", 6f, C.sub)
                            }
                            DropdownMenu(expanded = keyMenu, onDismissRequest = { keyMenu = false }) {
                                KEY_NAMES.forEach { k ->
                                    DropdownMenuItem(text = { Txt(k, 8f) }, onClick = { onChange(true) { it.copy(keys = it.keys + k) }; keyMenu = false })
                                }
                            }
                        }
                    }
                }
                PLabel("SPECIAL ACTION")
                Picker(Modifier.fillMaxWidth(), SPECIALS, b.special, { it }, height = 18) { v -> onChange(true) { it.copy(special = v) } }
                PLabel("BEHAVIOR")
                PToggle("Toggle (tap on, tap off)", b.toggle) { v -> onChange(true) { it.copy(toggle = v) } }
                PToggle("Swipeable", b.swipe) { v -> onChange(true) { it.copy(swipe = v) } }
                PToggle("Pass touches to game", b.pass) { v -> onChange(true) { it.copy(pass = v) } }
                PToggle("Show while playing", b.showInGame) { v -> onChange(true) { it.copy(showInGame = v) } }
                PLabel("SHAPE")
                val shapeIdx = if (b.radius <= 0.01f) 0 else if (b.radius >= 0.99f) 2 else 1
                Seg(
                    listOf("Square", "Rounded", "Circle"), shapeIdx,
                    { i -> onChange(true) { it.copy(radius = if (i == 0) 0f else if (i == 1) 0.35f else 1f) } },
                    Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(4.dp))
                PSlider("Corner radius", b.radius, (b.radius * 100f).toInt().toString() + "%") { v -> onChange(false) { it.copy(radius = v) } }
            } else {
                PLabel("BEHAVIOR")
                PToggle("Forward lock (push up to sprint)", b.locked) { v -> onChange(true) { it.copy(locked = v) } }
                PToggle("Show while playing", b.showInGame) { v -> onChange(true) { it.copy(showInGame = v) } }
            }
            PLabel("SIZE")
            if (b.kind == 1) {
                PSlider("Size", (b.w - 40f) / 100f, b.w.toInt().toString()) { v ->
                    val sz = 40f + v * 100f
                    onChange(false) { it.copy(w = sz, h = sz) }
                }
            } else {
                PSlider("Width", (b.w - 24f) / 96f, b.w.toInt().toString()) { v ->
                    val nw = 24f + v * 96f
                    onChange(false) { if (lockRatio) it.copy(w = nw, h = (it.h * nw / it.w).coerceIn(24f, 120f)) else it.copy(w = nw) }
                }
                PSlider("Height", (b.h - 24f) / 96f, b.h.toInt().toString()) { v ->
                    val nh = 24f + v * 96f
                    onChange(false) { if (lockRatio) it.copy(h = nh, w = (it.w * nh / it.h).coerceIn(24f, 120f)) else it.copy(h = nh) }
                }
                PToggle("Lock aspect ratio", lockRatio, onLock)
            }
            PLabel("OPACITY")
            PSlider("Opacity", (b.opacity - 0.1f) / 0.9f, (b.opacity * 100f).toInt().toString() + "%") { v -> onChange(false) { it.copy(opacity = 0.1f + v * 0.9f) } }
            PLabel("COLORS")
            Txt(if (b.kind == 1) "Base" else "Fill", 5.8f, C.muted)
            Spacer(Modifier.height(3.dp))
            SwatchRow(b.fill, { c -> onChange(true) { it.copy(fill = c) } }, { onPickColor(b.fill) { c -> onChange(true) { it.copy(fill = c) } } })
            Spacer(Modifier.height(6.dp))
            Txt(if (b.kind == 1) "Stick" else "Stroke", 5.8f, C.muted)
            Spacer(Modifier.height(3.dp))
            SwatchRow(b.stroke, { c -> onChange(true) { it.copy(stroke = c) } }, { onPickColor(b.stroke) { c -> onChange(true) { it.copy(stroke = c) } } })
            Spacer(Modifier.height(4.dp))
            PSlider("Stroke width", b.strokeW / 6f, "%.1f".format(b.strokeW)) { v -> onChange(false) { it.copy(strokeW = v * 6f) } }
            Spacer(Modifier.height(8.dp))
        }
        Box(Modifier.fillMaxWidth().height(1.dp).background(C.border))
        Row(Modifier.fillMaxWidth().padding(8.dp), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            OutlineButton("Duplicate", Modifier.weight(1f), height = 18, onClick = onDuplicate)
            OutlineButton("Delete", Modifier.weight(1f), height = 18, onClick = onDelete)
            PrimaryButton("Done", Modifier.weight(1f), height = 18, onClick = onClose)
        }
    }
}

@Composable
private fun LayoutPanel(l: ControlLayout, onChange: (ControlLayout) -> Unit, onMirror: () -> Unit, onReset: () -> Unit, onClose: () -> Unit) {
    Column(Modifier.fillMaxHeight().width(212.dp).background(Color(0xF7101012)).border(1.dp, C.border)) {
        PanelHeader("Layout settings", onClose)
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 8.dp)) {
            PToggle("Snap to grid", l.snap) { onChange(l.copy(snap = it)) }
            PSlider("Grid size", l.grid, (8f + l.grid * 24f).toInt().toString() + " px") { onChange(l.copy(grid = it)) }
            PSlider("Button scale", l.scale, (layoutScale(l) * 100f).toInt().toString() + "%") { onChange(l.copy(scale = it)) }
            PSlider("Opacity", l.opacity, (l.opacity * 100f).toInt().toString() + "%") { onChange(l.copy(opacity = it)) }
            Spacer(Modifier.height(10.dp))
            OutlineButton("Mirror layout (left-handed)", Modifier.fillMaxWidth(), height = 20, onClick = onMirror)
            Spacer(Modifier.height(5.dp))
            OutlineButton("Reset to default layout", Modifier.fillMaxWidth(), height = 20, onClick = onReset)
        }
        Box(Modifier.fillMaxWidth().height(1.dp).background(C.border))
        Row(Modifier.fillMaxWidth().padding(8.dp), horizontalArrangement = Arrangement.End) {
            PrimaryButton("Done", Modifier.width(70.dp), height = 18, onClick = onClose)
        }
    }
}

// ---------------------------------------------------------------- dialogs
@Composable
fun ColorPickerDialog(initial: Long, onApply: (Long) -> Unit, onClose: () -> Unit) {
    val init = remember { FloatArray(3).also { android.graphics.Color.colorToHSV(initial.toInt(), it) } }
    var hue by remember { mutableStateOf(init[0]) }
    var sat by remember { mutableStateOf(init[1]) }
    var value by remember { mutableStateOf(init[2]) }
    val color = Color.hsv(hue, sat, value)
    val hex = String.format("#%06X", color.toArgb() and 0xFFFFFF)
    ModalBox(onDismiss = onClose) {
        Column(Modifier.width(240.dp).clip(DlgShape).background(Color(0xFF101012)).border(1.dp, Color(0xFF38383E), DlgShape).padding(12.dp)) {
            Txt("Custom color", 7.8f, C.text, FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(
                    Modifier.size(104.dp).clip(R5).background(Brush.horizontalGradient(listOf(Color.White, Color.hsv(hue, 1f, 1f))))
                        .pointerInput(Unit) {
                            detectTapGestures { o ->
                                sat = (o.x / size.width).coerceIn(0f, 1f)
                                value = 1f - (o.y / size.height).coerceIn(0f, 1f)
                            }
                        }
                        .pointerInput(Unit) {
                            detectDragGestures { change, _ ->
                                change.consume()
                                sat = (change.position.x / size.width).coerceIn(0f, 1f)
                                value = 1f - (change.position.y / size.height).coerceIn(0f, 1f)
                            }
                        }
                ) {
                    Box(Modifier.matchParentSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black))))
                    Box(
                        Modifier.offset { IntOffset((sat * 104.dp.toPx() - 5.dp.toPx()).toInt(), ((1f - value) * 104.dp.toPx() - 5.dp.toPx()).toInt()) }
                            .size(10.dp).border(1.5.dp, Color.White, CircleShape)
                    )
                }
                Box(
                    Modifier.width(12.dp).height(104.dp).clip(R4)
                        .background(Brush.verticalGradient(listOf(Color.Red, Color.Yellow, Color.Green, Color.Cyan, Color.Blue, Color.Magenta, Color.Red)))
                        .pointerInput(Unit) { detectTapGestures { o -> hue = (o.y / size.height).coerceIn(0f, 1f) * 360f } }
                        .pointerInput(Unit) {
                            detectDragGestures { change, _ ->
                                change.consume()
                                hue = (change.position.y / size.height).coerceIn(0f, 1f) * 360f
                            }
                        }
                ) {
                    Box(
                        Modifier.offset { IntOffset(0, (hue / 360f * 104.dp.toPx() - 2.dp.toPx()).toInt()) }
                            .fillMaxWidth().height(4.dp).border(1.dp, Color.White, R4)
                    )
                }
                Column(Modifier.weight(1f)) {
                    Box(Modifier.fillMaxWidth().height(38.dp).clip(R6).background(color).border(1.dp, C.border, R6))
                    Spacer(Modifier.height(6.dp))
                    Txt("Hex", 5.6f, C.muted)
                    Txt(hex, 7f, C.text, FontWeight.Bold)
                }
            }
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                OutlineButton("Cancel", Modifier.width(60.dp)) { onClose() }
                Spacer(Modifier.width(8.dp))
                PrimaryButton("Apply color", Modifier.width(84.dp), height = 22) { onApply(color.toArgb().toLong() and 0xFFFFFFFFL) }
            }
        }
    }
}

@Composable
private fun SaveAsDialog(onSave: (String) -> Unit, onClose: () -> Unit) {
    var name by remember { mutableStateOf("") }
    ModalBox(onDismiss = onClose) {
        Column(Modifier.width(250.dp).clip(DlgShape).background(Color(0xFF101012)).border(1.dp, Color(0xFF38383E), DlgShape).padding(14.dp)) {
            Txt("Save layout as", 8.4f, C.text, FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Txt("Layout name", 5.8f, C.muted)
            Spacer(Modifier.height(3.dp))
            TextInput(name, { name = it }, "My layout", Modifier.fillMaxWidth())
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                OutlineButton("Cancel", Modifier.width(60.dp)) { onClose() }
                Spacer(Modifier.width(8.dp))
                PrimaryButton("Save", Modifier.width(80.dp), height = 22) { onSave(name) }
            }
        }
    }
}

@Composable
fun LayoutsDialog(s: LauncherState, onClose: () -> Unit) {
    val store = s.controls
    val ctx = LocalContext.current
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            val t = try { ctx.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } } catch (e: Exception) { null }
            if (t != null && store.importText(t)) s.toast("Layout imported") else s.toast("That is not a layout file")
        }
    }
    ModalBox(onDismiss = onClose) {
        Column(Modifier.width(300.dp).clip(DlgShape).background(Color(0xFF101012)).border(1.dp, Color(0xFF38383E), DlgShape).padding(14.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Txt("Control layouts", 8.4f, C.text, FontWeight.Bold, modifier = Modifier.weight(1f))
                Icon(Icons.Default.Close, null, tint = C.muted, modifier = Modifier.size(9.dp).clickable(onClick = onClose))
            }
            Spacer(Modifier.height(8.dp))
            store.layouts.forEachIndexed { i, l ->
                val on = i == store.activeIdx
                Row(
                    Modifier.fillMaxWidth().padding(bottom = 5.dp).clip(R6).background(if (on) C.selected else C.card)
                        .border(1.dp, if (on) Color(0xFF5A5A62) else C.border, R6).clickable { store.setActive(i) }.padding(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(Modifier.size(9.dp).clip(CircleShape).border(1.dp, if (on) Color.White else C.muted, CircleShape).padding(2.dp)) {
                        if (on) Box(Modifier.fillMaxSize().clip(CircleShape).background(Color.White))
                    }
                    Spacer(Modifier.width(8.dp))
                    Txt(l.name, 7f, C.text, if (on) FontWeight.Bold else FontWeight.Normal, maxLines = 1, modifier = Modifier.weight(1f))
                    if (i == store.defaultIdx) Txt("Default", 5.4f, C.green, FontWeight.Bold)
                }
            }
            Spacer(Modifier.height(6.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                OutlineButton("Import", Modifier.weight(1f), height = 20) { pick.launch("*/*") }
                OutlineButton("Export", Modifier.weight(1f), height = 20) { s.toast("Saved: " + store.export(store.activeIdx)) }
                OutlineButton("Delete", Modifier.weight(1f), height = 20) { store.delete(store.activeIdx) }
            }
            Spacer(Modifier.height(6.dp))
            PrimaryButton("Set as default layout", Modifier.fillMaxWidth(), height = 22) {
                store.setDefault(store.activeIdx)
                s.toast("Default layout changed")
            }
        }
    }
}

// ---------------------------------------------------------------- the editor
@Composable
fun ControlEditor(s: LauncherState) {
    val store = s.controls
    BackHandler { s.editorOpen = false }
    var layout by remember { mutableStateOf(store.active) }
    var selId by remember { mutableStateOf<String?>(null) }
    var panel by remember { mutableStateOf(0) }
    var showLayouts by remember { mutableStateOf(false) }
    var showSaveAs by remember { mutableStateOf(false) }
    var lockRatio by remember { mutableStateOf(true) }
    var picker by remember { mutableStateOf<PickerReq?>(null) }
    val undo = remember { ArrayList<ControlLayout>() }
    val redo = remember { ArrayList<ControlLayout>() }
    var tick by remember { mutableStateOf(0) }
    val historyVersion = tick

    LaunchedEffect(store.activeIdx) { layout = store.active; selId = null }

    fun commit(l: ControlLayout) { layout = l; store.updateActive(l) }
    fun push() { undo.add(layout); if (undo.size > 40) undo.removeAt(0); redo.clear(); tick++ }
    fun change(record: Boolean, f: (CtlButton) -> CtlButton) {
        val id = selId ?: return
        if (record) push()
        commit(layout.copy(buttons = layout.buttons.map { if (it.id == id) f(it) else it }))
    }
    fun addControl(kind: Int) {
        push()
        val id = "b" + System.currentTimeMillis()
        val nb = if (kind == 1) CtlButton(id = id, name = "Joystick", kind = 1, x = 0.15f, y = 0.55f, w = 76f, h = 76f, radius = 1f, opacity = 0.8f, strokeW = 1.5f)
        else CtlButton(id = id, name = "New button", x = 0.45f, y = 0.4f, w = 50f, h = 40f, radius = 0.3f)
        commit(layout.copy(buttons = layout.buttons + nb))
        selId = id
        panel = 0
    }
    fun duplicate() {
        val b = layout.buttons.firstOrNull { it.id == selId } ?: return
        push()
        val nb = b.copy(id = "b" + System.currentTimeMillis(), x = (b.x + 0.04f).coerceAtMost(1f), y = (b.y + 0.06f).coerceAtMost(1f))
        commit(layout.copy(buttons = layout.buttons + nb))
        selId = nb.id
    }
    fun deleteSelected() {
        val id = selId ?: return
        push()
        commit(layout.copy(buttons = layout.buttons.filter { it.id != id }))
        selId = null
    }
    fun doUndo() {
        if (undo.isEmpty()) return
        redo.add(layout)
        val prev = undo.removeAt(undo.lastIndex)
        commit(prev)
        tick++
    }
    fun doRedo() {
        if (redo.isEmpty()) return
        undo.add(layout)
        val next = redo.removeAt(redo.lastIndex)
        commit(next)
        tick++
    }

    BoxWithConstraints(
        Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF3F6FA8), Color(0xFF8DB4DC))))
    ) {
        val areaW = maxWidth.value
        val areaH = maxHeight.value
        val sc = layoutScale(layout)
        Box(Modifier.fillMaxSize().background(Color(0x77000000)))
        if (layout.snap) {
            Canvas(Modifier.fillMaxSize()) {
                val step = (8f + layout.grid * 24f).dp.toPx()
                var gx = step
                while (gx < size.width) {
                    var gy = step
                    while (gy < size.height) {
                        drawCircle(Color(0x44FFFFFF), 0.7.dp.toPx(), Offset(gx, gy))
                        gy += step
                    }
                    gx += step
                }
            }
        }
        // empty-space tap deselects
        Box(Modifier.fillMaxSize().pointerInput(Unit) { detectTapGestures { selId = null } })
        layout.buttons.forEach { b ->
            key(b.id) {
                val bw = b.w * sc
                val bh = b.h * sc
                val ox = b.x * (areaW - bw).coerceAtLeast(0f)
                val oy = b.y * (areaH - bh).coerceAtLeast(0f)
                Box(
                    Modifier.offset(ox.dp, oy.dp)
                        .pointerInput(b.id) { detectTapGestures(onTap = { selId = b.id; panel = 0 }) }
                        .pointerInput(b.id) {
                            var accX = 0f
                            var accY = 0f
                            var startX = 0f
                            var startY = 0f
                            detectDragGestures(
                                onDragStart = {
                                    selId = b.id
                                    panel = 0
                                    push()
                                    val cur = layout.buttons.firstOrNull { it.id == b.id }
                                    if (cur != null) {
                                        val cw = cur.w * layoutScale(layout)
                                        val ch = cur.h * layoutScale(layout)
                                        startX = cur.x * (areaW - cw).coerceAtLeast(0f)
                                        startY = cur.y * (areaH - ch).coerceAtLeast(0f)
                                    }
                                    accX = 0f
                                    accY = 0f
                                },
                                onDrag = { change, drag ->
                                    change.consume()
                                    accX += drag.x / density
                                    accY += drag.y / density
                                    val cur = layout.buttons.firstOrNull { it.id == b.id }
                                    if (cur != null) {
                                        val cw = cur.w * layoutScale(layout)
                                        val ch = cur.h * layoutScale(layout)
                                        var nx = startX + accX
                                        var ny = startY + accY
                                        if (layout.snap) {
                                            val g = 8f + layout.grid * 24f
                                            nx = Math.round(nx / g) * g
                                            ny = Math.round(ny / g) * g
                                        }
                                        val maxX = (areaW - cw).coerceAtLeast(0f)
                                        val maxY = (areaH - ch).coerceAtLeast(0f)
                                        nx = nx.coerceIn(0f, maxX)
                                        ny = ny.coerceIn(0f, maxY)
                                        val fx = if (maxX > 1f) nx / maxX else 0f
                                        val fy = if (maxY > 1f) ny / maxY else 0f
                                        commit(layout.copy(buttons = layout.buttons.map { if (it.id == b.id) it.copy(x = fx, y = fy) else it }))
                                    }
                                }
                            )
                        }
                ) {
                    CtlVisual(b, sc, layout.opacity, false, Offset.Zero)
                    if (selId == b.id) Box(Modifier.matchParentSize().border(1.5.dp, Color.White, RoundedCornerShape(3.dp)))
                }
            }
        }
        // toolbar
        Row(
            Modifier.align(Alignment.TopCenter).padding(top = 10.dp).clip(RoundedCornerShape(13.dp)).background(Color(0xEE0A0A0C))
                .border(1.dp, Color(0xFF36363C), RoundedCornerShape(13.dp)).padding(horizontal = 4.dp, vertical = 3.dp),
            horizontalArrangement = Arrangement.spacedBy(2.dp), verticalAlignment = Alignment.CenterVertically
        ) {
            ToolItem(Icons.Default.Add, "Button") { addControl(0) }
            ToolItem(Icons.Default.Gamepad, "Joystick") { addControl(1) }
            ToolItem(Icons.Default.Settings, "Layout") { panel = if (panel == 1) 0 else 1; selId = null }
            ToolItem(Icons.Default.Undo, "Undo", enabled = undo.isNotEmpty() && historyVersion >= 0) { doUndo() }
            ToolItem(Icons.Default.Redo, "Redo", enabled = redo.isNotEmpty() && historyVersion >= 0) { doRedo() }
            ToolItem(Icons.Default.Layers, layout.name) { showLayouts = true }
            ToolItem(Icons.Default.Save, "Save as") { showSaveAs = true }
            ToolItem(Icons.Default.Check, "Done", filled = true) { s.editorOpen = false }
        }
        if (layout.buttons.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Txt("No controls yet. Tap Button or Joystick to add one.", 7f, Color(0xCCFFFFFF)) }
        }
        // side panels
        val sel = layout.buttons.firstOrNull { it.id == selId }
        if (panel == 1) {
            Box(Modifier.align(Alignment.CenterEnd)) {
                LayoutPanel(
                    layout, { l -> commit(l) },
                    { push(); commit(layout.copy(buttons = layout.buttons.map { it.copy(x = 1f - it.x) })) },
                    { push(); store.resetActive(); layout = store.active },
                    { panel = 0 }
                )
            }
        } else if (sel != null) {
            Box(Modifier.align(Alignment.CenterEnd)) {
                PropertyPanel(
                    sel, lockRatio, { lockRatio = it },
                    { record, f -> change(record, f) },
                    { initial, done -> picker = PickerReq(initial, done) },
                    { duplicate() }, { deleteSelected() }, { selId = null }
                )
            }
        }
        if (showLayouts) LayoutsDialog(s) { showLayouts = false }
        if (showSaveAs) {
            SaveAsDialog(
                onSave = { nm ->
                    store.addCopy(nm, layout)
                    s.toast("Layout saved as " + store.active.name)
                    showSaveAs = false
                },
                onClose = { showSaveAs = false }
            )
        }
        val pk = picker
        if (pk != null) ColorPickerDialog(pk.initial, { c -> pk.onApply(c); picker = null }, { picker = null })
    }
}
