package com.murasaki.launcher

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Base64
import android.widget.Toast
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

data class TaskInfo(val title: String, val progress: Float, val message: String, val finished: Boolean, val error: Boolean)
data class TaskResult(val message: String, val newInstance: Instance? = null)

class LauncherState(
    private val engine: LauncherEngine,
    private val scope: CoroutineScope,
    private val ctx: Context
) {
    private val sp = ctx.getSharedPreferences("murasaki", Context.MODE_PRIVATE)
    val installer = Installer(ctx)
    val controls = ControlsStore(ctx)
    val game = GameSession()

    // navigation
    var screen by mutableStateOf("Home")
    var showAdd by mutableStateOf(false)
    var showAccounts by mutableStateOf(false)
    var settingsTab by mutableStateOf(0)
    var editorOpen by mutableStateOf(false)

    // settings
    var javaRuntime by mutableStateOf("Temurin 17")
    var memFrac by mutableStateOf(0.6f)
    var jvmArgs by mutableStateOf("-XX:+UseG1GC -XX:MaxGCPauseMillis=50")
    var gameDir by mutableStateOf("")
    var resScale by mutableStateOf(1f)
    var renderer by mutableStateOf("gl4es (fast)")
    var showFps by mutableStateOf(false)
    var sustained by mutableStateOf(true)
    var touchLayout by mutableStateOf("Default")
    var btnOpacity by mutableStateOf(0.7f)
    var haptic by mutableStateOf(true)
    var language by mutableStateOf("English")
    var theme by mutableStateOf("Dark")
    var checkUpdates by mutableStateOf(true)
    var cursorSize by mutableStateOf(0.5f)
    var cursorSens by mutableStateOf(0.6f)
    var cursorStyle by mutableStateOf(0)
    var customCursor by mutableStateOf<Bitmap?>(null)
    var cfKey by mutableStateOf("")
    val memoryMb: Int get() = 1024 + ((memFrac * 5f * 4f).toInt() * 256)

    // accounts and instances
    var accounts by mutableStateOf(listOf(Account("Murasaki_Devil", "Local Account")))
    var accountIdx by mutableStateOf(0)
    var instances by mutableStateOf(
        listOf(
            Instance("Latest Release", "1.21.4", "1.21.4", null, "grass", null, "latest-release"),
            Instance("Fabric", "1.21.4", "1.21.4", "Fabric", "diamond_ore", null, "fabric"),
            Instance("Forge", "1.20.1", "1.20.1", "Forge", "furnace", null, "forge")
        )
    )
    var instanceIdx by mutableStateOf(0)
    var manageIdx by mutableStateOf(0)
    var instTab by mutableStateOf(0)
    var versions by mutableStateOf(listOf(GameVersion("1.21.4")))
    val account: Account get() = accounts[accountIdx.coerceIn(0, accounts.lastIndex)]
    val current: Instance get() = instances[instanceIdx.coerceIn(0, instances.lastIndex)]

    // launch
    var status by mutableStateOf<String?>(null)
    var launching by mutableStateOf(false)

    // skins
    var skin by mutableStateOf(loadDefaultSkin())
    var cape by mutableStateOf<Bitmap?>(null)
    var skinBusy by mutableStateOf(false)
    var capeBusy by mutableStateOf(false)

    // discover
    var dTab by mutableStateOf(0)
    var dSource by mutableStateOf(0)
    var dQuery by mutableStateOf("")
    var dSort by mutableStateOf(0)
    var dMatch by mutableStateOf(true)
    var dResults by mutableStateOf<List<Project>>(emptyList())
    var dLoading by mutableStateOf(false)
    var dError by mutableStateOf<String?>(null)
    var dMore by mutableStateOf(false)
    var detail by mutableStateOf<Project?>(null)
    private var searchJob: Job? = null

    // background tasks
    var task by mutableStateOf<TaskInfo?>(null)
    var refreshTick by mutableStateOf(0)

    val news = NewsItem("Minecraft 1.21.4 Released", "Read what is new in the latest update.", "Dec 3, 2024")

    init {
        runCatching { load() }
        if (gameDir.isEmpty()) gameDir = installer.root().path
        CurseForge.apiKey = cfKey.ifBlank { BuildConfig.CF_API_KEY }
        scope.launch {
            runCatching { engine.fetchVersions() }.onSuccess { list -> if (list.isNotEmpty()) versions = list }
        }
    }

    private fun loadDefaultSkin(): Bitmap {
        val o = BitmapFactory.Options().apply { inScaled = false }
        return BitmapFactory.decodeResource(ctx.resources, R.drawable.skin_default, o)
    }

    fun toast(msg: String) { Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show() }

    fun setCfKey(k: String) {
        cfKey = k
        CurseForge.apiKey = k.ifBlank { BuildConfig.CF_API_KEY }
        sp.edit().putString("cfkey", k).apply()
    }

    // ------------------------------------------------------------ persistence
    fun save() {
        val o = JSONObject()
        o.put("java", javaRuntime); o.put("mem", memFrac.toDouble()); o.put("jvm", jvmArgs); o.put("dir", gameDir)
        o.put("res", resScale.toDouble()); o.put("renderer", renderer); o.put("fps", showFps); o.put("sustained", sustained)
        o.put("layout", touchLayout); o.put("opacity", btnOpacity.toDouble()); o.put("haptic", haptic)
        o.put("lang", language); o.put("theme", theme); o.put("updates", checkUpdates)
        o.put("cSize", cursorSize.toDouble()); o.put("cSens", cursorSens.toDouble()); o.put("cStyle", cursorStyle)
        val ac = JSONArray()
        accounts.forEach { ac.put(JSONObject().put("n", it.name).put("t", it.type)) }
        o.put("accounts", ac); o.put("acc", accountIdx)
        val ins = JSONArray()
        instances.forEach {
            ins.put(
                JSONObject().put("t", it.title).put("s", it.subtitle).put("v", it.version)
                    .put("l", it.loader ?: "").put("i", it.iconKey).put("c", it.customIcon ?: "").put("d", it.dir)
                    .put("jo", it.javaOverride ?: "").put("mo", it.memOverride).put("ja", it.jvmOverride)
                    .put("ga", it.gameArgs).put("rw", it.resW).put("rh", it.resH)
            )
        }
        o.put("instances", ins); o.put("inst", instanceIdx)
        sp.edit().putString("state", o.toString()).apply()
    }

    private fun load() {
        cfKey = sp.getString("cfkey", "") ?: ""
        val o = JSONObject(sp.getString("state", "{}") ?: "{}")
        javaRuntime = o.optString("java", javaRuntime); memFrac = o.optDouble("mem", memFrac.toDouble()).toFloat()
        jvmArgs = o.optString("jvm", jvmArgs); gameDir = o.optString("dir", gameDir)
        resScale = o.optDouble("res", resScale.toDouble()).toFloat(); renderer = o.optString("renderer", renderer)
        showFps = o.optBoolean("fps", showFps); sustained = o.optBoolean("sustained", sustained)
        touchLayout = o.optString("layout", touchLayout); btnOpacity = o.optDouble("opacity", btnOpacity.toDouble()).toFloat()
        haptic = o.optBoolean("haptic", haptic); language = o.optString("lang", language)
        theme = o.optString("theme", theme); checkUpdates = o.optBoolean("updates", checkUpdates)
        cursorSize = o.optDouble("cSize", cursorSize.toDouble()).toFloat(); cursorSens = o.optDouble("cSens", cursorSens.toDouble()).toFloat()
        cursorStyle = o.optInt("cStyle", cursorStyle)
        val ac = o.optJSONArray("accounts")
        if (ac != null && ac.length() > 0) {
            accounts = (0 until ac.length()).map { val a = ac.getJSONObject(it); Account(a.getString("n"), a.getString("t")) }
            accountIdx = o.optInt("acc", 0)
        }
        val ins = o.optJSONArray("instances")
        if (ins != null && ins.length() > 0) {
            instances = (0 until ins.length()).map {
                val a = ins.getJSONObject(it)
                val title = a.getString("t")
                Instance(
                    title, a.getString("s"), a.getString("v"), a.optString("l", "").ifEmpty { null },
                    a.optString("i", "grass"), a.optString("c", "").ifEmpty { null }, a.optString("d", "").ifEmpty { slug(title) },
                    a.optString("jo", "").ifEmpty { null }, a.optInt("mo", 0), a.optString("ja", ""),
                    a.optString("ga", ""), a.optInt("rw", 0), a.optInt("rh", 0)
                )
            }
            instanceIdx = o.optInt("inst", 0)
        }
        val cf = File(ctx.filesDir, "cursor.png")
        if (cf.exists()) customCursor = BitmapFactory.decodeFile(cf.path)
        val sf = File(ctx.filesDir, "skin.png")
        if (sf.exists()) BitmapFactory.decodeFile(sf.path)?.let { skin = it }
        val kf = File(ctx.filesDir, "cape.png")
        if (kf.exists()) BitmapFactory.decodeFile(kf.path)?.let { cape = it }
    }

    // ------------------------------------------------------------ instances and accounts
    fun addInstance(i: Instance) {
        val d = if (i.dir.isEmpty()) slug(i.title) + "-" + (System.currentTimeMillis() % 100000) else i.dir
        instances = instances + i.copy(dir = d)
        instanceIdx = instances.lastIndex
        save()
    }

    fun updateInstance(index: Int, i: Instance) {
        instances = instances.mapIndexed { n, old -> if (n == index) i else old }
        save()
    }

    fun removeInstance(index: Int) {
        if (instances.size <= 1) return
        val gone = instances[index]
        instances = instances.filterIndexed { n, _ -> n != index }
        instanceIdx = instanceIdx.coerceIn(0, instances.lastIndex)
        manageIdx = manageIdx.coerceIn(0, instances.lastIndex)
        save()
        scope.launch(Dispatchers.IO) { runCatching { installer.deleteInstanceFiles(gone) } }
    }

    fun addLocalAccount(name: String) {
        val n = name.trim()
        if (n.isEmpty()) { toast("Type a username first"); return }
        accounts = accounts + Account(n, "Local Account")
        accountIdx = accounts.lastIndex
        save()
    }

    fun removeAccount(index: Int) {
        if (accounts.size <= 1) return
        accounts = accounts.filterIndexed { n, _ -> n != index }
        accountIdx = accountIdx.coerceIn(0, accounts.lastIndex)
        save()
    }

    fun play() {
        if (game.running) return
        val i = current
        controls.setActive(controls.defaultIdx)
        game.begin()
        val mem = if (i.memOverride > 0) i.memOverride else memoryMb
        val jvm = if (i.jvmOverride.isNotEmpty()) i.jvmOverride else jvmArgs
        game.log('I', "[Launcher] Starting " + i.title + "  (" + i.version + (if (i.loader != null) ", " + i.loader else "") + ")")
        game.log('I', "[Launcher] Account: " + account.name + "  (" + account.type + ")")
        game.log('I', "[Launcher] Java: " + (i.javaOverride ?: javaRuntime) + ",  memory " + mem + " MB,  renderer " + renderer)
        game.log('I', "[Launcher] Game folder: " + installer.dir(i).path)
        scope.launch {
            runCatching {
                engine.launch(i, LauncherSettings(i.javaOverride ?: javaRuntime, mem, installer.dir(i).path, jvm)) { msg -> game.log('I', "[Launcher] " + msg) }
            }.onFailure { game.log('E', "[Launcher] " + (it.message ?: "Launch failed")) }
            game.log('W', "[Launcher] The Minecraft engine is not connected yet. This is a preview session: controls, menu and log work, the game itself does not run.")
        }
    }

    fun endGame(force: Boolean) {
        game.log('W', if (force) "[Launcher] Game process force-quit by the player" else "[Launcher] Game closed by the player")
        game.running = false
        toast(if (force) "Game force-quit" else "Back at the launcher")
    }

    // ------------------------------------------------------------ background tasks
    fun startTask(title: String, work: ((Float, String) -> Unit) -> TaskResult) {
        val t = task
        if (t != null && !t.finished) { toast("Please wait, another task is running"); return }
        task = TaskInfo(title, 0f, "Starting...", false, false)
        scope.launch {
            try {
                val res = withContext(Dispatchers.IO) {
                    work { p, m -> task = TaskInfo(title, p, m, false, false) }
                }
                val ni = res.newInstance
                if (ni != null) { instances = instances + ni; save() }
                task = TaskInfo(title, 1f, res.message, true, false)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                task = TaskInfo(title, 0f, e.message ?: "Failed", true, true)
            }
            refreshTick++
        }
    }

    // ------------------------------------------------------------ discover
    fun search(reset: Boolean) {
        searchJob?.cancel()
        val offset = if (reset) 0 else dResults.size
        dLoading = true
        dError = null
        searchJob = scope.launch {
            try {
                val inst = current
                val modpack = dTab == 3
                val mc = if (dMatch && !modpack) inst.version else null
                val loader = if (dMatch && !modpack) inst.loader else null
                val list = withContext(Dispatchers.IO) {
                    if (dSource == 0) Modrinth.search(dTab, dQuery.trim(), mc, loader, MODRINTH_SORTS[dSort], offset)
                    else CurseForge.search(dTab, dQuery.trim(), mc, loader, CF_SORTS[dSort], offset)
                }
                dResults = if (reset) list else dResults + list
                dMore = list.size >= 20
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                dError = e.message ?: "Could not load"
            }
            dLoading = false
        }
    }

    fun versionsFor(p: Project): List<FileVer> {
        val inst = current
        val pack = p.type == "modpack"
        val mc = if (pack) null else inst.version.ifEmpty { null }
        val loader = if (pack) null else inst.loader
        val useLoader = p.type == "mod"
        return if (p.source == "modrinth") Modrinth.versions(p.id, mc, loader, useLoader)
        else CurseForge.files(p.id, mc, loader, useLoader)
    }

    private fun installChain(inst: Instance, p: Project, v: FileVer, update: (Float, String) -> Unit, depth: Int, seen: MutableSet<String>) {
        if (!seen.add(p.source + p.id)) return
        update(0.1f, "Downloading " + v.fileName)
        installer.installFile(inst, p, v) { f -> update(0.1f + 0.8f * f, "Downloading " + v.fileName) }
        if (depth < 2) {
            for (depId in v.requiredDeps) {
                try {
                    val dp = if (p.source == "modrinth") Modrinth.project(depId) else CurseForge.project(depId)
                    val dv = versionsFor(dp).firstOrNull() ?: continue
                    installChain(inst, dp, dv, update, depth + 1, seen)
                } catch (e: Exception) {
                    // a missing helper mod should not stop the main install
                }
            }
        }
    }

    fun install(p: Project, chosen: FileVer?) {
        if (p.type == "modpack") { installModpack(p, chosen); return }
        val inst = current
        startTask("Installing " + p.title) { update ->
            val v = chosen ?: versionsFor(p).firstOrNull() ?: throw IllegalStateException("No version of " + p.title + " found for " + inst.version)
            installChain(inst, p, v, update, 0, HashSet())
            TaskResult("Installed " + p.title + " in " + inst.title)
        }
    }

    private fun installModpack(p: Project, chosen: FileVer?) {
        startTask("Installing " + p.title) { update ->
            val v = chosen ?: versionsFor(p).firstOrNull() ?: throw IllegalStateException("No version found")
            val url = v.url ?: throw IllegalStateException("The author blocks downloads outside CurseForge. Open it on the website.")
            val zip = File(ctx.cacheDir, "pack_" + System.currentTimeMillis() + ".zip")
            update(0.02f, "Downloading modpack")
            Net.download(url, zip) { d, t -> if (t > 0) update(0.02f + 0.18f * (d.toFloat() / t.toFloat()), "Downloading modpack") }
            val res = installer.installPackFile(zip, p.iconUrl) { f, m -> update(0.2f + 0.8f * f, m) }
            zip.delete()
            val extra = if (res.skipped.isEmpty()) "" else "  -  " + res.skipped.size + " files could not be downloaded"
            TaskResult("Created instance " + res.inst.title + extra, res.inst)
        }
    }

    fun importPack(uri: Uri) {
        startTask("Importing modpack") { update ->
            val zip = File(ctx.cacheDir, "import_" + System.currentTimeMillis() + ".zip")
            update(0.02f, "Reading file")
            ctx.contentResolver.openInputStream(uri)?.use { input -> zip.outputStream().use { out -> input.copyTo(out) } }
                ?: throw IllegalStateException("Could not read that file")
            val res = installer.installPackFile(zip, null) { f, m -> update(0.05f + 0.95f * f, m) }
            zip.delete()
            val extra = if (res.skipped.isEmpty()) "" else "  -  " + res.skipped.size + " files could not be downloaded"
            TaskResult("Created instance " + res.inst.title + extra, res.inst)
        }
    }

    // ------------------------------------------------------------ images
    private fun decode(uri: Uri): Bitmap? =
        ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }

    fun saveImageCopy(uri: Uri, fileName: String, maxSize: Int): String? {
        val b = decode(uri) ?: return null
        val s = if (b.width > maxSize || b.height > maxSize) {
            val k = maxSize.toFloat() / maxOf(b.width, b.height)
            Bitmap.createScaledBitmap(b, (b.width * k).toInt().coerceAtLeast(1), (b.height * k).toInt().coerceAtLeast(1), true)
        } else b
        val f = File(ctx.filesDir, fileName)
        f.outputStream().use { s.compress(Bitmap.CompressFormat.PNG, 100, it) }
        return f.path
    }

    fun importCursor(uri: Uri) {
        val p = saveImageCopy(uri, "cursor.png", 128)
        if (p == null) { toast("Could not read that image"); return }
        customCursor = BitmapFactory.decodeFile(p)
        cursorStyle = 3
        save()
    }

    private fun saveBmp(b: Bitmap, name: String) {
        runCatching { File(ctx.filesDir, name).outputStream().use { b.compress(Bitmap.CompressFormat.PNG, 100, it) } }
    }

    private fun setSkin(b: Bitmap) { val n = Skin3D.normalizeSkin(b); skin = n; saveBmp(n, "skin.png") }
    private fun setCape(b: Bitmap) { val n = Skin3D.normalizeCape(b); cape = n; saveBmp(n, "cape.png") }

    fun importSkin(uri: Uri) {
        val b = decode(uri)
        if (b == null) { toast("Could not read that image"); return }
        setSkin(b)
    }

    fun importCape(uri: Uri) {
        val b = decode(uri)
        if (b == null) { toast("Could not read that image"); return }
        setCape(b)
    }

    // ------------------------------------------------------------ Mojang skin lookup
    private fun httpGet(url: String): String? {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 10000; c.readTimeout = 10000
        c.setRequestProperty("User-Agent", Net.UA)
        return if (c.responseCode == 200) c.inputStream.bufferedReader().use { it.readText() } else null
    }

    private fun bitmapFrom(url: String): Bitmap? {
        val c = URL(url.replace("http://", "https://")).openConnection() as HttpURLConnection
        c.connectTimeout = 10000; c.readTimeout = 10000
        c.setRequestProperty("User-Agent", Net.UA)
        return c.inputStream.use { BitmapFactory.decodeStream(it) }
    }

    private suspend fun fetchTextures(name: String): Pair<Bitmap?, Bitmap?> = withContext(Dispatchers.IO) {
        val p = httpGet("https://api.mojang.com/users/profiles/minecraft/" + URLEncoder.encode(name, "UTF-8"))
            ?: throw IllegalStateException("Player not found")
        val id = JSONObject(p).getString("id")
        val prof = httpGet("https://sessionserver.mojang.com/session/minecraft/profile/$id")
            ?: throw IllegalStateException("Profile unavailable, try again in a minute")
        val props = JSONObject(prof).getJSONArray("properties")
        var skinBmp: Bitmap? = null
        var capeBmp: Bitmap? = null
        for (i in 0 until props.length()) {
            val o = props.getJSONObject(i)
            if (o.getString("name") == "textures") {
                val tex = JSONObject(String(Base64.decode(o.getString("value"), Base64.DEFAULT))).getJSONObject("textures")
                if (tex.has("SKIN")) skinBmp = bitmapFrom(tex.getJSONObject("SKIN").getString("url"))
                if (tex.has("CAPE")) capeBmp = bitmapFrom(tex.getJSONObject("CAPE").getString("url"))
            }
        }
        Pair(skinBmp, capeBmp)
    }

    fun fetchSkin(name: String) {
        if (name.isBlank() || skinBusy) { if (name.isBlank()) toast("Type a username first"); return }
        skinBusy = true
        scope.launch {
            runCatching { fetchTextures(name.trim()) }
                .onSuccess { (s, _) -> if (s != null) setSkin(s) else toast("That player uses a default skin") }
                .onFailure { toast(it.message ?: "Could not fetch skin") }
            skinBusy = false
        }
    }

    fun fetchCape(name: String) {
        if (name.isBlank() || capeBusy) { if (name.isBlank()) toast("Type a username first"); return }
        capeBusy = true
        scope.launch {
            runCatching { fetchTextures(name.trim()) }
                .onSuccess { (_, c) -> if (c != null) setCape(c) else toast("That player has no cape") }
                .onFailure { toast(it.message ?: "Could not fetch cape") }
            capeBusy = false
        }
    }
}
