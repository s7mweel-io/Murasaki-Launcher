package com.murasaki.launcher

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch

class LauncherState(
    private val engine: LauncherEngine,
    private val scope: CoroutineScope
) {
    var screen by mutableStateOf("Home")
    var account by mutableStateOf(Account("Murasaki_Devil")) // placeholder until real login exists
    var versions by mutableStateOf(listOf(GameVersion("1.20.4")))
    var version by mutableStateOf(GameVersion("1.20.4"))
    var loader by mutableStateOf<String?>(null)
    var settings by mutableStateOf(LauncherSettings())
    var status by mutableStateOf<String?>(null)
    var launching by mutableStateOf(false)

    val quickAccess = listOf(
        Instance("Latest Release", "1.20.4", "1.20.4"),
        Instance("Fabric", "1.20.4", "1.20.4", "Fabric"),
        Instance("Forge", "1.20.1", "1.20.1", "Forge")
    )
    val recent = listOf(
        Instance("1.20.4", "Survival World", "1.20.4"),
        Instance("Fabric 1.20.1", "Modded", "1.20.1", "Fabric"),
        Instance("Forge 1.19.2", "Modded", "1.19.2", "Forge")
    )
    val news = NewsItem(
        "Minecraft 1.20.4 Released",
        "The Trails & Tales Update brings new features, blocks and more!",
        "Apr 25, 2024"
    )

    init {
        scope.launch {
            runCatching { engine.fetchVersions() }.onSuccess { list ->
                if (list.isNotEmpty()) {
                    versions = list
                    version = list.first()
                }
            }
        }
    }

    fun pick(i: Instance) {
        version = GameVersion(i.version)
        loader = i.loader
    }

    fun play() {
        if (launching) return
        launching = true
        status = null
        scope.launch {
            runCatching {
                engine.launch(Instance("Current", version.id, version.id, loader), settings) { status = it }
            }.onSuccess { status = null }
                .onFailure { status = "Failed: ${it.message}" }
            launching = false
        }
    }
}
