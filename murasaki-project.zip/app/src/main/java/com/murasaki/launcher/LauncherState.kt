package com.murasaki.launcher

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Base64
import android.widget.Toast
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

class LauncherState(
    private val engine: LauncherEngine,
    private val scope: CoroutineScope,
    private val ctx: Context
) {
    private val sp = ctx.getSharedPreferences("murasaki", Context.MODE_PRIVATE)

    // navigation
    var screen by mutableStateOf("Home")
    var showAdd by mutableStateOf(false)
    var showAccounts by mutableStateOf(false)
    var settingsTab by mutableStateOf(0)

    // settings
    var javaRuntime by mutableStateOf("Temurin 17")
    var memFrac by mutableStateOf(0.6f)
    var jvmArgs by mutableStateOf("-XX:+UseG1GC -XX:MaxGCPauseMillis=50")
    var gameDir by mutableStateOf("/storage/emulated/0/Minecraft")
    var resScale by mutableStateOf(1f)
    var renderer by mutableStateOf("gl4es (fast)")
    var showFps by mutableStateOf(false)
    var sustained by mutableStateOf(true)
    var touchLayout by mutableStateOf("Default")
    var btnOpacity by mutableStateOf(0.7f)
    var haptic by mutableStateOf(true)
    var language by mutableStateOf("English")
    var theme by mutableStateOf("Dark")
    var checkUpdates by mutableStateOf(true)
    var cursorSize by mutableStateOf(0.5f)
    var cursorSens by mutableStateOf(0.6f)
    var cursorStyle by mutableStateOf(0)
    var customCursor by mutableStateOf<Bitmap?>(null)
    val memoryMb: Int get() = 1024 + ((memFrac * 5f * 4f).toInt() * 256)

    // accounts and instances
    var accounts by mutableStateOf(listOf(Account("Murasaki_Devil", "Local Account")))
    var accountIdx by mutableStateOf(0)
    var instances by mutableStateOf(
        listOf(
            Instance("Latest Release", "1.21.4", "1.21.4", null, "grass"),
            Instance("Fabric", "1.21.4", "1.21.4", "Fabric", "diamond_ore"),
            Instance("Forge", "1.20.1", "1.20.1", "Forge", "furnace")
        )
    )
    var instanceIdx by mutableStateOf(0)
    var versions by mutableStateOf(listOf(GameVersion("1.21.4")))
    val account: Account get() = accounts[accountIdx.coerceIn(0, accounts.lastIndex)]
    val current: Instance get() = instances[instanceIdx.coerceIn(0, instances.lastIndex)]

    // launch
    var status by mutableStateOf<String?>(null)
    var launching by mutableStateOf(false)

    // skins
    var skin by mutableStateOf(loadDefaultSkin())
    var cape by mutableStateOf<Bitmap?>(null)
    var skinBusy by mutableStateOf(false)
    var capeBusy by mutableStateOf(false)

    val news = NewsItem("Minecraft 1.21.4 Released", "Read what is new in the latest update.", "Dec 3, 2024")

    init {
        runCatching { load() }
        scope.launch {
            runCatching { engine.fetchVersions() }.onSuccess { list -> if (list.isNotEmpty()) versions = list }
        }
    }

    private fun loadDefaultSkin(): Bitmap {
        val o = BitmapFactory.Options().apply { inScaled = false }
        return BitmapFactory.decodeResource(ctx.resources, R.drawable.skin_default, o)
    }

    fun toast(msg: String) { Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show() }

    // ------------------------------------------------------------ persistence
    fun save() {
        val o = JSONObject()
        o.put("java", javaRuntime); o.put("mem", memFrac.toDouble()); o.put("jvm", jvmArgs); o.put("dir", gameDir)
        o.put("res", resScale.toDouble()); o.put("renderer", renderer); o.put("fps", showFps); o.put("sustained", sustained)
        o.put("layout", touchLayout); o.put("opacity", btnOpacity.toDouble()); o.put("haptic", haptic)
        o.put("lang", language); o.put("theme", theme); o.put("updates", checkUpdates)
        o.put("cSize", cursorSize.toDouble()); o.put("cSens", cursorSens.toDouble()); o.put("cStyle", cursorStyle)
        val ac = JSONArray()
        accounts.forEach { ac.put(JSONObject().put("n", it.name).put("t", it.type)) }
        o.put("accounts", ac); o.put("acc", accountIdx)
        val ins = JSONArray()
        instances.forEach {
            ins.put(
                JSONObject().put("t", it.title).put("s", it.subtitle).put("v", it.version)
                    .put("l", it.loader ?: "").put("i", it.iconKey).put("c", it.customIcon ?: "")
            )
        }
        o.put("instances", ins); o.put("inst", instanceIdx)
        sp.edit().putString("state", o.toString()).apply()
    }

    private fun load() {
        val o = JSONObject(sp.getString("state", "{}") ?: "{}")
        javaRuntime = o.optString("java", javaRuntime); memFrac = o.optDouble("mem", memFrac.toDouble()).toFloat()
        jvmArgs = o.optString("jvm", jvmArgs); gameDir = o.optString("dir", gameDir)
        resScale = o.optDouble("res", resScale.toDouble()).toFloat(); renderer = o.optString("renderer", renderer)
        showFps = o.optBoolean("fps", showFps); sustained = o.optBoolean("sustained", sustained)
        touchLayout = o.optString("layout", touchLayout); btnOpacity = o.optDouble("opacity", btnOpacity.toDouble()).toFloat()
        haptic = o.optBoolean("haptic", haptic); language = o.optString("lang", language)
        theme = o.optString("theme", theme); checkUpdates = o.optBoolean("updates", checkUpdates)
        cursorSize = o.optDouble("cSize", cursorSize.toDouble()).toFloat(); cursorSens = o.optDouble("cSens", cursorSens.toDouble()).toFloat()
        cursorStyle = o.optInt("cStyle", cursorStyle)
        val ac = o.optJSONArray("accounts")
        if (ac != null && ac.length() > 0) {
            accounts = (0 until ac.length()).map { val a = ac.getJSONObject(it); Account(a.getString("n"), a.getString("t")) }
            accountIdx = o.optInt("acc", 0)
        }
        val ins = o.optJSONArray("instances")
        if (ins != null && ins.length() > 0) {
            instances = (0 until ins.length()).map {
                val a = ins.getJSONObject(it)
                Instance(
                    a.getString("t"), a.getString("s"), a.getString("v"),
                    a.optString("l", "").ifEmpty { null }, a.optString("i", "grass"), a.optString("c", "").ifEmpty { null }
                )
            }
            instanceIdx = o.optInt("inst", 0)
        }
        val cf = File(ctx.filesDir, "cursor.png")
        if (cf.exists()) customCursor = BitmapFactory.decodeFile(cf.path)
    }

    // ------------------------------------------------------------ actions
    fun addInstance(i: Instance) {
        instances = instances + i
        instanceIdx = instances.lastIndex
        save()
    }

    fun removeInstance(index: Int) {
        if (instances.size <= 1) return
        instances = instances.filterIndexed { n, _ -> n != index }
        instanceIdx = instanceIdx.coerceIn(0, instances.lastIndex)
        save()
    }

    fun addLocalAccount(name: String) {
        val n = name.trim()
        if (n.isEmpty()) { toast("Type a username first"); return }
        accounts = accounts + Account(n, "Local Account")
        accountIdx = accounts.lastIndex
        save()
    }

    fun removeAccount(index: Int) {
        if (accounts.size <= 1) return
        accounts = accounts.filterIndexed { n, _ -> n != index }
        accountIdx = accountIdx.coerceIn(0, accounts.lastIndex)
        save()
    }

    fun play() {
        if (launching) return
        launching = true
        status = null
        scope.launch {
            runCatching {
                engine.launch(current, LauncherSettings(javaRuntime, memoryMb, gameDir, jvmArgs)) { status = it }
            }.onSuccess { status = null }.onFailure { status = "Failed: ${it.message}" }
            launching = false
        }
    }

    // ------------------------------------------------------------ images
    private fun decode(uri: Uri): Bitmap? =
        ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }

    fun saveImageCopy(uri: Uri, fileName: String, maxSize: Int): String? {
        val b = decode(uri) ?: return null
        val s = if (b.width > maxSize || b.height > maxSize) {
            val k = maxSize.toFloat() / maxOf(b.width, b.height)
            Bitmap.createScaledBitmap(b, (b.width * k).toInt().coerceAtLeast(1), (b.height * k).toInt().coerceAtLeast(1), true)
        } else b
        val f = File(ctx.filesDir, fileName)
        f.outputStream().use { s.compress(Bitmap.CompressFormat.PNG, 100, it) }
        return f.path
    }

    fun importCursor(uri: Uri) {
        val p = saveImageCopy(uri, "cursor.png", 128)
        if (p == null) { toast("Could not read that image"); return }
        customCursor = BitmapFactory.decodeFile(p)
        cursorStyle = 3
        save()
    }

    fun importSkin(uri: Uri) {
        val b = decode(uri)
        if (b == null) { toast("Could not read that image"); return }
        skin = Skin3D.normalizeSkin(b)
    }

    fun importCape(uri: Uri) {
        val b = decode(uri)
        if (b == null) { toast("Could not read that image"); return }
        cape = Skin3D.normalizeCape(b)
    }

    // ------------------------------------------------------------ Mojang skin lookup
    private fun httpGet(url: String): String? {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 10000; c.readTimeout = 10000
        return if (c.responseCode == 200) c.inputStream.bufferedReader().use { it.readText() } else null
    }

    private fun bitmapFrom(url: String): Bitmap? {
        val c = URL(url.replace("http://", "https://")).openConnection() as HttpURLConnection
        c.connectTimeout = 10000; c.readTimeout = 10000
        return c.inputStream.use { BitmapFactory.decodeStream(it) }
    }

    private suspend fun fetchTextures(name: String): Pair<Bitmap?, Bitmap?> = withContext(Dispatchers.IO) {
        val p = httpGet("https://api.mojang.com/users/profiles/minecraft/" + URLEncoder.encode(name, "UTF-8"))
            ?: throw IllegalStateException("Player not found")
        val id = JSONObject(p).getString("id")
        val prof = httpGet("https://sessionserver.mojang.com/session/minecraft/profile/$id")
            ?: throw IllegalStateException("Profile unavailable, try again in a minute")
        val props = JSONObject(prof).getJSONArray("properties")
        var skinBmp: Bitmap? = null
        var capeBmp: Bitmap? = null
        for (i in 0 until props.length()) {
            val o = props.getJSONObject(i)
            if (o.getString("name") == "textures") {
                val tex = JSONObject(String(Base64.decode(o.getString("value"), Base64.DEFAULT))).getJSONObject("textures")
                if (tex.has("SKIN")) skinBmp = bitmapFrom(tex.getJSONObject("SKIN").getString("url"))
                if (tex.has("CAPE")) capeBmp = bitmapFrom(tex.getJSONObject("CAPE").getString("url"))
            }
        }
        Pair(skinBmp, capeBmp)
    }

    fun fetchSkin(name: String) {
        if (name.isBlank() || skinBusy) { if (name.isBlank()) toast("Type a username first"); return }
        skinBusy = true
        scope.launch {
            runCatching { fetchTextures(name.trim()) }
                .onSuccess { (s, _) -> if (s != null) skin = Skin3D.normalizeSkin(s) else toast("That player uses a default skin") }
                .onFailure { toast(it.message ?: "Could not fetch skin") }
            skinBusy = false
        }
    }

    fun fetchCape(name: String) {
        if (name.isBlank() || capeBusy) { if (name.isBlank()) toast("Type a username first"); return }
        capeBusy = true
        scope.launch {
            runCatching { fetchTextures(name.trim()) }
                .onSuccess { (_, c) -> if (c != null) cape = Skin3D.normalizeCape(c) else toast("That player has no cape") }
                .onFailure { toast(it.message ?: "Could not fetch cape") }
            capeBusy = false
        }
    }
}
