package com.murasaki.launcher

import java.io.File
import java.net.HttpURLConnection
import java.net.URL

object Net {
    const val UA = "s7mweel-io/Murasaki-Launcher/0.1"

    private fun open(url: String, method: String, headers: Map<String, String>): HttpURLConnection {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = method
        c.connectTimeout = 15000
        c.readTimeout = 30000
        c.setRequestProperty("User-Agent", UA)
        c.setRequestProperty("Accept", "application/json")
        for ((k, v) in headers) c.setRequestProperty(k, v)
        return c
    }

    fun get(url: String, headers: Map<String, String> = emptyMap()): String {
        val c = open(url, "GET", headers)
        val code = c.responseCode
        if (code != 200) throw IllegalStateException("Server answered $code")
        return c.inputStream.bufferedReader().use { it.readText() }
    }

    fun post(url: String, json: String, headers: Map<String, String> = emptyMap()): String {
        val c = open(url, "POST", headers)
        c.doOutput = true
        c.setRequestProperty("Content-Type", "application/json")
        c.outputStream.use { it.write(json.toByteArray()) }
        val code = c.responseCode
        if (code != 200) throw IllegalStateException("Server answered $code")
        return c.inputStream.bufferedReader().use { it.readText() }
    }

    fun download(url: String, dest: File, onProgress: (Long, Long) -> Unit = { _, _ -> }) {
        val c = open(url, "GET", mapOf("Accept" to "*/*"))
        val code = c.responseCode
        if (code != 200) throw IllegalStateException("Download failed ($code)")
        val total = c.contentLengthLong
        dest.parentFile?.mkdirs()
        val tmp = File(dest.path + ".part")
        c.inputStream.use { input ->
            tmp.outputStream().use { out ->
                val buf = ByteArray(32 * 1024)
                var done = 0L
                while (true) {
                    val n = input.read(buf)
                    if (n < 0) break
                    out.write(buf, 0, n)
                    done += n
                    onProgress(done, total)
                }
            }
        }
        if (dest.exists()) dest.delete()
        tmp.renameTo(dest)
    }
}
