package com.murasaki.launcher

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Everything the UI needs from the "real" launcher. Swap StubEngine for a Pojav-backed one later. */
interface LauncherEngine {
    suspend fun fetchVersions(): List<GameVersion>
    suspend fun launch(instance: Instance, settings: LauncherSettings, onProgress: (String) -> Unit)
}

class StubEngine : LauncherEngine {

    // REAL: downloads Mojang's official release list.
    override suspend fun fetchVersions(): List<GameVersion> = withContext(Dispatchers.IO) {
        val conn = URL("https://piston-meta.mojang.com/mc/game/version_manifest_v2.json")
            .openConnection() as HttpURLConnection
        conn.connectTimeout = 10_000
        conn.readTimeout = 10_000
        val text = conn.inputStream.bufferedReader().use { it.readText() }
        val arr = JSONObject(text).getJSONArray("versions")
        (0 until arr.length())
            .map { arr.getJSONObject(it) }
            .filter { it.getString("type") == "release" }
            .map { GameVersion(it.getString("id")) }
    }

    // STUB: replace the body with the real steps (see README).
    override suspend fun launch(
        instance: Instance,
        settings: LauncherSettings,
        onProgress: (String) -> Unit
    ) {
        onProgress("Preparing ${instance.version}…")
        delay(800)
        // TODO 1: download client jar, libraries, assets from the version's JSON
        // TODO 2: extract natives
        // TODO 3: build JVM args (-Xmx${settings.memoryMb}M, game dir, auth)
        // TODO 4: start the JVM + renderer through Pojav's launch code
        onProgress("Launching…")
        delay(800)
    }
}
