package com.murasaki.launcher

data class Account(val name: String, val type: String)
data class GameVersion(val id: String)
data class Block(val key: String, val label: String, val res: Int)

data class Instance(
    val title: String,
    val subtitle: String,
    val version: String,
    val loader: String? = null,
    val iconKey: String = "grass",
    val customIcon: String? = null,
    val dir: String = "",
    val javaOverride: String? = null,
    val memOverride: Int = 0,
    val jvmOverride: String = "",
    val gameArgs: String = "",
    val resW: Int = 0,
    val resH: Int = 0
)

fun slug(s: String): String = s.lowercase().replace(Regex("[^a-z0-9]+"), "-").trim('-').ifEmpty { "instance" }

data class NewsItem(val title: String, val body: String, val date: String)

data class LauncherSettings(
    val javaRuntime: String = "Temurin 17",
    val memoryMb: Int = 4096,
    val gameDir: String = "/storage/emulated/0/Minecraft",
    val gameArgs: String = "Default"
)

val BLOCKS = listOf(
    Block("grass", "Grass", R.drawable.b_grass), Block("dirt", "Dirt", R.drawable.b_dirt),
    Block("stone", "Stone", R.drawable.b_stone), Block("cobblestone", "Cobblestone", R.drawable.b_cobblestone),
    Block("planks", "Planks", R.drawable.b_planks), Block("log", "Log", R.drawable.b_log),
    Block("sand", "Sand", R.drawable.b_sand), Block("glass", "Glass", R.drawable.b_glass),
    Block("bricks", "Bricks", R.drawable.b_bricks), Block("coal_ore", "Coal Ore", R.drawable.b_coal_ore),
    Block("iron_ore", "Iron Ore", R.drawable.b_iron_ore), Block("gold_ore", "Gold Ore", R.drawable.b_gold_ore),
    Block("diamond_ore", "Diamond Ore", R.drawable.b_diamond_ore), Block("lapis_ore", "Lapis Ore", R.drawable.b_lapis_ore),
    Block("obsidian", "Obsidian", R.drawable.b_obsidian), Block("netherrack", "Netherrack", R.drawable.b_netherrack),
    Block("ice", "Ice", R.drawable.b_ice), Block("snow", "Snow", R.drawable.b_snow),
    Block("lava", "Lava", R.drawable.b_lava), Block("gold_block", "Gold Block", R.drawable.b_gold_block),
    Block("diamond_block", "Diamond Block", R.drawable.b_diamond_block), Block("emerald_block", "Emerald Block", R.drawable.b_emerald_block),
    Block("iron_block", "Iron Block", R.drawable.b_iron_block), Block("furnace", "Furnace", R.drawable.b_furnace)
)
fun blockRes(key: String): Int = BLOCKS.firstOrNull { it.key == key }?.res ?: R.drawable.b_grass
