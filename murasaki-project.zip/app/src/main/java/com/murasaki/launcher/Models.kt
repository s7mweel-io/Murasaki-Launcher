package com.murasaki.launcher

data class Account(val name: String, val type: String = "Microsoft Account")
data class GameVersion(val id: String)

data class Instance(
    val title: String,
    val subtitle: String,
    val version: String,
    val loader: String? = null // null = vanilla, or "Fabric" / "Forge"
)

data class NewsItem(val title: String, val body: String, val date: String)

data class LauncherSettings(
    val javaRuntime: String = "Temurin 17",
    val memoryMb: Int = 4096,
    val gameDir: String = "/storage/emulated/0/Minecraft",
    val gameArgs: String = "Default"
)
